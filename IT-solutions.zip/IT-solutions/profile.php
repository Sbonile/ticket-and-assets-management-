<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];
$message = '';
$error = '';

// Get user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Get user stats
$stats = [
    'total_tickets' => $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ?")->execute([$userId]) ? $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ?")->fetchColumn() : 0,
    'open_tickets' => $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND status IN ('pending', 'in_progress')")->execute([$userId]) ? $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND status IN ('pending', 'in_progress')")->fetchColumn() : 0,
    'resolved_tickets' => $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND status = 'resolved'")->execute([$userId]) ? $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id = ? AND status = 'resolved'")->fetchColumn() : 0,
];

// Get assigned assets
$stmt = $pdo->prepare("SELECT * FROM assets WHERE assigned_to = ?");
$stmt->execute([$userId]);
$assets = $stmt->fetchAll();

// Get unread notifications count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$userId]);
$unreadCount = $stmt->fetchColumn();

// Get notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        
        if (empty($fullName) || empty($email)) {
            $error = 'Name and email are required.';
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, contact = ? WHERE id = ?");
            if ($stmt->execute([$fullName, $email, $phone, $userId])) {
                $_SESSION['name'] = $fullName;
                $_SESSION['email'] = $email;
                $message = 'Profile updated successfully!';
                // Refresh user data
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
            } else {
                $error = 'Failed to update profile.';
            }
        }
    } elseif ($action === 'change_password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $error = 'All password fields are required.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match.';
        } elseif (strlen($newPassword) < 6) {
            $error = 'Password must be at least 6 characters.';
        } else {
            // Verify current password
            $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $userData = $stmt->fetch();
            
            if (password_verify($currentPassword, $userData['password'])) {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                if ($stmt->execute([$hashedPassword, $userId])) {
                    $message = 'Password changed successfully!';
                } else {
                    $error = 'Failed to change password.';
                }
            } else {
                $error = 'Current password is incorrect.';
            }
        }
    } elseif ($action === 'update_preferences') {
        $theme = $_POST['theme'] ?? 'light';
        $notificationsEmail = isset($_POST['notifications_email']) ? 1 : 0;
        $notificationsBrowser = isset($_POST['notifications_browser']) ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE users SET theme = ?, notifications_email = ?, notifications_browser = ? WHERE id = ?");
        if ($stmt->execute([$theme, $notificationsEmail, $notificationsBrowser, $userId])) {
            $message = 'Preferences updated successfully!';
        } else {
            $error = 'Failed to update preferences.';
        }
    }
}

$theme = $user['theme'] ?? 'light';
$notifications_email = $user['notifications_email'] ?? 1;
$notifications_browser = $user['notifications_browser'] ?? 0;

function timeAgo($timestamp) {
    $seconds = time() - $timestamp;
    if ($seconds < 60) return 'Just now';
    $minutes = floor($seconds / 60);
    if ($minutes < 60) return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
    $hours = floor($minutes / 60);
    if ($hours < 24) return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    $days = floor($hours / 24);
    if ($days < 7) return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    return date('M d, Y', $timestamp);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root { 
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }
        
        /* Modern Navbar */
        .navbar { 
            background: var(--primary-gradient);
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand { 
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }
        
        .navbar-brand i {
            font-size: 1.6rem;
        }
        
        .navbar-brand:hover {
            color: white;
        }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            margin: 0 2px;
        }
        
        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
            font-weight: 600;
        }
        
        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
            border: 2px solid #f39c12;
        }
        
        /* Notification Dropdown */
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: 16px;
            border: none;
            box-shadow: 0 20px 40px -12px rgba(0,0,0,0.2);
            padding: 0;
        }
        
        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #e9ecef;
            background: white;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        
        .notifications-header h6 {
            font-weight: 700;
            margin: 0;
            color: #1e293b;
        }
        
        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid #f1f5f9;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .notification-item:hover {
            background: #fefce8;
        }
        
        .notification-item.unread {
            background: var(--primary-light);
        }
        
        .notification-icon {
            width: 36px;
            height: 36px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: #1e293b;
            margin-bottom: 4px;
        }
        
        .notification-message {
            font-size: 0.75rem;
            color: #64748b;
            margin-bottom: 4px;
        }
        
        .notification-time {
            font-size: 0.65rem;
            color: #94a3b8;
        }
        
        /* Main Content */
        .main-content { 
            margin-top: 80px; 
            padding: 24px 28px;
        }
        
        /* Profile Header */
        .profile-header {
            background: white;
            border-radius: 24px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12);
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--primary-gradient);
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 30px;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            box-shadow: 0 10px 25px -5px rgba(243,156,18,0.3);
        }
        
        /* Cards */
        .card {
            border: none;
            border-radius: 24px;
            box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            font-size: 1rem;
            color: #1e293b;
        }
        
        .card-header i {
            color: var(--primary);
            font-size: 1.2rem;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            text-align: center;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.15);
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            line-height: 1.2;
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Form Styles */
        .form-label {
            font-weight: 600;
            font-size: 0.8rem;
            color: #475569;
            margin-bottom: 0.4rem;
        }
        
        .form-control, .form-select {
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding: 0.6rem 1rem;
            transition: all 0.2s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary);
            background: transparent;
            color: var(--primary);
            font-weight: 600;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-1px);
        }
        
        /* Alert */
        .alert-custom {
            border-radius: 16px;
            border: none;
            padding: 1rem 1.25rem;
        }
        
        /* Asset Item */
        .asset-item {
            background: #f8fafc;
            border-radius: 16px;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            transition: all 0.2s ease;
        }
        
        .asset-item:hover {
            background: #fefce8;
            transform: translateX(5px);
        }
        
        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-available { background: #d4f8e8; color: #10b981; }
        .status-in_use { background: #dbeafe; color: #3b82f6; }
        .status-maintenance { background: #fed7aa; color: #f59e0b; }
        .status-retired { background: #fee2e2; color: #ef4444; }
        .status-lost { background: #f3e8ff; color: #8b5cf6; }
        
        /* Switch Toggle */
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #cbd5e1;
            transition: 0.3s;
            border-radius: 34px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.3s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background: var(--primary-gradient);
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        
        /* Responsive */
        @media (max-width: 768px) { 
            .main-content { 
                padding: 16px; 
                margin-top: 70px;
            }
            .profile-header {
                text-align: center;
            }
            .profile-avatar {
                margin: 0 auto 1rem;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
            .stat-value {
                font-size: 1.5rem;
            }
        }
        
        @media (max-width: 576px) {
            .notifications-dropdown {
                width: 300px;
                right: -80px !important;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .main-content {
            animation: fadeIn 0.4s ease-out;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php"><i class="bi bi-laptop me-1"></i> Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="assets.php"><i class="bi bi-box-seam me-1"></i> Assets</a></li>
                    <li class="nav-item"><a class="nav-link" href="tickets.php"><i class="bi bi-ticket-detailed me-1"></i> Tickets</a></li>
                    <li class="nav-item"><a class="nav-link" href="technicians.php"><i class="bi bi-people me-1"></i> Technicians</a></li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header d-flex justify-content-between align-items-center">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <?php if ($unreadCount > 0): ?>
                                    <button class="btn btn-sm btn-link text-decoration-none" onclick="markAllAsRead()" style="color: var(--primary);">
                                        Mark all as read
                                    </button>
                                <?php endif; ?>
                            </div>
                            <div id="notificationsList">
                                <?php if (empty($notifications)): ?>
                                    <div class="text-center py-5 text-muted">
                                        <i class="bi bi-bell-slash fs-1 d-block mb-2"></i>
                                        <small>No notifications yet</small>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($notifications as $notification): ?>
                                        <div class="notification-item <?= $notification['is_read'] ? '' : 'unread' ?>" data-id="<?= $notification['id'] ?>">
                                            <div class="d-flex gap-3">
                                                <div class="notification-icon" style="background: #fed7aa; color: #f59e0b;">
                                                    <i class="bi bi-info-circle"></i>
                                                </div>
                                                <div class="notification-content">
                                                    <div class="notification-title"><?= htmlspecialchars($notification['title']) ?></div>
                                                    <div class="notification-message"><?= htmlspecialchars($notification['message']) ?></div>
                                                    <div class="notification-time">
                                                        <?= timeAgo(strtotime($notification['created_at'])) ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="#" class="text-decoration-none small" style="color: var(--primary);">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? $user['username'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#notificationsModal"><i class="bi bi-bell me-2"></i> Notifications <?php if ($unreadCount > 0): ?><span class="badge bg-danger ms-1"><?= $unreadCount ?></span><?php endif; ?></a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Notifications Modal -->
    <div class="modal fade" id="notificationsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-bell me-2"></i> Notifications
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="list-group list-group-flush" id="modalNotificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="text-center py-5 text-muted">
                                <i class="bi bi-bell-slash fs-1 d-block mb-2"></i>
                                <p>No notifications yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notification): ?>
                                <div class="list-group-item notification-item-modal <?= $notification['is_read'] ? '' : 'unread' ?>" data-id="<?= $notification['id'] ?>">
                                    <div class="d-flex gap-3">
                                        <div class="notification-icon" style="background: #fed7aa; color: #f59e0b;">
                                            <i class="bi bi-info-circle"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="fw-semibold"><?= htmlspecialchars($notification['title']) ?></div>
                                            <div class="small text-muted"><?= htmlspecialchars($notification['message']) ?></div>
                                            <div class="small text-muted mt-1">
                                                <?= timeAgo(strtotime($notification['created_at'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if ($unreadCount > 0): ?>
                        <button type="button" class="btn btn-outline-primary" onclick="markAllAsRead()">
                            <i class="bi bi-check2-all"></i> Mark all as read
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <!-- Alert Messages -->
        <?php if ($message): ?>
            <div class="alert alert-success alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Profile Header -->
        <div class="profile-header">
            <div class="row align-items-center">
                <div class="col-md-2 text-center text-md-start">
                    <div class="profile-avatar mx-auto mx-md-0">
                        <i class="bi bi-person-fill"></i>
                    </div>
                </div>
                <div class="col-md-6 text-center text-md-start mt-3 mt-md-0">
                    <h3 class="mb-1"><?= htmlspecialchars($user['username'] ?? 'User') ?></h3>
                    <p class="text-muted mb-2">
                        <i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($user['email'] ?? '') ?>
                        <?php if (!empty($user['contact'])): ?>
                            <span class="mx-2">•</span>
                            <i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($user['contact']) ?>
                        <?php endif; ?>
                    </p>
                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">
                        <i class="bi bi-person-badge me-1"></i> <?= ucfirst(str_replace('_', ' ', $user['user_type'] ?? 'Staff')) ?>
                    </span>
                    <?php if (!empty($user['role'])): ?>
                        <span class="badge bg-warning bg-opacity-10 text-warning px-3 py-2 rounded-pill ms-2">
                            <i class="bi bi-building me-1"></i> <?= htmlspecialchars($user['role']) ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-md-4 text-center text-md-end mt-3 mt-md-0">
                    <small class="text-muted d-block">
                        <i class="bi bi-calendar3 me-1"></i> Member since <?= date('M Y', strtotime($user['created_at'] ?? 'now')) ?>
                    </small>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Stats Cards -->
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-value"><?= $stats['total_tickets'] ?></div>
                    <div class="stat-label">Total Tickets</div>
                    <div class="mt-2 small text-muted">
                        <span class="text-warning"><?= $stats['open_tickets'] ?> open</span> | 
                        <span class="text-success"><?= $stats['resolved_tickets'] ?> resolved</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-value"><?= count($assets) ?></div>
                    <div class="stat-label">Assigned Assets</div>
                    <div class="mt-2 small text-muted">
                        <i class="bi bi-box-seam"></i> Currently in your possession
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-value"><?= $unreadCount ?></div>
                    <div class="stat-label">Unread Notifications</div>
                    <div class="mt-2 small text-muted">
                        <i class="bi bi-bell"></i> Stay updated
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-2">
            <!-- Profile Information -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-person-circle me-2"></i> Profile Information
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="full_name" value="<?= htmlspecialchars($user['username'] ?? '') ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" name="phone" value="<?= htmlspecialchars($user['contact'] ?? '') ?>" placeholder="+27 XX XXX XXXX">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save"></i> Save Changes
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Change Password -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-shield-lock me-2"></i> Change Password
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="mb-3">
                                <label class="form-label">Current Password</label>
                                <input type="password" class="form-control" name="current_password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" class="form-control" name="new_password" required>
                                <small class="text-muted">Minimum 6 characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                            
                            <button type="submit" class="btn btn-outline-primary">
                                <i class="bi bi-key"></i> Update Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Preferences -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-sliders2 me-2"></i> Preferences
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="update_preferences">
                            
                            <div class="mb-3">
                                <label class="form-label">Theme</label>
                                <select class="form-select" name="theme">
                                    <option value="light" <?= $theme == 'light' ? 'selected' : '' ?>>🌞 Light Mode</option>
                                    <option value="dark" <?= $theme == 'dark' ? 'selected' : '' ?>>🌙 Dark Mode</option>
                                    <option value="auto" <?= $theme == 'auto' ? 'selected' : '' ?>>🔄 Auto (System)</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <label class="form-label mb-0">Email Notifications</label>
                                        <div class="small text-muted">Receive notifications via email</div>
                                    </div>
                                    <label class="switch">
                                        <input type="checkbox" name="notifications_email" value="1" <?= $notifications_email ? 'checked' : '' ?>>
                                        <span class="slider"></span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <label class="form-label mb-0">Browser Notifications</label>
                                        <div class="small text-muted">Receive popup notifications</div>
                                    </div>
                                    <label class="switch">
                                        <input type="checkbox" name="notifications_browser" value="1" <?= $notifications_browser ? 'checked' : '' ?>>
                                        <span class="slider"></span>
                                    </label>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save"></i> Save Preferences
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Assigned Assets -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-box-seam me-2"></i> My Assigned Assets
                    </div>
                    <div class="card-body">
                        <?php if (empty($assets)): ?>
                            <div class="text-center py-4 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                <p>No assets assigned to you</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($assets as $asset): ?>
                                <div class="asset-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= htmlspecialchars($asset['name']) ?></strong><br>
                                        <small class="text-muted">Tag: <?= htmlspecialchars($asset['asset_tag']) ?></small>
                                    </div>
                                    <span class="status-badge status-<?= $asset['status'] ?>">
                                        <?= ucfirst(str_replace('_', ' ', $asset['status'])) ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
    </script>
</body>
</html>