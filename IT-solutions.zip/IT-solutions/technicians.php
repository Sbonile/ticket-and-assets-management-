<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Check if user is admin (only admins can manage technicians)
$isAdmin = ($_SESSION['role'] === 'admin' || $_SESSION['user_type'] === 'admin');

if (!$isAdmin) {
    header("Location: dashboard.php");
    exit();
}

// Get all technicians
$technicians = [];
try {
    $stmt = $pdo->query("
        SELECT t.*, 
               u.user_type, u.department_code, u.department_name, u.status as user_status,
               (SELECT COUNT(*) FROM tickets WHERE assigned_technician_id = t.id AND status IN ('pending', 'in_progress')) as current_jobs,
               (SELECT COUNT(*) FROM tickets WHERE assigned_technician_id = t.id AND status = 'resolved') as total_tickets_resolved
        FROM technicians t
        LEFT JOIN users u ON t.user_id = u.id
        ORDER BY FIELD(t.status, 'available', 'busy', 'offline', 'on_leave'), t.name
    ");
    $technicians = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to fetch technicians: ' . $e->getMessage();
}

// Statistics
$total_techs = count($technicians);
$available_techs = count(array_filter($technicians, fn($t) => $t['status'] == 'available' && !$t['on_leave']));
$busy_techs = count(array_filter($technicians, fn($t) => $t['status'] == 'busy'));
$on_leave_techs = count(array_filter($technicians, fn($t) => $t['on_leave'] == 1));

// Get unread notifications count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$_SESSION['user_id']]);
$unreadCount = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Management | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }
        
        .navbar { 
            background: var(--primary-gradient);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand { 
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }
        
        .navbar-brand i {
            font-size: 1.6rem;
        }
        
        .navbar-brand:hover {
            color: white;
        }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            margin: 0 2px;
        }
        
        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
            font-weight: 600;
        }
        
        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }
        
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: var(--radius-md);
            border: none;
            box-shadow: var(--shadow-lg);
            padding: 0;
        }
        
        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background: white;
            z-index: 1;
        }
        
        .notifications-header h6 {
            margin: 0;
            font-weight: 600;
        }
        
        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid var(--border);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .notification-item:hover {
            background: #fefce8;
        }
        
        .notification-item.unread {
            background: #fffbeb;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            background: #fed7aa;
            color: var(--warning);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        .notification-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 4px;
        }
        
        .notification-message {
            font-size: 0.75rem;
            color: var(--gray);
            margin-bottom: 4px;
        }
        
        .notification-time {
            font-size: 0.65rem;
            color: #94a3b8;
        }
        
        .main-content { 
            margin-top: 80px; 
            padding: 24px 28px;
            animation: fadeIn 0.4s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            line-height: 1.2;
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--gray);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Main Card */
        .main-card {
            background: white;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            border: none;
        }
        
        .card-header-custom {
            background: white;
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .card-header-custom h5 {
            font-weight: 700;
            color: var(--dark);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-header-custom h5 i {
            color: var(--primary);
            font-size: 1.4rem;
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary);
            background: transparent;
            color: var(--primary);
            font-weight: 600;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }
        
        /* Technician Grid */
        .tech-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }
        
        .tech-card {
            background: white;
            border-radius: var(--radius-lg);
            transition: all 0.3s ease;
            border: 1px solid var(--border);
            overflow: hidden;
            position: relative;
        }
        
        .tech-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        
        .tech-card-header {
            padding: 1.25rem 1.25rem 0.75rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
        
        .tech-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .tech-avatar {
            width: 52px;
            height: 52px;
            border-radius: var(--radius-md);
            background: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary);
        }
        
        .tech-name {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--dark);
            margin-bottom: 4px;
        }
        
        .tech-email {
            font-size: 0.7rem;
            color: var(--gray);
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .tech-department {
            font-size: 0.65rem;
            color: var(--primary);
            background: var(--primary-light);
            display: inline-block;
            padding: 2px 8px;
            border-radius: 20px;
            margin-top: 4px;
        }
        
        /* Status Styles */
        .tech-status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 6px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.6; }
            100% { opacity: 1; }
        }
        
        .status-available { background: var(--success); box-shadow: 0 0 8px var(--success); }
        .status-busy { background: var(--danger); box-shadow: 0 0 8px var(--danger); }
        .status-offline { background: var(--gray); }
        .status-on_leave { background: var(--warning); box-shadow: 0 0 8px var(--warning); }
        
        .status-badge-custom {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .badge-available { background: #d4f8e8; color: #065f46; }
        .badge-busy { background: #fee2e2; color: #991b1b; }
        .badge-offline { background: #f1f5f9; color: #475569; }
        .badge-on_leave { background: #fed7aa; color: #9b2c1d; }
        
        /* Stats Section */
        .tech-stats {
            padding: 0.75rem 1.25rem;
            display: flex;
            gap: 1rem;
            border-top: 1px solid var(--border);
            border-bottom: 1px solid var(--border);
            background: #fafbfc;
        }
        
        .stat-item {
            flex: 1;
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--dark);
        }
        
        .stat-label-small {
            font-size: 0.6rem;
            color: var(--gray);
            font-weight: 500;
            text-transform: uppercase;
        }
        
        /* Actions */
        .tech-actions {
            padding: 0.75rem 1.25rem;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            flex: 1;
            padding: 0.4rem 0.5rem;
            border-radius: var(--radius-sm);
            font-size: 0.7rem;
            font-weight: 500;
            transition: all 0.2s ease;
            border: none;
            background: #f1f5f9;
            color: #475569;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        
        .action-btn:hover {
            transform: translateY(-1px);
        }
        
        .action-btn-primary {
            background: var(--primary-light);
            color: var(--primary);
        }
        
        .action-btn-primary:hover {
            background: var(--primary);
            color: white;
        }
        
        .action-btn-danger {
            background: #fee2e2;
            color: var(--danger);
        }
        
        .action-btn-danger:hover {
            background: var(--danger);
            color: white;
        }
        
        .action-btn-warning {
            background: #fed7aa;
            color: var(--warning);
        }
        
        .action-btn-warning:hover {
            background: var(--warning);
            color: white;
        }
        
        .action-btn-success {
            background: #d4f8e8;
            color: var(--success);
        }
        
        .action-btn-success:hover {
            background: var(--success);
            color: white;
        }
        
        /* Dropdown */
        .dropdown-menu {
            border-radius: var(--radius-md);
            border: none;
            box-shadow: var(--shadow-lg);
            padding: 0.5rem;
        }
        
        .dropdown-item {
            border-radius: var(--radius-sm);
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .dropdown-item:hover {
            background: var(--primary-light);
        }
        
        /* Modals */
        .modal-content {
            border-radius: var(--radius-lg);
            border: none;
            overflow: hidden;
        }
        
        .modal-header {
            background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%);
            border-bottom: 1px solid #fde68a;
            padding: 1.25rem 1.5rem;
        }
        
        .modal-header h5 {
            font-weight: 700;
            color: #92400e;
        }
        
        .form-label {
            font-weight: 600;
            font-size: 0.8rem;
            color: #475569;
            margin-bottom: 0.4rem;
        }
        
        .form-control, .form-select {
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            padding: 0.6rem 1rem;
            transition: all 0.2s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }
        
        .alert-custom {
            border-radius: var(--radius-md);
            border: none;
            padding: 0.75rem 1rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .toast-container {
            position: fixed;
            top: 90px;
            right: 20px;
            z-index: 1100;
        }
        
        /* Responsive */
        @media (max-width: 768px) { 
            .main-content { 
                padding: 16px; 
                margin-top: 70px;
            }
            .tech-grid {
                grid-template-columns: 1fr;
            }
            .stat-value {
                font-size: 1.5rem;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
        }
        
        @media (max-width: 576px) {
            .stat-card {
                text-align: center;
            }
            .stat-icon {
                margin: 0 auto 10px;
            }
            .notifications-dropdown {
                width: 300px;
                right: -80px !important;
            }
        }
        
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php"><i class="bi bi-laptop me-1"></i> Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="assets.php"><i class="bi bi-box-seam me-1"></i> Assets</a></li>
                    <li class="nav-item"><a class="nav-link" href="tickets.php"><i class="bi bi-ticket-detailed me-1"></i> Tickets</a></li>
                    <li class="nav-item"><a class="nav-link active" href="technicians.php"><i class="bi bi-people me-1"></i> Technicians</a></li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Toast Container for notifications -->
    <div class="toast-container"></div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='technicians.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $total_techs ?></div>
                            <div class="stat-label">Total Technicians</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='technicians.php?status=available'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-success"><?= $available_techs ?></div>
                            <div class="stat-label">Available</div>
                        </div>
                        <div class="stat-icon" style="background: #d4f8e8; color: var(--success);">
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='technicians.php?status=busy'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-danger"><?= $busy_techs ?></div>
                            <div class="stat-label">Busy</div>
                        </div>
                        <div class="stat-icon" style="background: #fee2e2; color: var(--danger);">
                            <i class="bi bi-exclamation-circle-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='technicians.php?leave=on'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-warning"><?= $on_leave_techs ?></div>
                            <div class="stat-label">On Leave</div>
                        </div>
                        <div class="stat-icon" style="background: #fed7aa; color: var(--warning);">
                            <i class="bi bi-airplane-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Technicians List -->
        <div class="main-card">
            <div class="card-header-custom">
                <h5>
                    <i class="bi bi-people"></i>
                    Technician Team
                </h5>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTechnicianModal">
                    <i class="bi bi-person-plus"></i> Add Technician
                </button>
            </div>
            <div class="card-body p-4">
                <?php if (empty($technicians)): ?>
                    <div class="empty-state">
                        <i class="bi bi-people"></i>
                        <p class="mb-0">No technicians found. Click "Add Technician" to get started.</p>
                    </div>
                <?php else: ?>
                    <div class="tech-grid">
                        <?php foreach ($technicians as $tech): 
                            $statusClass = '';
                            $statusBadge = '';
                            if ($tech['status'] == 'available') {
                                $statusClass = 'status-available';
                                $statusBadge = 'badge-available';
                            } elseif ($tech['status'] == 'busy') {
                                $statusClass = 'status-busy';
                                $statusBadge = 'badge-busy';
                            } elseif ($tech['status'] == 'offline') {
                                $statusClass = 'status-offline';
                                $statusBadge = 'badge-offline';
                            } elseif ($tech['status'] == 'on_leave') {
                                $statusClass = 'status-on_leave';
                                $statusBadge = 'badge-on_leave';
                            }
                        ?>
                            <div class="tech-card" data-tech-id="<?= $tech['id'] ?>">
                                <div class="tech-card-header">
                                    <div class="tech-info">
                                        <div class="tech-avatar">
                                            <i class="bi bi-person-badge"></i>
                                        </div>
                                        <div>
                                            <div class="tech-name"><?= htmlspecialchars($tech['name']) ?></div>
                                            <div class="tech-email">
                                                <i class="bi bi-envelope"></i>
                                                <?= htmlspecialchars($tech['email']) ?>
                                            </div>
                                            <?php if ($tech['department_name']): ?>
                                                <div class="tech-department">
                                                    <i class="bi bi-building"></i> <?= htmlspecialchars($tech['department_name']) ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-link text-dark p-0" data-bs-toggle="dropdown">
                                            <i class="bi bi-three-dots-vertical fs-5"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="#" onclick="editTechnician(<?= htmlspecialchars(json_encode($tech)) ?>)">
                                                <i class="bi bi-pencil"></i> Edit Details
                                            </a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item" href="#" onclick="updateStatus(<?= $tech['id'] ?>, 'available')">
                                                <i class="bi bi-check-circle text-success"></i> Set Available
                                            </a></li>
                                            <li><a class="dropdown-item" href="#" onclick="updateStatus(<?= $tech['id'] ?>, 'busy')">
                                                <i class="bi bi-exclamation-circle text-danger"></i> Set Busy
                                            </a></li>
                                            <li><a class="dropdown-item" href="#" onclick="updateStatus(<?= $tech['id'] ?>, 'offline')">
                                                <i class="bi bi-circle text-secondary"></i> Set Offline
                                            </a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item text-danger" href="#" onclick="deleteTechnician(<?= $tech['id'] ?>, '<?= htmlspecialchars($tech['name']) ?>')">
                                                <i class="bi bi-trash"></i> Delete
                                            </a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="tech-stats">
                                    <div class="stat-item">
                                        <div class="stat-number"><?= $tech['max_tickets'] ?></div>
                                        <div class="stat-label-small">Max Tickets</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-number text-warning"><?= $tech['current_jobs'] ?? 0 ?></div>
                                        <div class="stat-label-small">Current Jobs</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-number text-success"><?= $tech['total_tickets_resolved'] ?? 0 ?></div>
                                        <div class="stat-label-small">Resolved</div>
                                    </div>
                                </div>
                                
                                <div class="tech-actions">
                                    <span class="status-badge-custom <?= $statusBadge ?>">
                                        <span class="tech-status-dot <?= $statusClass ?>"></span>
                                        <?= ucfirst(str_replace('_', ' ', $tech['status'])) ?>
                                        <?php if ($tech['on_leave']): ?>
                                            <span class="ms-1">(On Leave)</span>
                                        <?php endif; ?>
                                    </span>
                                    <?php if (!$tech['on_leave']): ?>
                                        <button class="action-btn action-btn-warning" onclick="toggleLeave(<?= $tech['id'] ?>)">
                                            <i class="bi bi-airplane"></i> Leave
                                        </button>
                                    <?php else: ?>
                                        <button class="action-btn action-btn-success" onclick="toggleLeave(<?= $tech['id'] ?>)">
                                            <i class="bi bi-house-door"></i> Return
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Technician Modal -->
    <div class="modal fade" id="addTechnicianModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-person-plus me-2"></i> Add New Technician
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="add_name" placeholder="e.g., John Doe" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="add_email" placeholder="e.g., john@itsolutions.com" required>
                        <small class="text-muted">Used for login and notifications. Default password: <code>password123</code></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="add_phone" placeholder="e.g., +27 12 345 6789">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Department</label>
                        <select class="form-select" id="add_department">
                            <option value="IT">Information Technology</option>
                            <option value="HR">Human Resources</option>
                            <option value="FIN">Finance</option>
                            <option value="OPS">Operations</option>
                            <option value="MKT">Marketing</option>
                            <option value="SALES">Sales</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Max Concurrent Tickets</label>
                        <input type="number" class="form-control" id="add_max_tickets" value="5" min="1" max="20">
                        <small class="text-muted">Maximum number of tickets this technician can handle simultaneously</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="addTechnician()">Add Technician</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Technician Modal -->
    <div class="modal fade" id="editTechnicianModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-pencil me-2"></i> Edit Technician
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="edit_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="edit_email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="edit_phone">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="edit_status">
                            <option value="available">Available</option>
                            <option value="busy">Busy</option>
                            <option value="offline">Offline</option>
                            <option value="on_leave">On Leave</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Max Concurrent Tickets</label>
                        <input type="number" class="form-control" id="edit_max_tickets" min="1" max="20">
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="edit_on_leave">
                        <label class="form-check-label" for="edit_on_leave">On Leave</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveTechnicianEdit()">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Notification System
        let notificationPollingInterval = null;
        
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon">
                                <i class="bi bi-bell"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title">${escapeHtml(notif.title)}</div>
                                <div class="notification-message">${escapeHtml(notif.message)}</div>
                                <div class="notification-time">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function startNotificationPolling() {
            if (notificationPollingInterval) clearInterval(notificationPollingInterval);
            notificationPollingInterval = setInterval(() => {
                fetch('api/notifications.php?action=get_count')
                    .then(r => r.json())
                    .then(data => {
                        if (data.success && data.unread_count > 0) {
                            const bellBadge = document.querySelector('.notification-badge');
                            if (bellBadge) {
                                bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                                bellBadge.style.display = 'flex';
                            }
                        }
                    })
                    .catch(err => console.error('Error checking notifications:', err));
            }, 30000);
        }
        
        function showToast(message, type = 'success') {
            const toastContainer = document.querySelector('.toast-container');
            const toastId = 'toast-' + Date.now();
            const bgClass = type === 'success' ? 'bg-success' : 'bg-danger';
            const icon = type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill';
            
            const toastHtml = `
                <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0 mb-2" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="bi ${icon} me-2"></i> ${escapeHtml(message)}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                </div>
            `;
            
            toastContainer.insertAdjacentHTML('beforeend', toastHtml);
            const toastElement = document.getElementById(toastId);
            const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
            toast.show();
            
            toastElement.addEventListener('hidden.bs.toast', () => {
                toastElement.remove();
            });
        }
        
        // Technician Management Functions
        function updateStatus(technicianId, status) {
            if (confirm(`Set technician status to ${status.toUpperCase()}?`)) {
                fetch('api/technicians.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=update_status&id=${technicianId}&status=${status}`
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('Status updated successfully!', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showToast(data.error || 'Failed to update status', 'danger');
                    }
                })
                .catch(err => {
                    console.error('Error:', err);
                    showToast('Failed to update status', 'danger');
                });
            }
        }
        
        function toggleLeave(technicianId) {
            fetch('api/technicians.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=toggle_leave&id=${technicianId}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Leave status toggled successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Failed to toggle leave status', 'danger');
                }
            })
            .catch(err => {
                console.error('Error:', err);
                showToast('Failed to toggle leave status', 'danger');
            });
        }
        
        function deleteTechnician(technicianId, technicianName) {
            if (confirm(`Are you sure you want to delete "${technicianName}"? This will also deactivate their user account.`)) {
                fetch('api/technicians.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=delete&id=${technicianId}`
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('Technician deleted successfully!', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showToast(data.error || 'Failed to delete technician', 'danger');
                    }
                })
                .catch(err => {
                    console.error('Error:', err);
                    showToast('Failed to delete technician', 'danger');
                });
            }
        }
        
        function addTechnician() {
            const name = document.getElementById('add_name').value.trim();
            const email = document.getElementById('add_email').value.trim();
            const phone = document.getElementById('add_phone').value.trim();
            const department = document.getElementById('add_department').value;
            const maxTickets = document.getElementById('add_max_tickets').value;
            
            if (!name || !email) {
                showToast('Please fill in all required fields.', 'danger');
                return;
            }
            
            // Get department name
            const departmentMap = {
                'IT': 'Information Technology',
                'HR': 'Human Resources',
                'FIN': 'Finance',
                'OPS': 'Operations',
                'MKT': 'Marketing',
                'SALES': 'Sales'
            };
            
            fetch('api/technicians.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=add&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&department_code=${department}&department_name=${encodeURIComponent(departmentMap[department])}&max_tickets=${maxTickets}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Technician added successfully! Default password: password123', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Failed to add technician', 'danger');
                }
            })
            .catch(err => {
                console.error('Error:', err);
                showToast('Failed to add technician', 'danger');
            });
        }
        
        function editTechnician(tech) {
            document.getElementById('edit_id').value = tech.id;
            document.getElementById('edit_name').value = tech.name;
            document.getElementById('edit_email').value = tech.email;
            document.getElementById('edit_phone').value = tech.phone || '';
            document.getElementById('edit_status').value = tech.status;
            document.getElementById('edit_max_tickets').value = tech.max_tickets;
            document.getElementById('edit_on_leave').checked = tech.on_leave == 1;
            new bootstrap.Modal(document.getElementById('editTechnicianModal')).show();
        }
        
        function saveTechnicianEdit() {
            const id = document.getElementById('edit_id').value;
            const name = document.getElementById('edit_name').value.trim();
            const email = document.getElementById('edit_email').value.trim();
            const phone = document.getElementById('edit_phone').value.trim();
            const status = document.getElementById('edit_status').value;
            const maxTickets = document.getElementById('edit_max_tickets').value;
            const onLeave = document.getElementById('edit_on_leave').checked ? 1 : 0;
            
            if (!name || !email) {
                showToast('Please fill in all required fields.', 'danger');
                return;
            }
            
            fetch('api/technicians.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=edit&id=${id}&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&status=${status}&max_tickets=${maxTickets}&on_leave=${onLeave}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Technician updated successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Failed to update technician', 'danger');
                }
            })
            .catch(err => {
                console.error('Error:', err);
                showToast('Failed to update technician', 'danger');
            });
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            startNotificationPolling();
        });
    </script>
</body>
</html>