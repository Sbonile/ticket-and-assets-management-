<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';
// ticket-assistance.php - Public IT Support Ticket System (FULLY FIXED)
// No login required - Public facing page
session_start();

// Database connection
$host = 'localhost';
$dbname = 'it_solutions_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed. Please try again later.");
}

// Create assistance_requests table if not exists (with proper structure)
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `assistance_requests` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_name` VARCHAR(100) NOT NULL,
            `user_email` VARCHAR(100) NOT NULL,
            `laptop_number` VARCHAR(50) DEFAULT NULL,
            `issue_type` VARCHAR(100) DEFAULT NULL,
            `description` TEXT NOT NULL,
            `status` VARCHAR(20) DEFAULT 'pending',
            `priority` VARCHAR(20) DEFAULT 'medium',
            `assigned_technician_id` INT(11) DEFAULT NULL,
            `public_notes` TEXT DEFAULT NULL,
            `resolved_at` TIMESTAMP NULL DEFAULT NULL,
            `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_status` (`status`),
            KEY `idx_email` (`user_email`),
            KEY `idx_priority` (`priority`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
} catch (PDOException $e) {
    // Table might already exist, ignore
}

// Create ticket_chat_messages table if not exists
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `ticket_chat_messages` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `ticket_id` INT(11) NOT NULL,
            `sender_type` ENUM('user', 'technician', 'admin') NOT NULL,
            `sender_name` VARCHAR(100) NOT NULL,
            `message` TEXT NOT NULL,
            `is_read` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_ticket_id` (`ticket_id`),
            KEY `idx_created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
} catch (PDOException $e) {
    // Table might already exist
}

// Generate CSRF token if not exists
if (empty($_SESSION['public_csrf_token'])) {
    $_SESSION['public_csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$alertType = '';
$submittedTicketId = null;

// Handle ticket submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['public_csrf_token']) {
        $message = 'Invalid security token. Please refresh the page.';
        $alertType = 'danger';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $laptop_number = !empty($_POST['laptop_number']) ? trim($_POST['laptop_number']) : null;
        $issue_type = $_POST['issue_type'] ?? '';
        $description = trim($_POST['description'] ?? '');
        
        // Validation
        if (empty($name) || empty($email) || empty($issue_type) || empty($description)) {
            $message = 'Please fill in all required fields.';
            $alertType = 'danger';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Please enter a valid email address.';
            $alertType = 'danger';
        } elseif (strlen($description) < 10) {
            $message = 'Please provide more details about your issue (at least 10 characters).';
            $alertType = 'danger';
        } else {
            try {
                // Insert into assistance_requests table - FIXED: match exact column names
                $stmt = $pdo->prepare("
                    INSERT INTO assistance_requests (
                        user_name, 
                        user_email, 
                        laptop_number, 
                        issue_type, 
                        description, 
                        status, 
                        priority, 
                        submitted_at
                    ) VALUES (?, ?, ?, ?, ?, 'pending', 'medium', NOW())
                ");
                $success = $stmt->execute([$name, $email, $laptop_number, $issue_type, $description]);
                
                if ($success) {
                    $submittedTicketId = $pdo->lastInsertId();
                    
                    // Add initial chat message
                    $stmt = $pdo->prepare("
                        INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, is_read, created_at) 
                        VALUES (?, 'user', ?, ?, 0, NOW())
                    ");
                    $stmt->execute([$submittedTicketId, $name, $description]);
                    
                    // Try to assign a technician automatically (round-robin)
                    try {
                        // Find available technician with least current tickets
                        $stmt = $pdo->prepare("
                            SELECT t.id, t.name, IFNULL(t.current_tickets, 0) as ticket_count 
                            FROM technicians t
                            WHERE t.status = 'available' AND (t.on_leave = 0 OR t.on_leave IS NULL)
                            ORDER BY ticket_count ASC, t.id ASC
                            LIMIT 1
                        ");
                        $stmt->execute();
                        $availableTech = $stmt->fetch();
                        
                        if ($availableTech) {
                            $stmt = $pdo->prepare("
                                UPDATE assistance_requests 
                                SET assigned_technician_id = ?, status = 'in_progress', updated_at = NOW()
                                WHERE id = ?
                            ");
                            $stmt->execute([$availableTech['id'], $submittedTicketId]);
                            
                            // Update technician's current tickets count
                            $stmt = $pdo->prepare("
                                UPDATE technicians 
                                SET current_tickets = IFNULL(current_tickets, 0) + 1 
                                WHERE id = ?
                            ");
                            $stmt->execute([$availableTech['id']]);
                            
                            // Add technician assignment message to chat
                            $stmt = $pdo->prepare("
                                INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, is_read, created_at) 
                                VALUES (?, 'admin', 'System', ?, 0, NOW())
                            ");
                            $stmt->execute([$submittedTicketId, "Your ticket has been assigned to {$availableTech['name']}. They will assist you shortly."]);
                        } else {
                            // Add waiting message
                            $stmt = $pdo->prepare("
                                INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, is_read, created_at) 
                                VALUES (?, 'admin', 'System', 'Your ticket has been received. A technician will be assigned to you as soon as one becomes available.', 0, NOW())
                            ");
                            $stmt->execute([$submittedTicketId]);
                        }
                    } catch (PDOException $e) {
                        // Technician assignment failed but ticket is still created
                        error_log("Technician assignment error: " . $e->getMessage());
                    }
                    
                    $message = 'Your support request has been submitted successfully! A technician will contact you shortly.';
                    $alertType = 'success';
                    
                    // Refresh CSRF token
                    $_SESSION['public_csrf_token'] = bin2hex(random_bytes(32));
                } else {
                    $message = 'Failed to submit request. Please try again.';
                    $alertType = 'danger';
                }
            } catch (PDOException $e) {
                error_log("Ticket submission error: " . $e->getMessage());
                $message = 'An error occurred: ' . $e->getMessage();
                $alertType = 'danger';
            }
        }
    }
}

// Get available devices (laptops) for dropdown
$devices = [];
try {
    $stmt = $pdo->query("SELECT device_number, device_name FROM devices WHERE status = 'available' ORDER BY device_number");
    $devices = $stmt->fetchAll();
} catch (PDOException $e) {
    // Table might not exist, ignore
}

// Get recent public announcements
$announcements = [];
try {
    $stmt = $pdo->query("
        SELECT * FROM announcements 
        WHERE is_active = 1 
        AND (expires_at IS NULL OR expires_at > NOW()) 
        ORDER BY created_at DESC 
        LIMIT 3
    ");
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    // Table might not exist
}

// Get ticket status counts for info display
$ticketStats = [];
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved
        FROM assistance_requests 
        WHERE submitted_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $ticketStats = $stmt->fetch();
} catch (PDOException $e) {
    $ticketStats = ['total' => 0, 'pending' => 0, 'in_progress' => 0, 'resolved' => 0];
}

// Get average response time
$avgResponseTime = 24;
try {
    $stmt = $pdo->query("
        SELECT AVG(TIMESTAMPDIFF(HOUR, submitted_at, updated_at)) as avg_hours
        FROM assistance_requests 
        WHERE status = 'resolved' AND updated_at IS NOT NULL
        AND submitted_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $result = $stmt->fetch();
    if ($result && $result['avg_hours'] && $result['avg_hours'] > 0) {
        $avgResponseTime = round($result['avg_hours']);
    }
} catch (PDOException $e) {
    // Use default
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta name="description" content="IT Support Ticket System - Submit your technical issues and get help from our support team">
    <title>IT Support | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: var(--primary-gradient);
            padding: 1rem 0;
            box-shadow: var(--shadow-md);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
            text-decoration: none;
            font-weight: 700;
            font-size: 1.4rem;
        }

        .header .logo i {
            font-size: 1.6rem;
        }

        .header .logo span {
            color: white;
        }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            color: white;
            padding: 3rem 0;
            text-align: center;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .hero-section p {
            font-size: 1.1rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Stats Bar */
        .stats-bar {
            background: white;
            padding: 1rem 0;
            box-shadow: var(--shadow-sm);
            margin-top: -2rem;
            margin-bottom: 2rem;
            border-radius: var(--radius-lg);
        }

        .stat-item-bar {
            text-align: center;
            padding: 0.5rem;
        }

        .stat-value-bar {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
        }

        .stat-label-bar {
            font-size: 0.7rem;
            color: var(--gray);
            text-transform: uppercase;
        }

        /* Main Content */
        .main-content {
            padding: 1rem 0 2rem;
        }

        /* Cards */
        .card {
            border: none;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--dark);
        }

        .card-header i {
            color: var(--primary);
            font-size: 1.2rem;
        }

        /* Form Styles */
        .form-label {
            font-weight: 600;
            font-size: 0.8rem;
            color: #475569;
            margin-bottom: 0.4rem;
        }

        .form-control, .form-select {
            border-radius: var(--radius-sm);
            border: 1px solid #e2e8f0;
            padding: 0.6rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }

        textarea.form-control {
            resize: vertical;
        }

        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }

        /* Alert */
        .alert-custom {
            border-radius: var(--radius-md);
            border: none;
            padding: 1rem 1.25rem;
        }

        /* Info Cards */
        .info-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
            height: 100%;
            border: 1px solid var(--border);
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .info-icon {
            width: 60px;
            height: 60px;
            background: var(--primary-light);
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
        }

        .info-icon i {
            font-size: 1.8rem;
            color: var(--primary);
        }

        .info-card h5 {
            font-weight: 700;
            margin-bottom: 0.75rem;
        }

        .info-card p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* FAQ Section */
        .faq-item {
            border-bottom: 1px solid var(--border);
            padding: 1rem 0;
            cursor: pointer;
        }

        .faq-item:last-child {
            border-bottom: none;
        }

        .faq-question {
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .faq-question i {
            transition: transform 0.3s ease;
        }

        .faq-answer {
            font-size: 0.85rem;
            color: var(--gray);
            padding-top: 0.5rem;
            display: none;
        }

        .faq-item.active .faq-answer {
            display: block;
        }

        .faq-item.active .faq-question i {
            transform: rotate(180deg);
        }

        /* Footer */
        .footer {
            background: #1e293b;
            color: #94a3b8;
            padding: 2rem 0;
            margin-top: 3rem;
        }

        .footer a {
            color: #94a3b8;
            text-decoration: none;
        }

        .footer a:hover {
            color: var(--primary);
        }

        /* Success Modal */
        .modal-content {
            border-radius: var(--radius-lg);
            border: none;
        }

        .modal-header {
            background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%);
            border-bottom: 1px solid #fde68a;
        }

        .modal-header h5 {
            font-weight: 700;
            color: #92400e;
        }

        .ticket-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            font-family: monospace;
        }

        /* Track Ticket Section */
        .track-ticket-card {
            background: var(--primary-light);
            border: none;
        }

        /* Loading Spinner */
        .spinner-border-sm {
            width: 1rem;
            height: 1rem;
            border-width: 0.15em;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 1.8rem;
            }
            .hero-section p {
                font-size: 0.9rem;
            }
            .main-content {
                padding: 1rem 0;
            }
            .stats-bar {
                margin-top: -1rem;
            }
            .stat-value-bar {
                font-size: 1rem;
            }
            .stat-label-bar {
                font-size: 0.6rem;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .main-content {
            animation: fadeIn 0.4s ease-out;
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <a href="ticket-assistance.php" class="logo">
                    <i class="bi bi-cpu"></i>
                    <span>IT Solutions</span>
                </a>
                <div>
                    <a href="index.php" class="text-white text-decoration-none me-3">
                        <i class="bi bi-box-arrow-in-right"></i> Staff Login
                    </a>
                    <a href="#" class="text-white text-decoration-none" data-bs-toggle="modal" data-bs-target="#trackTicketModal">
                        <i class="bi bi-search"></i> Track Ticket
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1><i class="bi bi-headset"></i> IT Support Center</h1>
            <p>Having technical issues? Submit a support ticket and our team will assist you promptly.</p>
        </div>
    </div>

    <!-- Stats Bar -->
    <?php if ($ticketStats && ($ticketStats['total'] > 0)): ?>
    <div class="container">
        <div class="stats-bar">
            <div class="row">
                <div class="col-4">
                    <div class="stat-item-bar">
                        <div class="stat-value-bar"><?= number_format($ticketStats['total'] ?? 0) ?></div>
                        <div class="stat-label-bar">Tickets (30 days)</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-item-bar">
                        <div class="stat-value-bar text-warning"><?= number_format(($ticketStats['pending'] ?? 0) + ($ticketStats['in_progress'] ?? 0)) ?></div>
                        <div class="stat-label-bar">Active Tickets</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-item-bar">
                        <div class="stat-value-bar text-success"><?= $avgResponseTime ?>h</div>
                        <div class="stat-label-bar">Avg Response Time</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <?php if ($message): ?>
                <div class="alert alert-<?= $alertType ?> alert-custom alert-dismissible fade show mb-4" role="alert">
                    <i class="bi bi-<?= $alertType === 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill' ?> me-2"></i>
                    <?= htmlspecialchars($message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- Ticket Form -->
                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-send me-2"></i> Submit Support Request
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" id="ticketForm">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['public_csrf_token'] ?>">
                                
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Your Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="name" id="name" placeholder="John Doe" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" name="email" id="email" placeholder="john@example.com" required>
                                        <small class="text-muted">We'll send updates to this email</small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Device Number (optional)</label>
                                        <select class="form-select" name="laptop_number" id="laptop_number">
                                            <option value="">-- Select Device --</option>
                                            <?php foreach ($devices as $device): ?>
                                                <option value="<?= htmlspecialchars($device['device_number']) ?>">
                                                    <?= htmlspecialchars($device['device_number']) ?> - <?= htmlspecialchars($device['device_name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Issue Type <span class="text-danger">*</span></label>
                                        <select class="form-select" name="issue_type" id="issue_type" required>
                                            <option value="">-- Select Issue Type --</option>
                                            <option value="Hardware Problem">🖥️ Hardware Problem</option>
                                            <option value="Software Issue">💻 Software Issue</option>
                                            <option value="Login Problems">🔑 Login Problems</option>
                                            <option value="Network Connection">📡 Network Connection</option>
                                            <option value="Battery/Power">🔋 Battery/Power</option>
                                            <option value="Printer Issue">🖨️ Printer Issue</option>
                                            <option value="Email Problem">📧 Email Problem</option>
                                            <option value="Virus/Malware">🛡️ Virus/Malware</option>
                                            <option value="Data Recovery">💾 Data Recovery</option>
                                            <option value="Other">❓ Other</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Describe Your Issue <span class="text-danger">*</span></label>
                                        <textarea class="form-control" name="description" id="description" rows="5" required
                                            placeholder="Please provide detailed information about your issue...

Please include:
• What happened?
• When did it happen?
• Any error messages?
• Steps to reproduce (if possible)"></textarea>
                                        <small class="text-muted">Minimum 10 characters. More details help us resolve faster!</small>
                                    </div>
                                </div>

                                <div class="mt-4">
                                    <button type="submit" name="submit_request" class="btn btn-primary w-100" id="submitBtn">
                                        <i class="bi bi-send-fill me-2"></i> Submit Support Request
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Info Sidebar -->
                <div class="col-lg-5">
                    <!-- Support Information -->
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-info-circle me-2"></i> Support Information
                        </div>
                        <div class="card-body">
                            <div class="info-card mb-3">
                                <div class="info-icon">
                                    <i class="bi bi-clock"></i>
                                </div>
                                <h5>Response Time</h5>
                                <p>We aim to respond to all tickets within <strong><?= $avgResponseTime ?> hours</strong> during business days.</p>
                            </div>

                            <div class="info-card mb-3">
                                <div class="info-icon">
                                    <i class="bi bi-telephone"></i>
                                </div>
                                <h5>Emergency Support</h5>
                                <p>For urgent issues, call us at: <strong>+27 10 880 3795</strong></p>
                                <small class="text-muted">Available Mon-Fri, 8am-5pm</small>
                            </div>

                            <div class="info-card">
                                <div class="info-icon">
                                    <i class="bi bi-envelope"></i>
                                </div>
                                <h5>Email Support</h5>
                                <p>You can also email us directly at: <strong>support@itsolutions.co.za</strong></p>
                            </div>
                        </div>
                    </div>

                    <!-- Track Ticket -->
                    <div class="card mt-4 track-ticket-card">
                        <div class="card-header">
                            <i class="bi bi-search me-2"></i> Track Your Ticket
                        </div>
                        <div class="card-body">
                            <p class="small text-muted mb-3">Have a ticket number? Check your status here.</p>
                            <div class="input-group">
                                <input type="number" class="form-control" id="trackTicketId" placeholder="Enter Ticket ID">
                                <button class="btn btn-primary" onclick="trackTicket()">Track</button>
                            </div>
                        </div>
                    </div>

                    <!-- Announcements -->
                    <?php if (!empty($announcements)): ?>
                    <div class="card mt-4">
                        <div class="card-header">
                            <i class="bi bi-megaphone me-2"></i> Announcements
                        </div>
                        <div class="card-body">
                            <?php foreach ($announcements as $announcement): ?>
                                <div class="mb-3 pb-3 border-bottom">
                                    <div class="fw-semibold"><?= htmlspecialchars($announcement['title']) ?></div>
                                    <div class="small text-muted"><?= nl2br(htmlspecialchars($announcement['content'])) ?></div>
                                    <div class="small text-muted mt-1">
                                        <i class="bi bi-calendar"></i> <?= date('M d, Y', strtotime($announcement['created_at'])) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- FAQ -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <i class="bi bi-question-circle me-2"></i> Frequently Asked Questions
                        </div>
                        <div class="card-body">
                            <div class="faq-item" onclick="toggleFaq(this)">
                                <div class="faq-question">
                                    How long until I get a response?
                                    <i class="bi bi-chevron-down"></i>
                                </div>
                                <div class="faq-answer">
                                    We aim to respond within <?= $avgResponseTime ?> hours during business days (Monday-Friday, 8am-5pm).
                                </div>
                            </div>
                            <div class="faq-item" onclick="toggleFaq(this)">
                                <div class="faq-question">
                                    Can I check my ticket status?
                                    <i class="bi bi-chevron-down"></i>
                                </div>
                                <div class="faq-answer">
                                    Yes! Use the "Track Your Ticket" section above and enter your ticket ID (the number you received after submission).
                                </div>
                            </div>
                            <div class="faq-item" onclick="toggleFaq(this)">
                                <div class="faq-question">
                                    What if my issue is urgent?
                                    <i class="bi bi-chevron-down"></i>
                                </div>
                                <div class="faq-answer">
                                    For urgent issues that cannot wait, please call our emergency support line at +27 10 880 3795.
                                </div>
                            </div>
                            <div class="faq-item" onclick="toggleFaq(this)">
                                <div class="faq-question">
                                    Is there a cost for support?
                                    <i class="bi bi-chevron-down"></i>
                                </div>
                                <div class="faq-answer">
                                    IT support is provided free of charge to all staff members. Hardware repairs may require approval from your department head.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-check-circle-fill text-success me-2"></i> Request Submitted!
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center py-4">
                    <i class="bi bi-ticket-detailed" style="font-size: 3rem; color: var(--primary);"></i>
                    <h4 class="mt-3">Thank You!</h4>
                    <p>Your support request has been submitted successfully.</p>
                    <?php if ($submittedTicketId): ?>
                    <div class="mt-3 p-3 bg-light rounded">
                        <small class="text-muted">Your Ticket ID</small>
                        <div class="ticket-number">#<?= str_pad($submittedTicketId, 6, '0', STR_PAD_LEFT) ?></div>
                        <small class="text-muted">Save this number to track your request</small>
                    </div>
                    <?php endif; ?>
                    <p class="text-muted small mt-3">A technician will review your issue and contact you shortly.</p>
                    <hr>
                    <div class="mt-3">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">
                            <i class="bi bi-check"></i> Got it, thanks!
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Track Ticket Modal -->
    <div class="modal fade" id="trackTicketModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-search me-2"></i> Track Ticket Status
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Enter Ticket ID</label>
                        <input type="number" class="form-control" id="trackTicketModalId" placeholder="e.g., 123456">
                    </div>
                    <div id="trackResult"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="trackTicketModal()">Track Ticket</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="bi bi-cpu"></i> IT Solutions</h5>
                    <p class="mb-0">Enterprise IT Management System</p>
                    <p class="small mt-2">&copy; <?= date('Y') ?> IT Solutions. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Contact</h5>
                    <p class="mb-0">
                        <i class="bi bi-envelope"></i> support@itsolutions.co.za<br>
                        <i class="bi bi-telephone"></i> +27 10 880 3795
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        <?php if ($submittedTicketId): ?>
        // Show success modal on successful submission
        document.addEventListener('DOMContentLoaded', function() {
            const successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();
            
            // Reset form
            const form = document.getElementById('ticketForm');
            if (form) {
                form.reset();
            }
        });
        <?php endif; ?>

        // FAQ Toggle
        function toggleFaq(element) {
            element.classList.toggle('active');
        }

        // Track Ticket functions
        function trackTicket() {
            const ticketId = document.getElementById('trackTicketId').value.trim();
            if (!ticketId) {
                alert('Please enter a ticket ID');
                return;
            }
            // Redirect to a ticket tracking page or show modal
            document.getElementById('trackTicketModalId').value = ticketId;
            const trackModal = new bootstrap.Modal(document.getElementById('trackTicketModal'));
            trackModal.show();
            trackTicketModal();
        }

        function trackTicketModal() {
            const ticketId = document.getElementById('trackTicketModalId').value.trim();
            const trackResult = document.getElementById('trackResult');
            
            if (!ticketId) {
                trackResult.innerHTML = '<div class="alert alert-danger">Please enter a ticket ID</div>';
                return;
            }

            trackResult.innerHTML = '<div class="text-center"><div class="spinner-border text-primary"></div><p class="mt-2">Checking status...</p></div>';

            fetch(`api/track-ticket.php?id=${encodeURIComponent(ticketId)}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        let statusClass = '';
                        let statusIcon = '';
                        let statusText = '';
                        switch(data.ticket.status) {
                            case 'pending':
                                statusClass = 'warning';
                                statusIcon = 'bi-hourglass-split';
                                statusText = 'Pending';
                                break;
                            case 'in_progress':
                                statusClass = 'info';
                                statusIcon = 'bi-gear';
                                statusText = 'In Progress';
                                break;
                            case 'resolved':
                                statusClass = 'success';
                                statusIcon = 'bi-check-circle';
                                statusText = 'Resolved';
                                break;
                            default:
                                statusClass = 'secondary';
                                statusIcon = 'bi-question-circle';
                                statusText = data.ticket.status || 'Unknown';
                        }
                        
                        trackResult.innerHTML = `
                            <div class="card mt-3">
                                <div class="card-body">
                                    <div class="text-center mb-3">
                                        <i class="bi ${statusIcon}" style="font-size: 2rem; color: var(--${statusClass});"></i>
                                    </div>
                                    <h6 class="text-center">Ticket #${String(data.ticket.id).padStart(6, '0')}</h6>
                                    <hr>
                                    <p><strong>Status:</strong> <span class="badge bg-${statusClass}">${statusText}</span></p>
                                    <p><strong>Issue:</strong> ${escapeHtml(data.ticket.issue_type || 'N/A')}</p>
                                    <p><strong>Submitted:</strong> ${new Date(data.ticket.submitted_at).toLocaleString()}</p>
                                    ${data.ticket.assigned_technician ? `<p><strong>Assigned to:</strong> ${escapeHtml(data.ticket.assigned_technician)}</p>` : '<p><strong>Assigned to:</strong> Not assigned yet</p>'}
                                    ${data.ticket.resolved_at ? `<p><strong>Resolved:</strong> ${new Date(data.ticket.resolved_at).toLocaleString()}</p>` : ''}
                                </div>
                            </div>
                        `;
                    } else {
                        trackResult.innerHTML = `<div class="alert alert-danger mt-3">${escapeHtml(data.error || 'Ticket not found')}</div>`;
                    }
                })
                .catch(err => {
                    console.error('Error:', err);
                    trackResult.innerHTML = '<div class="alert alert-danger mt-3">Failed to check ticket status. Please try again.</div>';
                });
        }

        // Form validation and submission handling
        document.getElementById('ticketForm')?.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const issueType = document.getElementById('issue_type').value;
            const description = document.getElementById('description').value.trim();
            
            // Client-side validation
            if (!name || !email || !issueType || !description) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return;
            }
            
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                return;
            }
            
            if (description.length < 10) {
                e.preventDefault();
                alert('Please provide more details about your issue (at least 10 characters).');
                return;
            }
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Submitting...';
        });
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>