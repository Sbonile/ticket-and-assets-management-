<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Get statistics
try {
    $totalDevices = $pdo->query("SELECT COUNT(*) FROM devices")->fetchColumn();
    $availableDevices = $pdo->query("SELECT COUNT(*) FROM devices WHERE status = 'available'")->fetchColumn();
    $inUseDevices = $pdo->query("SELECT COUNT(*) FROM devices WHERE status = 'in_use'")->fetchColumn();
    
    $totalAssets = $pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();
    $availableAssets = $pdo->query("SELECT COUNT(*) FROM assets WHERE status = 'available'")->fetchColumn();
    
    $openTickets = $pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('pending', 'in_progress')")->fetchColumn();
    $urgentTickets = $pdo->query("SELECT COUNT(*) FROM tickets WHERE priority = 'urgent' AND status != 'resolved'")->fetchColumn();
    
    $totalTechnicians = $pdo->query("SELECT COUNT(*) FROM technicians")->fetchColumn();
    $availableTechs = $pdo->query("SELECT COUNT(*) FROM technicians WHERE status = 'available'")->fetchColumn();
    
    // Get assets by category
    $assetsByCategory = $pdo->query("
        SELECT category, COUNT(*) as count 
        FROM assets 
        GROUP BY category
    ")->fetchAll();
    
    // Get expiring warranties
    $expiringWarranties = $pdo->query("
        SELECT * FROM assets 
        WHERE warranty_expiry IS NOT NULL 
        AND warranty_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
        ORDER BY warranty_expiry ASC
        LIMIT 5
    ")->fetchAll();
    
    // Get recent tickets
    $recentTickets = $pdo->query("
        SELECT t.*, tech.name as technician_name 
        FROM tickets t
        LEFT JOIN technicians tech ON t.assigned_technician_id = tech.id
        ORDER BY t.submitted_at DESC 
        LIMIT 5
    ")->fetchAll();
    
    // Get recent device activity
    $recentActivity = $pdo->query("
        SELECT dl.*, d.device_number, u.username 
        FROM device_logs dl
        JOIN devices d ON dl.device_id = d.id
        LEFT JOIN users u ON dl.user_id = u.id
        ORDER BY dl.created_at DESC
        LIMIT 5
    ")->fetchAll();
    
    // Get unread notifications count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$_SESSION['user_id']]);
    $unreadCount = $stmt->fetchColumn();
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }
        
        /* Modern Navbar */
        .navbar { 
            background: var(--primary-gradient);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand { 
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }
        
        .navbar-brand i {
            font-size: 1.6rem;
        }
        
        .navbar-brand:hover {
            color: white;
        }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            margin: 0 2px;
        }
        
        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
            font-weight: 600;
        }
        
        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }
        
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: var(--radius-md);
            border: none;
            box-shadow: var(--shadow-lg);
            padding: 0;
        }
        
        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background: white;
            z-index: 1;
        }
        
        .notifications-header h6 {
            margin: 0;
            font-weight: 600;
        }
        
        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid var(--border);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .notification-item:hover {
            background: #fefce8;
        }
        
        .notification-item.unread {
            background: #fffbeb;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            background: #fed7aa;
            color: var(--warning);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        .notification-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 4px;
        }
        
        .notification-message {
            font-size: 0.75rem;
            color: var(--gray);
            margin-bottom: 4px;
        }
        
        .notification-time {
            font-size: 0.65rem;
            color: #94a3b8;
        }
        
        /* Main Content */
        .main-content { 
            margin-top: 80px; 
            padding: 24px 28px;
        }
        
        /* Welcome Section */
        .welcome-section {
            margin-bottom: 1.5rem;
        }
        
        .welcome-section h2 {
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 0.25rem;
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            line-height: 1.2;
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--gray);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Main Cards */
        .card {
            border: none;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            font-size: 1rem;
            color: var(--dark);
        }
        
        .card-header i {
            color: var(--primary);
            font-size: 1.2rem;
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary);
            background: transparent;
            color: var(--primary);
            font-weight: 600;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }
        
        /* Table Styles */
        .table {
            margin-bottom: 0;
        }
        
        .table thead th {
            background: #f8fafc;
            color: var(--gray);
            font-weight: 600;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.875rem 1rem;
            border-bottom: 2px solid var(--border);
        }
        
        .table tbody td {
            padding: 0.875rem 1rem;
            vertical-align: middle;
            color: var(--dark);
            font-size: 0.85rem;
        }
        
        .table tbody tr {
            transition: all 0.2s ease;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #fefce8;
        }
        
        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fed7aa; color: #9b2c1d; }
        .status-in_progress { background: #dbeafe; color: #1e40af; }
        .status-resolved { background: #d4f8e8; color: #065f46; }
        
        .priority-urgent { background: #e74c3c; color: white; }
        .priority-high { background: #f59e0b; color: white; }
        .priority-medium { background: #3b82f6; color: white; }
        .priority-low { background: #10b981; color: white; }
        
        /* Quick Actions Section */
        .quick-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .quick-action-btn {
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius-md);
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            opacity: 0.5;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .main-content {
            animation: fadeIn 0.4s ease-out;
        }
        
        /* Responsive */
        @media (max-width: 768px) { 
            .main-content { 
                padding: 16px; 
                margin-top: 70px;
            }
            .stat-value {
                font-size: 1.5rem;
            }
            .quick-actions {
                flex-direction: column;
            }
            .quick-action-btn {
                justify-content: center;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
        }
        
        @media (max-width: 576px) {
            .stat-card {
                text-align: center;
            }
            .stat-icon {
                margin: 0 auto 10px;
            }
            .notifications-dropdown {
                width: 300px;
                right: -80px !important;
            }
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="devices.php">
                            <i class="bi bi-laptop me-1"></i> Devices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="assets.php">
                            <i class="bi bi-box-seam me-1"></i> Assets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="bi bi-ticket-detailed me-1"></i> Tickets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="technicians.php">
                            <i class="bi bi-people me-1"></i> Technicians
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h2>Welcome back, <?= htmlspecialchars($_SESSION['name']) ?>!</h2>
            <p class="text-muted">Here's what's happening with your IT infrastructure today.</p>
        </div>
        
        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='devices.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $totalDevices ?? 0 ?></div>
                            <div class="stat-label">Total Devices</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-laptop"></i>
                        </div>
                    </div>
                    <div class="mt-2 small text-muted">
                        <span class="text-success"><?= $availableDevices ?? 0 ?> available</span> | 
                        <span class="text-warning"><?= $inUseDevices ?? 0 ?> in use</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='assets.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $totalAssets ?? 0 ?></div>
                            <div class="stat-label">Total Assets</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                    <div class="mt-2 small text-muted">
                        <span class="text-success"><?= $availableAssets ?? 0 ?> available</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='tickets.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-danger"><?= $openTickets ?? 0 ?></div>
                            <div class="stat-label">Open Tickets</div>
                        </div>
                        <div class="stat-icon" style="background: #fee2e2; color: #ef4444;">
                            <i class="bi bi-ticket-detailed"></i>
                        </div>
                    </div>
                    <div class="mt-2 small text-muted">
                        <span class="text-danger"><?= $urgentTickets ?? 0 ?> urgent</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='technicians.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $availableTechs ?? 0 ?> / <?= $totalTechnicians ?? 0 ?></div>
                            <div class="stat-label">Techs Available</div>
                        </div>
                        <div class="stat-icon" style="background: #d4f8e8; color: #10b981;">
                            <i class="bi bi-people-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <i class="bi bi-pie-chart me-2"></i> Assets by Category
                    </div>
                    <div class="card-body d-flex justify-content-center">
                        <canvas id="categoryChart" height="220" style="max-width: 100%;"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <i class="bi bi-exclamation-triangle me-2"></i> Expiring Warranties
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Asset</th>
                                        <th>Warranty Expiry</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($expiringWarranties)): ?>
                                        <tr>
                                            <td colspan="3" class="empty-state">
                                                <i class="bi bi-check-circle"></i>
                                                <p class="mb-0">No warranties expiring soon</p>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($expiringWarranties as $asset): ?>
                                            <tr>
                                                <td>
                                                    <strong><?= htmlspecialchars($asset['name']) ?></strong><br>
                                                    <small class="text-muted"><?= htmlspecialchars($asset['asset_tag']) ?></small>
                                                </td>
                                                <td class="text-warning fw-semibold"><?= date('M d, Y', strtotime($asset['warranty_expiry'])) ?></td>
                                                <td><span class="badge bg-secondary"><?= ucfirst($asset['status']) ?></span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Tickets & Activity -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-ticket-detailed me-2"></i> Recent Support Tickets</span>
                        <a href="tickets.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-eye"></i> View All
                        </a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>User</th>
                                        <th>Issue</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Tech</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentTickets as $ticket): ?>
                                        <tr>
                                            <td class="fw-semibold">#<?= $ticket['id'] ?></td>
                                            <td><?= htmlspecialchars(substr($ticket['user_name'], 0, 20)) ?></td>
                                            <td><?= htmlspecialchars(substr($ticket['issue_type'] ?? 'Other', 0, 15)) ?></td>
                                            <td>
                                                <span class="badge priority-<?= $ticket['priority'] ?? 'medium' ?>">
                                                    <?= ucfirst($ticket['priority'] ?? 'Medium') ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?= $ticket['status'] ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                                </span>
                                            </td>
                                            <td><?= htmlspecialchars($ticket['technician_name'] ?? '—') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-clock-history me-2"></i> Recent Device Activity</span>
                        <a href="devices.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-gear"></i> Manage
                        </a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>User</th>
                                        <th>Device</th>
                                        <th>Action</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentActivity as $log): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($log['username'] ?? 'Unknown') ?></td>
                                            <td><code><?= htmlspecialchars($log['device_number']) ?></code></td>
                                            <td>
                                                <span class="badge bg-<?= $log['action_type'] == 'checked_out' ? 'warning' : 'success' ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $log['action_type'])) ?>
                                                </span>
                                            </td>
                                            <td><?= date('M d, H:i', strtotime($log['created_at'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-lightning-charge me-2"></i> Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="quick-actions">
                            <a href="devices.php" class="quick-action-btn btn-outline-primary">
                                <i class="bi bi-plus-circle"></i> Add Device
                            </a>
                            <a href="assets.php" class="quick-action-btn btn-outline-primary">
                                <i class="bi bi-box-seam"></i> Add Asset
                            </a>
                            <a href="technicians.php" class="quick-action-btn btn-outline-primary">
                                <i class="bi bi-person-plus"></i> Add Technician
                            </a>
                            <a href="tickets.php" class="quick-action-btn btn-outline-primary">
                                <i class="bi bi-ticket-detailed"></i> View Tickets
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Assets by Category Chart
        const categoryLabels = [<?php foreach ($assetsByCategory as $cat) { echo "'" . ucfirst($cat['category']) . "',"; } ?>];
        const categoryData = [<?php foreach ($assetsByCategory as $cat) { echo $cat['count'] . ","; } ?>];
        
        if (categoryLabels.length > 0) {
            const ctx = document.getElementById('categoryChart').getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: categoryLabels,
                    datasets: [{
                        data: categoryData,
                        backgroundColor: ['#f39c12', '#e67e22', '#f59e0b', '#10b981', '#ef4444', '#3b82f6'],
                        borderWidth: 0,
                        hoverOffset: 8
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: true, 
                    plugins: { 
                        legend: { 
                            position: 'bottom',
                            labels: {
                                font: { size: 11 },
                                padding: 10
                            }
                        },
                        tooltip: {
                            backgroundColor: '#1e293b',
                            titleColor: '#fff',
                            bodyColor: '#94a3b8',
                            padding: 10,
                            cornerRadius: 8
                        }
                    },
                    cutout: '60%'
                }
            });
        } else {
            const chartEl = document.getElementById('categoryChart');
            if (chartEl) {
                chartEl.style.display = 'none';
                const parent = chartEl.parentElement;
                if (parent) {
                    parent.innerHTML = '<div class="empty-state"><i class="bi bi-inbox"></i><p class="mb-0">No asset data available</p></div>';
                }
            }
        }
        
        // Notification System
        let notificationPollingInterval = null;
        let lastNotificationCheck = Date.now();
        
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon">
                                <i class="bi bi-bell"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title">${escapeHtml(notif.title)}</div>
                                <div class="notification-message">${escapeHtml(notif.message)}</div>
                                <div class="notification-time">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function startNotificationPolling() {
            if (notificationPollingInterval) clearInterval(notificationPollingInterval);
            notificationPollingInterval = setInterval(() => {
                fetch('api/notifications.php?action=get_count')
                    .then(r => r.json())
                    .then(data => {
                        if (data.success && data.unread_count > 0) {
                            const bellBadge = document.querySelector('.notification-badge');
                            if (bellBadge) {
                                bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                                bellBadge.style.display = 'flex';
                            }
                        }
                    })
                    .catch(err => console.error('Error checking notifications:', err));
            }, 30000);
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            startNotificationPolling();
        });
    </script>
</body>
</html>