<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

// Define database name if not defined in database.php
if (!defined('DB_NAME')) {
    define('DB_NAME', 'it_solutions_db');
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['user_type'] !== 'admin')) {
    header("Location: index.php");
    exit();
}

$success = '';
$error = '';
$active_tab = $_GET['tab'] ?? 'general';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $action = $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'update_general_settings':
                    $maintenance_mode = isset($_POST['maintenance_mode']) ? 'true' : 'false';
                    $registration_enabled = isset($_POST['registration_enabled']) ? 'true' : 'false';
                    $site_name = trim($_POST['site_name'] ?? 'IT Solutions');
                    $site_description = trim($_POST['site_description'] ?? '');
                    
                    $settings = [
                        'maintenance_mode' => $maintenance_mode,
                        'registration_enabled' => $registration_enabled,
                        'site_name' => $site_name,
                        'site_description' => $site_description
                    ];
                    
                    foreach ($settings as $key => $value) {
                        $stmt = $pdo->prepare("
                            INSERT INTO system_settings (setting_key, setting_value, updated_at) 
                            VALUES (?, ?, NOW()) 
                            ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()
                        ");
                        $stmt->execute([$key, $value, $value]);
                    }
                    
                    $success = 'General settings updated successfully.';
                    break;
                    
                case 'update_security_settings':
                    $max_login_attempts = (int)($_POST['max_login_attempts'] ?? 5);
                    $lockout_duration = (int)($_POST['lockout_duration'] ?? 15);
                    $session_timeout = (int)($_POST['session_timeout'] ?? 120);
                    $password_expiry_days = (int)($_POST['password_expiry_days'] ?? 90);
                    $require_strong_password = isset($_POST['require_strong_password']) ? 'true' : 'false';
                    
                    if ($max_login_attempts < 1) $max_login_attempts = 5;
                    if ($lockout_duration < 1) $lockout_duration = 15;
                    if ($session_timeout < 5) $session_timeout = 120;
                    if ($password_expiry_days < 30) $password_expiry_days = 90;
                    
                    $settings = [
                        'max_login_attempts' => $max_login_attempts,
                        'lockout_duration' => $lockout_duration,
                        'session_timeout' => $session_timeout,
                        'password_expiry_days' => $password_expiry_days,
                        'require_strong_password' => $require_strong_password
                    ];
                    
                    foreach ($settings as $key => $value) {
                        $stmt = $pdo->prepare("
                            INSERT INTO system_settings (setting_key, setting_value, updated_at) 
                            VALUES (?, ?, NOW()) 
                            ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()
                        ");
                        $stmt->execute([$key, $value, $value]);
                    }
                    
                    $success = 'Security settings updated successfully.';
                    break;
                    
                case 'add_user':
                    $username = trim($_POST['username'] ?? '');
                    $email = trim($_POST['email'] ?? '');
                    $password = $_POST['password'] ?? '';
                    $role = $_POST['role'] ?? 'staff';
                    $user_type = $_POST['user_type'] ?? 'staff';
                    $department_code = trim($_POST['department_code'] ?? '');
                    $department_name = trim($_POST['department_name'] ?? '');
                    $phone = trim($_POST['phone'] ?? '');
                    
                    if (empty($username) || empty($email) || empty($password)) {
                        $error = 'Please fill in all required fields.';
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $error = 'Please enter a valid email address.';
                    } elseif (strlen($password) < 8) {
                        $error = 'Password must be at least 8 characters long.';
                    } else {
                        // Check if email exists
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                        $stmt->execute([$email]);
                        if ($stmt->fetch()) {
                            $error = 'Email already exists.';
                        } else {
                            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("
                                INSERT INTO users (username, email, password, phone, department_code, department_name, role, user_type, status, password_changed_at) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
                            ");
                            if ($stmt->execute([$username, $email, $hashed_password, $phone, $department_code, $department_name, $role, $user_type])) {
                                $success = 'User added successfully.';
                            } else {
                                $error = 'Failed to add user.';
                            }
                        }
                    }
                    break;
                    
                case 'edit_user':
                    $user_id = (int)($_POST['user_id'] ?? 0);
                    $username = trim($_POST['username'] ?? '');
                    $email = trim($_POST['email'] ?? '');
                    $role = $_POST['role'] ?? 'staff';
                    $user_type = $_POST['user_type'] ?? 'staff';
                    $department_code = trim($_POST['department_code'] ?? '');
                    $department_name = trim($_POST['department_name'] ?? '');
                    $phone = trim($_POST['phone'] ?? '');
                    $status = $_POST['status'] ?? 'active';
                    
                    if ($user_id > 0 && !empty($username) && !empty($email)) {
                        $stmt = $pdo->prepare("
                            UPDATE users SET 
                                username = ?, email = ?, role = ?, user_type = ?, 
                                department_code = ?, department_name = ?, phone = ?, status = ?
                            WHERE id = ?
                        ");
                        if ($stmt->execute([$username, $email, $role, $user_type, $department_code, $department_name, $phone, $status, $user_id])) {
                            $success = 'User updated successfully.';
                        } else {
                            $error = 'Failed to update user.';
                        }
                    } else {
                        $error = 'Invalid user data.';
                    }
                    break;
                    
                case 'reset_password':
                    $user_id = (int)($_POST['user_id'] ?? 0);
                    $new_password = $_POST['new_password'] ?? '';
                    
                    if ($user_id > 0 && strlen($new_password) >= 8) {
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE users SET password = ?, password_changed_at = NOW() WHERE id = ?");
                        if ($stmt->execute([$hashed_password, $user_id])) {
                            $success = 'Password reset successfully.';
                        } else {
                            $error = 'Failed to reset password.';
                        }
                    } else {
                        $error = 'Password must be at least 8 characters.';
                    }
                    break;
                    
                case 'delete_user':
                    $user_id = (int)($_POST['user_id'] ?? 0);
                    
                    // Don't allow deleting own account
                    if ($user_id == $_SESSION['user_id']) {
                        $error = 'You cannot delete your own account.';
                    } elseif ($user_id > 0) {
                        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                        if ($stmt->execute([$user_id])) {
                            $success = 'User deleted successfully.';
                        } else {
                            $error = 'Failed to delete user.';
                        }
                    }
                    break;
                    
                case 'update_email_template':
                    $template_type = $_POST['template_type'] ?? '';
                    $subject = trim($_POST['subject'] ?? '');
                    $body = trim($_POST['body'] ?? '');
                    
                    if ($template_type && $subject && $body) {
                        // Check if template exists
                        $stmt = $pdo->prepare("SELECT id FROM email_templates WHERE template_type = ?");
                        $stmt->execute([$template_type]);
                        
                        if ($stmt->fetch()) {
                            // Update existing
                            $stmt = $pdo->prepare("UPDATE email_templates SET subject = ?, body = ?, updated_at = NOW() WHERE template_type = ?");
                            $stmt->execute([$subject, $body, $template_type]);
                        } else {
                            // Insert new
                            $stmt = $pdo->prepare("INSERT INTO email_templates (template_type, subject, body, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
                            $stmt->execute([$template_type, $subject, $body]);
                        }
                        $success = 'Email template updated successfully.';
                    } else {
                        $error = 'Please fill in all template fields.';
                    }
                    break;
                    
                case 'clear_cache':
                    // Create cache directory if it doesn't exist
                    if (!is_dir('cache')) {
                        mkdir('cache', 0755, true);
                    }
                    
                    $cache_files = glob('cache/*');
                    $cleared = 0;
                    foreach ($cache_files as $file) {
                        if (is_file($file) && unlink($file)) {
                            $cleared++;
                        }
                    }
                    $success = "Cache cleared successfully. ($cleared files removed)";
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch current settings
$settings = [];
try {
    $result = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    if ($result) {
        while ($row = $result->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch (PDOException $e) {
    // Settings table might not have all entries yet
}

// Fetch users
$users = [];
try {
    $result = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
    if ($result) {
        $users = $result->fetchAll();
    }
} catch (PDOException $e) {
    $error = 'Failed to fetch users: ' . $e->getMessage();
}

// Fetch email templates
$email_templates = [];
try {
    // Check if email_templates table exists
    $result = $pdo->query("SHOW TABLES LIKE 'email_templates'");
    if ($result && $result->rowCount() > 0) {
        $result = $pdo->query("SELECT * FROM email_templates");
        if ($result) {
            while ($row = $result->fetch()) {
                $email_templates[$row['template_type']] = $row;
            }
        }
    }
} catch (PDOException $e) {
    // Table might not exist yet
}

// Get system stats
$stats = [];
try {
    // Total users
    $result = $pdo->query("SELECT COUNT(*) FROM users");
    $stats['total_users'] = $result ? $result->fetchColumn() : 0;
    
    // Active users
    $result = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'");
    $stats['active_users'] = $result ? $result->fetchColumn() : 0;
    
    // Total tickets (check if table exists)
    $result = $pdo->query("SHOW TABLES LIKE 'assistance_requests'");
    if ($result && $result->rowCount() > 0) {
        $result = $pdo->query("SELECT COUNT(*) FROM assistance_requests");
        $stats['total_tickets'] = $result ? $result->fetchColumn() : 0;
        
        $result = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE status = 'pending'");
        $stats['pending_tickets'] = $result ? $result->fetchColumn() : 0;
    } else {
        $stats['total_tickets'] = 0;
        $stats['pending_tickets'] = 0;
    }
    
    // Total assets
    $result = $pdo->query("SELECT COUNT(*) FROM assets");
    $stats['total_assets'] = $result ? $result->fetchColumn() : 0;
    
    // Recent login attempts (last 24 hours) - check if table exists
    $result = $pdo->query("SHOW TABLES LIKE 'failed_logins'");
    if ($result && $result->rowCount() > 0) {
        $result = $pdo->query("SELECT COUNT(*) FROM failed_logins WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stats['failed_logins_24h'] = $result ? $result->fetchColumn() : 0;
    } else {
        $stats['failed_logins_24h'] = 0;
    }
} catch (PDOException $e) {
    $stats['total_users'] = 0;
    $stats['active_users'] = 0;
    $stats['total_tickets'] = 0;
    $stats['pending_tickets'] = 0;
    $stats['total_assets'] = 0;
    $stats['failed_logins_24h'] = 0;
}

// Generate fresh CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 280px;
            background: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.05);
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e2e8f0;
        }

        .sidebar-header h3 {
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin: 0;
            font-size: 1.3rem;
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item-custom {
            padding: 0.5rem 1.5rem;
            margin: 0.25rem 0;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .nav-item-custom a {
            color: #4a5568;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }

        .nav-item-custom i {
            width: 24px;
            font-size: 1.2rem;
        }

        .nav-item-custom:hover {
            background: #fef3c7;
            border-left-color: var(--primary);
        }

        .nav-item-custom.active {
            background: #fef3c7;
            border-left-color: var(--primary);
        }

        .nav-item-custom.active a {
            color: var(--primary-dark);
            font-weight: 600;
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 1.5rem 2rem;
        }

        /* Cards */
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 1rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e293b;
        }

        .stat-label {
            font-size: 0.7rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Settings Card */
        .settings-card {
            background: white;
            border-radius: 16px;
            border: none;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }

        .settings-card .card-header {
            background: white;
            border-bottom: 1px solid #e2e8f0;
            padding: 1rem 1.5rem;
            font-weight: 600;
            font-size: 1rem;
            border-radius: 16px 16px 0 0;
        }

        .settings-card .card-body {
            padding: 1.5rem;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #1e293b;
            margin-bottom: 0.5rem;
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            padding: 0.6rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }

        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            font-weight: 600;
            padding: 0.6rem 1.5rem;
            border-radius: 10px;
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(243,156,18,0.3);
            color: white;
        }

        .btn-outline-primary {
            border: 2px solid var(--primary);
            color: var(--primary);
            font-weight: 600;
            border-radius: 10px;
            background: transparent;
        }

        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background: #f8fafc;
            color: #64748b;
            font-weight: 600;
            font-size: 0.7rem;
            text-transform: uppercase;
            padding: 0.875rem 1rem;
            border-bottom: 2px solid #e2e8f0;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            font-size: 0.85rem;
        }

        .badge-status {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }

        .badge-active { background: #d4f8e8; color: #065f46; }
        .badge-inactive { background: #fee2e2; color: #991b1b; }
        .badge-admin { background: #fed7aa; color: #9b2c1d; }
        .badge-staff { background: #dbeafe; color: #1e40af; }

        .alert-custom {
            border-radius: 12px;
            border: none;
            padding: 0.75rem 1rem;
        }

        /* Modal */
        .modal-content {
            border-radius: 16px;
            border: none;
        }

        .modal-header {
            border-bottom: 1px solid #e2e8f0;
            padding: 1rem 1.5rem;
        }

        .modal-footer {
            border-top: 1px solid #e2e8f0;
            padding: 1rem 1.5rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 1100;
                background: var(--primary);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 0.5rem 0.75rem;
            }
        }

        @media (min-width: 993px) {
            .menu-toggle {
                display: none;
            }
        }

        .utility-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .btn-group-sm .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="menu-toggle" id="menuToggle">
        <i class="bi bi-list"></i>
    </button>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="bi bi-gear me-2"></i>IT Solutions</h3>
            <p class="text-muted small mb-0">Admin Control Panel</p>
        </div>
        <div class="sidebar-nav">
            <div class="nav-item-custom <?= $active_tab == 'general' ? 'active' : '' ?>">
                <a href="?tab=general"><i class="bi bi-sliders2"></i> General Settings</a>
            </div>
            <div class="nav-item-custom <?= $active_tab == 'security' ? 'active' : '' ?>">
                <a href="?tab=security"><i class="bi bi-shield-lock"></i> Security</a>
            </div>
            <div class="nav-item-custom <?= $active_tab == 'users' ? 'active' : '' ?>">
                <a href="?tab=users"><i class="bi bi-people"></i> User Management</a>
            </div>
            <div class="nav-item-custom <?= $active_tab == 'email' ? 'active' : '' ?>">
                <a href="?tab=email"><i class="bi bi-envelope"></i> Email Templates</a>
            </div>
            <div class="nav-item-custom <?= $active_tab == 'system' ? 'active' : '' ?>">
                <a href="?tab=system"><i class="bi bi-hdd-stack"></i> System Info</a>
            </div>
            <div class="nav-item-custom">
                <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Back to Dashboard</a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">System Settings</h2>
                <p class="text-muted mb-0">Manage your system configuration and preferences</p>
            </div>
            <div class="utility-buttons">
                <button class="btn btn-outline-primary btn-sm" onclick="window.location.reload()">
                    <i class="bi bi-arrow-repeat"></i> Refresh
                </button>
                <a href="dashboard.php" class="btn btn-primary btn-sm">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row g-3 mb-4">
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['total_users'] ?? 0 ?></div>
                            <div class="stat-label">Total Users</div>
                        </div>
                        <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['active_users'] ?? 0 ?></div>
                            <div class="stat-label">Active Users</div>
                        </div>
                        <div class="stat-icon bg-success bg-opacity-10 text-success">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['total_tickets'] ?? 0 ?></div>
                            <div class="stat-label">Total Tickets</div>
                        </div>
                        <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                            <i class="bi bi-ticket"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['pending_tickets'] ?? 0 ?></div>
                            <div class="stat-label">Pending Tickets</div>
                        </div>
                        <div class="stat-icon bg-danger bg-opacity-10 text-danger">
                            <i class="bi bi-clock-history"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['total_assets'] ?? 0 ?></div>
                            <div class="stat-label">Total Assets</div>
                        </div>
                        <div class="stat-icon bg-info bg-opacity-10 text-info">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-6">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['failed_logins_24h'] ?? 0 ?></div>
                            <div class="stat-label">Failed Logins (24h)</div>
                        </div>
                        <div class="stat-icon bg-danger bg-opacity-10 text-danger">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Tab Content -->
        <?php if ($active_tab == 'general'): ?>
        <!-- General Settings -->
        <div class="settings-card">
            <div class="card-header">
                <i class="bi bi-sliders2 me-2"></i> General Settings
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="update_general_settings">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Site Name</label>
                            <input type="text" class="form-control" name="site_name" 
                                   value="<?= htmlspecialchars($settings['site_name'] ?? 'IT Solutions') ?>">
                            <small class="text-muted">The name of your site displayed throughout the system.</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Site Description</label>
                            <input type="text" class="form-control" name="site_description" 
                                   value="<?= htmlspecialchars($settings['site_description'] ?? 'Enterprise IT Management System') ?>">
                            <small class="text-muted">A brief description of your organization.</small>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="maintenance_mode" id="maintenance_mode" 
                                       <?= ($settings['maintenance_mode'] ?? 'false') === 'true' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="maintenance_mode">
                                    <strong>Maintenance Mode</strong>
                                </label>
                                <p class="text-muted small mb-0">When enabled, only admins can access the system.</p>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="registration_enabled" id="registration_enabled" 
                                       <?= ($settings['registration_enabled'] ?? 'true') !== 'false' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="registration_enabled">
                                    <strong>Allow User Registration</strong>
                                </label>
                                <p class="text-muted small mb-0">Allow new users to register on the login page.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($active_tab == 'security'): ?>
        <!-- Security Settings -->
        <div class="settings-card">
            <div class="card-header">
                <i class="bi bi-shield-lock me-2"></i> Security Settings
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="update_security_settings">
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Max Login Attempts</label>
                            <input type="number" class="form-control" name="max_login_attempts" 
                                   value="<?= $settings['max_login_attempts'] ?? 5 ?>" min="1" max="20">
                            <small class="text-muted">Number of failed attempts before lockout</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Lockout Duration (minutes)</label>
                            <input type="number" class="form-control" name="lockout_duration" 
                                   value="<?= $settings['lockout_duration'] ?? 15 ?>" min="1" max="1440">
                            <small class="text-muted">How long to lock out after failed attempts</small>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Session Timeout (minutes)</label>
                            <input type="number" class="form-control" name="session_timeout" 
                                   value="<?= $settings['session_timeout'] ?? 120 ?>" min="5" max="720">
                            <small class="text-muted">Auto logout after inactivity</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password Expiry (days)</label>
                            <input type="number" class="form-control" name="password_expiry_days" 
                                   value="<?= $settings['password_expiry_days'] ?? 90 ?>" min="30" max="365">
                            <small class="text-muted">Days before password must be changed</small>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="require_strong_password" id="require_strong_password" 
                                   <?= ($settings['require_strong_password'] ?? 'true') === 'true' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="require_strong_password">
                                <strong>Require Strong Passwords</strong>
                            </label>
                            <p class="text-muted small mb-0">Require passwords with uppercase, lowercase, numbers, and special characters.</p>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> Save Security Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Clear Cache Card -->
        <div class="settings-card">
            <div class="card-header">
                <i class="bi bi-trash me-2"></i> System Maintenance
            </div>
            <div class="card-body">
                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to clear the cache?');">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="clear_cache">
                    
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="mb-1">Clear System Cache</h6>
                            <p class="text-muted small mb-0">Clear cached data to ensure fresh content is loaded.</p>
                        </div>
                        <button type="submit" class="btn btn-outline-danger">
                            <i class="bi bi-trash me-2"></i> Clear Cache
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($active_tab == 'users'): ?>
        <!-- User Management -->
        <div class="settings-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-people me-2"></i> User Management</span>
                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addUserModal">
                    <i class="bi bi-person-plus"></i> Add New User
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-container">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= htmlspecialchars($user['id']) ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <span class="badge-status <?= $user['role'] == 'admin' ? 'badge-admin' : 'badge-staff' ?>">
                                        <?= ucfirst(htmlspecialchars($user['role'])) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($user['department_name'] ?: '-') ?></td>
                                <td>
                                    <span class="badge-status <?= $user['status'] == 'active' ? 'badge-active' : 'badge-inactive' ?>">
                                        <?= ucfirst(htmlspecialchars($user['status'])) ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" onclick='editUser(<?= json_encode($user) ?>)'>
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-outline-warning" onclick="resetPassword(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')">
                                            <i class="bi bi-key"></i>
                                        </button>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <button class="btn btn-outline-danger" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Add User Modal -->
        <div class="modal fade" id="addUserModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="action" value="add_user">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add New User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password *</label>
                                <input type="password" class="form-control" name="password" required>
                                <small class="text-muted">Minimum 8 characters</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Role</label>
                                <select class="form-select" name="role">
                                    <option value="staff">Staff</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">User Type</label>
                                <select class="form-select" name="user_type">
                                    <option value="staff">Staff</option>
                                    <option value="admin">Admin</option>
                                    <option value="technician">Technician</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Department Code</label>
                                <input type="text" class="form-control" name="department_code">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Department Name</label>
                                <input type="text" class="form-control" name="department_name">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit User Modal -->
        <div class="modal fade" id="editUserModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="action" value="edit_user">
                        <input type="hidden" name="user_id" id="edit_user_id">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" id="edit_username" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" id="edit_email" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Role</label>
                                <select class="form-select" name="role" id="edit_role">
                                    <option value="staff">Staff</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">User Type</label>
                                <select class="form-select" name="user_type" id="edit_user_type">
                                    <option value="staff">Staff</option>
                                    <option value="admin">Admin</option>
                                    <option value="technician">Technician</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" id="edit_phone">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Department Code</label>
                                <input type="text" class="form-control" name="department_code" id="edit_department_code">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Department Name</label>
                                <input type="text" class="form-control" name="department_name" id="edit_department_name">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status" id="edit_status">
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Reset Password Modal -->
        <div class="modal fade" id="resetPasswordModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="action" value="reset_password">
                        <input type="hidden" name="user_id" id="reset_user_id">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-key me-2"></i>Reset Password</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Reset password for user: <strong id="reset_username"></strong></p>
                            <div class="mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" class="form-control" name="new_password" required>
                                <small class="text-muted">Minimum 8 characters</small>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-warning">Reset Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Delete User Form -->
        <form id="deleteUserForm" method="POST" style="display: none;">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="action" value="delete_user">
            <input type="hidden" name="user_id" id="delete_user_id">
        </form>
        <?php endif; ?>

        <?php if ($active_tab == 'email'): ?>
        <!-- Email Templates -->
        <div class="settings-card">
            <div class="card-header">
                <i class="bi bi-envelope me-2"></i> Email Templates
            </div>
            <div class="card-body">
                <form method="POST" action="" id="emailTemplateForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="update_email_template">
                    
                    <div class="mb-3">
                        <label class="form-label">Template Type</label>
                        <select class="form-select" name="template_type" id="template_type" onchange="loadTemplate()">
                            <option value="welcome">Welcome Email</option>
                            <option value="password_reset">Password Reset</option>
                            <option value="ticket_created">Ticket Created</option>
                            <option value="ticket_updated">Ticket Updated</option>
                            <option value="ticket_resolved">Ticket Resolved</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <input type="text" class="form-control" name="subject" id="template_subject" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email Body</label>
                        <textarea class="form-control" name="body" id="template_body" rows="10" required></textarea>
                        <small class="text-muted">
                            Available variables: {user_name}, {user_email}, {site_name}, {ticket_id}, {reset_link}
                        </small>
                    </div>
                    
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> Save Template
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script>
        const emailTemplates = <?php 
            $templates = [];
            foreach ($email_templates as $type => $template) {
                $templates[$type] = [
                    'subject' => $template['subject'],
                    'body' => $template['body']
                ];
            }
            echo json_encode($templates);
        ?>;
        
        function loadTemplate() {
            const type = document.getElementById('template_type').value;
            const template = emailTemplates[type];
            if (template) {
                document.getElementById('template_subject').value = template.subject;
                document.getElementById('template_body').value = template.body;
            } else {
                // Default templates
                const defaults = {
                    'welcome': {
                        subject: 'Welcome to {site_name}',
                        body: 'Dear {user_name},\n\nWelcome to {site_name}! Your account has been successfully created.\n\nYou can now log in using your email: {user_email}\n\nBest regards,\n{site_name} Team'
                    },
                    'password_reset': {
                        subject: 'Password Reset Request',
                        body: 'Dear {user_name},\n\nWe received a request to reset your password. Click the link below to reset it:\n\n{reset_link}\n\nIf you did not request this, please ignore this email.\n\nBest regards,\n{site_name} Team'
                    },
                    'ticket_created': {
                        subject: 'Support Ticket Created - #{ticket_id}',
                        body: 'Dear {user_name},\n\nYour support ticket (#{ticket_id}) has been created successfully.\n\nWe will get back to you as soon as possible.\n\nBest regards,\n{site_name} Support Team'
                    },
                    'ticket_updated': {
                        subject: 'Ticket #{ticket_id} Updated',
                        body: 'Dear {user_name},\n\nYour support ticket (#{ticket_id}) has been updated.\n\nPlease log in to view the details.\n\nBest regards,\n{site_name} Support Team'
                    },
                    'ticket_resolved': {
                        subject: 'Ticket #{ticket_id} Resolved',
                        body: 'Dear {user_name},\n\nYour support ticket (#{ticket_id}) has been marked as resolved.\n\nIf you have any further issues, please feel free to open a new ticket.\n\nBest regards,\n{site_name} Support Team'
                    }
                };
                
                if (defaults[type]) {
                    document.getElementById('template_subject').value = defaults[type].subject;
                    document.getElementById('template_body').value = defaults[type].body;
                } else {
                    document.getElementById('template_subject').value = '';
                    document.getElementById('template_body').value = '';
                }
            }
        }
        </script>
        <?php endif; ?>

        <?php if ($active_tab == 'system'): ?>
        <!-- System Information -->
        <div class="row">
            <div class="col-md-6">
                <div class="settings-card">
                    <div class="card-header">
                        <i class="bi bi-server me-2"></i> Server Information
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 40%">PHP Version</th>
                                <td><?= phpversion() ?></td>
                            </tr>
                            <tr>
                                <th>Server Software</th>
                                <td><?= $_SERVER['SERVER_SOFTWARE'] ?? 'N/A' ?></td>
                            </tr>
                            <tr>
                                <th>MySQL Version</th>
                                <td>
                                    <?php
                                    $result = $pdo->query("SELECT VERSION()");
                                    echo $result ? $result->fetchColumn() : 'N/A';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Server Time</th>
                                <td><?= date('Y-m-d H:i:s') ?></td>
                            </tr>
                            <tr>
                                <th>Timezone</th>
                                <td><?= date_default_timezone_get() ?></td>
                            </tr>
                            <tr>
                                <th>Upload Max Size</th>
                                <td><?= ini_get('upload_max_filesize') ?></td>
                            </tr>
                            <tr>
                                <th>Post Max Size</th>
                                <td><?= ini_get('post_max_size') ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="settings-card">
                    <div class="card-header">
                        <i class="bi bi-database me-2"></i> Database Information
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 40%">Database Name</th>
                                <td><?= htmlspecialchars(DB_NAME) ?></td>
                            </tr>
                            <tr>
                                <th>Total Tables</th>
                                <td>
                                    <?php
                                    $result = $pdo->query("SHOW TABLES");
                                    echo $result ? $result->rowCount() : 0;
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Total Users</th>
                                <td><?= $stats['total_users'] ?? 0 ?></td>
                            </tr>
                            <tr>
                                <th>Total Tickets</th>
                                <td><?= $stats['total_tickets'] ?? 0 ?></td>
                            </tr>
                            <tr>
                                <th>Total Assets</th>
                                <td><?= $stats['total_assets'] ?? 0 ?></td>
                            </tr>
                            <tr>
                                <th>Database Size</th>
                                <td>
                                    <?php
                                    try {
                                        $result = $pdo->query("
                                            SELECT SUM(data_length + index_length) / 1024 / 1024 AS size_mb
                                            FROM information_schema.tables
                                            WHERE table_schema = '" . DB_NAME . "'
                                        ");
                                        if ($result) {
                                            $size = $result->fetchColumn();
                                            echo round($size, 2) . ' MB';
                                        } else {
                                            echo 'N/A';
                                        }
                                    } catch (Exception $e) {
                                        echo 'Unable to calculate';
                                    }
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-12">
                <div class="settings-card">
                    <div class="card-header">
                        <i class="bi bi-activity me-2"></i> Recent Login Activity
                    </div>
                    <div class="card-body p-0">
                        <div class="table-container">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>User</th>
                                        <th>IP Address</th>
                                        <th>User Agent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $result = $pdo->query("
                                            SELECT ll.*, u.username 
                                            FROM login_logs ll 
                                            LEFT JOIN users u ON ll.user_id = u.id 
                                            ORDER BY ll.login_time DESC 
                                            LIMIT 20
                                        ");
                                        $hasLogs = false;
                                        if ($result) {
                                            while ($log = $result->fetch()):
                                                $hasLogs = true;
                                    ?>
                                    <tr>
                                        <td><?= date('M d, H:i:s', strtotime($log['login_time'])) ?></td>
                                        <td><?= htmlspecialchars($log['username'] ?? 'Unknown') ?></td>
                                        <td><?= htmlspecialchars($log['ip_address'] ?? 'N/A') ?></td>
                                        <td><small><?= htmlspecialchars(substr($log['user_agent'] ?? '', 0, 50)) ?>...</small></td>
                                    </tr>
                                    <?php 
                                            endwhile;
                                        }
                                        if (!$hasLogs) {
                                            echo '<tr><td colspan="4" class="text-center py-4 text-muted">No login activity found</td></tr>';
                                        }
                                    } catch (PDOException $e) {
                                        echo '<tr><td colspan="4" class="text-center py-4 text-muted">Unable to load activity logs</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        
        if (menuToggle) {
            menuToggle.addEventListener('click', () => {
                sidebar.classList.toggle('show');
            });
        }
        
        // User Management Functions
        function editUser(user) {
            document.getElementById('edit_user_id').value = user.id;
            document.getElementById('edit_username').value = user.username;
            document.getElementById('edit_email').value = user.email;
            document.getElementById('edit_role').value = user.role;
            document.getElementById('edit_user_type').value = user.user_type;
            document.getElementById('edit_phone').value = user.phone || '';
            document.getElementById('edit_department_code').value = user.department_code || '';
            document.getElementById('edit_department_name').value = user.department_name || '';
            document.getElementById('edit_status').value = user.status;
            
            new bootstrap.Modal(document.getElementById('editUserModal')).show();
        }
        
        function resetPassword(userId, username) {
            document.getElementById('reset_user_id').value = userId;
            document.getElementById('reset_username').textContent = username;
            new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
        }
        
        function deleteUser(userId, username) {
            if (confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) {
                document.getElementById('delete_user_id').value = userId;
                document.getElementById('deleteUserForm').submit();
            }
        }
        
        // Auto-load email template on page load
        if (typeof loadTemplate === 'function') {
            loadTemplate();
        }
        
        // Session timeout warning
        let timeoutWarning;
        const sessionTimeout = <?= ($settings['session_timeout'] ?? 120) ?> * 60 * 1000;
        
        function resetTimeout() {
            clearTimeout(timeoutWarning);
            timeoutWarning = setTimeout(() => {
                if (confirm('Your session will expire soon due to inactivity. Click OK to stay logged in.')) {
                    // Refresh session via AJAX
                    fetch('api/refresh_session.php')
                        .catch(err => console.error('Session refresh failed'));
                    resetTimeout();
                }
            }, sessionTimeout - 60000); // Warn 1 minute before timeout
        }
        
        if (sessionTimeout > 60000) {
            resetTimeout();
            document.addEventListener('mousemove', resetTimeout);
            document.addEventListener('keypress', resetTimeout);
        }
    </script>
</body>
</html>