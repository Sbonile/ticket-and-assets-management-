<?php
// config/settings.php - System configuration functions

function isMaintenanceMode($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'maintenance_mode'");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result && $result['setting_value'] === 'true';
    } catch (PDOException $e) {
        return false;
    }
}

function isRegistrationEnabled($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'registration_enabled'");
        $stmt->execute();
        $result = $stmt->fetch();
        return !$result || $result['setting_value'] !== 'false';
    } catch (PDOException $e) {
        return true;
    }
}

function getMaxLoginAttempts($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'max_login_attempts'");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result ? (int)$result['setting_value'] : 5;
    } catch (PDOException $e) {
        return 5;
    }
}

function logUserActivity($pdo, $userId, $action, $details = null) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_activity_logs (user_id, action, details, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $userId, 
            $action, 
            $details, 
            $_SERVER['REMOTE_ADDR'], 
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    } catch (PDOException $e) {
        // Silently fail - don't break functionality
    }
}