<?php
// config/company.php - White Label Configuration (Works with existing database)
return [
    // Company Information - CHANGE THESE VALUES FOR YOUR COMPANY
    'company' => [
        'name' => 'IT Solutions',
        'short_name' => 'ITS',
        'logo_text' => 'IT Solutions',
        'logo_icon' => 'bi-cpu',
        'email' => 'support@itsolutions.co.za',
        'phone' => '+27 10 880 3795',
        'website' => '',
    ],
    
    // Branding Colors - CHANGE THESE TO MATCH YOUR BRAND
    'colors' => [
        'primary' => '#f39c12',      // Main brand color (Orange)
        'primary_dark' => '#e67e22',  // Darker shade
        'primary_light' => '#fef3c7', // Lighter shade
        'secondary' => '#1e293b',
        'success' => '#10b981',
        'danger' => '#ef4444',
        'warning' => '#f59e0b',
        'info' => '#3b82f6',
    ],
    
    // System Settings
    'system' => [
        'name' => 'IT Solutions Management System',
        'version' => '1.0.0',
    ],
    
    // Footer Text
    'footer' => [
        'copyright' => '© ' . date('Y') . ' IT Solutions. All rights reserved.',
        'powered_by' => 'Powered by IT Solutions',
        'show_version' => true,
    ],

    'theme' => [
    'logo_path' => 'assets/images/logo.png',
],
];
?>