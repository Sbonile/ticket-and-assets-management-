<?php
// config/session.php - Updated with company config support
session_start();

// Load company configuration
$companyConfigFile = __DIR__ . '/company.php';
if (file_exists($companyConfigFile)) {
    $companyConfig = require_once $companyConfigFile;
} else {
    // Default configuration if file doesn't exist
    $companyConfig = [
        'company' => [
            'name' => 'IT Solutions',
            'short_name' => 'ITS',
            'logo_text' => 'IT Solutions',
            'logo_icon' => 'bi-cpu',
            'email' => 'support@itsolutions.co.za',
            'phone' => '+27 10 880 3795',
        ],
        'colors' => [
            'primary' => '#f39c12',
            'primary_dark' => '#e67e22',
            'primary_light' => '#fef3c7',
        ],
        'system' => [
            'name' => 'IT Solutions Management System',
            'version' => '1.0.0',
        ],
        'footer' => [
            'copyright' => '© ' . date('Y') . ' IT Solutions. All rights reserved.',
            'powered_by' => 'Powered by IT Solutions',
            'show_version' => true,
        ],
    ];
}

// Make config available globally
$GLOBALS['company'] = $companyConfig;

// Helper function to get company setting
function company($key, $default = null) {
    global $companyConfig;
    $keys = explode('.', $key);
    $value = $companyConfig;
    foreach ($keys as $k) {
        if (!isset($value[$k])) return $default;
        $value = $value[$k];
    }
    return $value;
}

// Helper functions for common values
function companyName() {
    return company('company.name', 'IT Solutions');
}

function companyEmail() {
    return company('company.email', 'support@itsolutions.co.za');
}

function companyPhone() {
    return company('company.phone', '+27 10 880 3795');
}

function primaryColor() {
    return company('colors.primary', '#f39c12');
}

// Set timezone
date_default_timezone_set('Africa/Johannesburg');
?>