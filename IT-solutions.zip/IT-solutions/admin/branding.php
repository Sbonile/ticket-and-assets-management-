<?php
// admin/branding.php - Admin interface for white label settings
require_once '../config/session.php';
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['user_type'] !== 'admin')) {
    header("Location: ../index.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'company' => [
            'name' => $_POST['company_name'] ?? 'IT Solutions',
            'short_name' => $_POST['company_short_name'] ?? 'ITS',
            'logo_text' => $_POST['company_logo_text'] ?? '',
            'logo_icon' => $_POST['company_logo_icon'] ?? 'bi-building',
            'email' => $_POST['company_email'] ?? '',
            'phone' => $_POST['company_phone'] ?? '',
            'website' => $_POST['company_website'] ?? '',
        ],
        'colors' => [
            'primary' => $_POST['color_primary'] ?? '#f39c12',
            'primary_dark' => $_POST['color_primary_dark'] ?? '#e67e22',
            'primary_light' => $_POST['color_primary_light'] ?? '#fef3c7',
        ],
    ];
    
    // Save to config file
    $configContent = "<?php\nreturn " . var_export($settings, true) . ";\n";
    file_put_contents('../config/company.php', $configContent);
    
    $success = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Branding Settings | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: <?= company('colors.primary', '#f39c12') ?>;
        }
        body { font-family: 'Inter', sans-serif; background: #f5f7fa; }
        .preview-box {
            background: white;
            border-radius: 12px;
            padding: 1rem;
            margin-top: 1rem;
            border: 1px solid #e2e8f0;
        }
        .color-preview {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: inline-block;
            margin-right: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h4 class="mb-0"><i class="bi bi-palette"></i> White Label / Branding Settings</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success">Settings saved successfully!</div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <h5 class="mt-3">Company Information</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Company Name</label>
                                    <input type="text" name="company_name" class="form-control" value="<?= company('company.name') ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Short Name</label>
                                    <input type="text" name="company_short_name" class="form-control" value="<?= company('company.short_name') ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Logo Text</label>
                                    <input type="text" name="company_logo_text" class="form-control" value="<?= company('company.logo_text') ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Logo Icon (Bootstrap Icon class)</label>
                                    <input type="text" name="company_logo_icon" class="form-control" value="<?= company('company.logo_icon') ?>">
                                    <small>e.g., bi-building, bi-cpu, bi-laptop</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Support Email</label>
                                    <input type="email" name="company_email" class="form-control" value="<?= company('company.email') ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Support Phone</label>
                                    <input type="text" name="company_phone" class="form-control" value="<?= company('company.phone') ?>">
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Website</label>
                                    <input type="url" name="company_website" class="form-control" value="<?= company('company.website') ?>">
                                </div>
                            </div>
                            
                            <h5 class="mt-4">Brand Colors</h5>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label>Primary Color</label>
                                    <input type="color" name="color_primary" class="form-control form-control-color" value="<?= company('colors.primary', '#f39c12') ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Primary Dark</label>
                                    <input type="color" name="color_primary_dark" class="form-control form-control-color" value="<?= company('colors.primary_dark', '#e67e22') ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Primary Light</label>
                                    <input type="color" name="color_primary_light" class="form-control form-control-color" value="<?= company('colors.primary_light', '#fef3c7') ?>">
                                </div>
                            </div>
                            
                            <div class="preview-box">
                                <h6>Live Preview</h6>
                                <div style="background: var(--primary); padding: 10px; border-radius: 8px; color: white; text-align: center;">
                                    <i class="bi <?= company('company.logo_icon', 'bi-building') ?>"></i>
                                    <strong><?= company('company.name', 'Your Company') ?></strong>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">Save Branding Settings</button>
                                <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>