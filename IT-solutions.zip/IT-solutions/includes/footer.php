<?php
// includes/footer.php - Reusable footer
$companyName = company('company.name', 'IT Solutions');
$copyright = company('footer.copyright', "© " . date('Y') . " $companyName. All rights reserved.");
$poweredBy = company('footer.powered_by', "Powered by $companyName");
?>
    </div> <!-- Close main-content -->
    
    <footer style="background: #1e293b; color: #94a3b8; padding: 2rem 0; margin-top: auto;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="bi <?= company('company.logo_icon', 'bi-building') ?>"></i> <?= htmlspecialchars($companyName) ?></h5>
                    <p class="mb-0"><?= company('system.name', 'Enterprise IT Management System') ?></p>
                    <p class="small mt-2"><?= $copyright ?></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Contact</h5>
                    <p class="mb-0">
                        <i class="bi bi-envelope"></i> <?= company('company.email', 'support@itsolutions.co.za') ?><br>
                        <i class="bi bi-telephone"></i> <?= company('company.phone', '+27 10 880 3795') ?>
                    </p>
                </div>
            </div>
            <hr class="mt-3 mb-3" style="border-color: #334155;">
            <div class="text-center">
                <small><?= $poweredBy ?></small>
            </div>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Notification System
        let notificationPollingInterval = null;
        
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon">
                                <i class="bi bi-bell"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title fw-semibold">${escapeHtml(notif.title)}</div>
                                <div class="notification-message small">${escapeHtml(notif.message)}</div>
                                <div class="notification-time small">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function startNotificationPolling() {
            if (notificationPollingInterval) clearInterval(notificationPollingInterval);
            notificationPollingInterval = setInterval(() => {
                fetch('api/notifications.php?action=get_count')
                    .then(r => r.json())
                    .then(data => {
                        if (data.success && data.unread_count > 0) {
                            const bellBadge = document.querySelector('.notification-badge');
                            if (bellBadge) {
                                bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                                bellBadge.style.display = 'flex';
                            }
                        }
                    })
                    .catch(err => console.error('Error checking notifications:', err));
            }, 30000);
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            startNotificationPolling();
        });
    </script>
</body>
</html>