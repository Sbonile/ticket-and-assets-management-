<?php
// includes/header.php - Reusable header with white labeling
if (!isset($GLOBALS['company'])) {
    require_once __DIR__ . '/../config/session.php';
}

$companyName = company('company.name', 'IT Solutions');
$logoText = company('company.logo_text', $companyName);
$logoIcon = company('company.logo_icon', 'bi-cpu');
$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' : '';
$unreadCount = $unreadCount ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle . $companyName ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: <?= company('colors.primary', '#f39c12') ?>;
            --primary-dark: <?= company('colors.primary_dark', '#e67e22') ?>;
            --primary-light: <?= company('colors.primary_light', '#fef3c7') ?>;
            --primary-gradient: linear-gradient(135deg, <?= company('colors.primary', '#f39c12') ?> 0%, <?= company('colors.primary_dark', '#e67e22') ?> 100%);
            --secondary: <?= company('colors.secondary', '#1e293b') ?>;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        html, body {
            height: 100%;
        }
        
        body { 
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            display: flex;
            flex-direction: column;
        }
        
        /* Navbar */
        .navbar {
            background: var(--primary-gradient) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white !important;
        }
        
        .navbar-brand i {
            font-size: 1.6rem;
        }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }
        
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: 12px;
            border: none;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            padding: 0;
        }
        
        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background: white;
            z-index: 1;
        }
        
        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid #e2e8f0;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .notification-item:hover {
            background: #fefce8;
        }
        
        .notification-item.unread {
            background: #fffbeb;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #fed7aa;
            color: #f59e0b;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-top: 80px;
            padding: 24px 28px;
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient) !important;
            border: none !important;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            filter: brightness(1.05);
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary) !important;
            color: var(--primary) !important;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-gradient) !important;
            border-color: transparent !important;
            color: white !important;
        }
        
        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .main-content {
            animation: fadeIn 0.4s ease-out;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                margin-top: 70px;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi <?= $logoIcon ?>"></i>
                <span><?= htmlspecialchars($logoText) ?></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'devices.php' ? 'active' : '' ?>" href="devices.php">
                            <i class="bi bi-laptop me-1"></i> Devices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'assets.php' ? 'active' : '' ?>" href="assets.php">
                            <i class="bi bi-box-seam me-1"></i> Assets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'tickets.php' ? 'active' : '' ?>" href="tickets.php">
                            <i class="bi bi-ticket-detailed me-1"></i> Tickets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'technicians.php' ? 'active' : '' ?>" href="technicians.php">
                            <i class="bi bi-people me-1"></i> Technicians
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header">
                                <h6 class="m-0"><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link p-0" onclick="markAllAsRead()" style="color: var(--primary);">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small" style="color: var(--primary);">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="main-content">