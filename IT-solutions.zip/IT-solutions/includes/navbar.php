<?php
// Get unread notifications count
$unreadCount = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$_SESSION['user_id']]);
    $unreadCount = $stmt->fetchColumn();
}
?>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">
            <i class="bi bi-cpu"></i>
            <span>IT Solutions</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-1"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'devices.php' ? 'active' : '' ?>" href="devices.php">
                        <i class="bi bi-laptop me-1"></i> Devices
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'assets.php' ? 'active' : '' ?>" href="assets.php">
                        <i class="bi bi-box-seam me-1"></i> Assets
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'tickets.php' ? 'active' : '' ?>" href="tickets.php">
                        <i class="bi bi-ticket-detailed me-1"></i> Tickets
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'technicians.php' ? 'active' : '' ?>" href="technicians.php">
                        <i class="bi bi-people me-1"></i> Technicians
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav align-items-center">
                <li class="nav-item">
                    <div class="notification-bell" data-bs-toggle="dropdown">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($unreadCount > 0): ?>
                            <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                        <div class="notifications-header">
                            <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                            <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                        </div>
                        <div id="notificationsList" class="notifications-list">
                            <div class="text-center py-4 text-muted">
                                <i class="bi bi-bell-slash fs-4"></i>
                                <p class="mb-0 small">Loading...</p>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item dropdown ms-2">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>