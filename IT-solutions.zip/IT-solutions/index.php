<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';
$error = '';
$warning = '';

// Function to get system setting
function getSetting($pdo, $key, $default = null) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

// Check if system is in maintenance mode
$maintenance_mode = getSetting($pdo, 'maintenance_mode', 'false') === 'true';
$maintenance_message = getSetting($pdo, 'maintenance_message', 'System is currently under maintenance. Please try again later.');

// Check if registration is enabled
$registration_enabled = getSetting($pdo, 'registration_enabled', 'true') !== 'false';

// Get max login attempts
$max_login_attempts = (int)getSetting($pdo, 'max_login_attempts', 5);
$lockout_duration = (int)getSetting($pdo, 'lockout_duration', 15);

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if IP is locked out
function isIPLockedOut($pdo, $ip, $lockout_duration) {
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM failed_logins 
            WHERE ip_address = ? 
            AND attempt_time > DATE_SUB(NOW(), INTERVAL ? MINUTE)
        ");
        $stmt->execute([$ip, $lockout_duration]);
        $attempts = $stmt->fetchColumn();
        
        $max_attempts = (int)getSetting($pdo, 'max_login_attempts', 5);
        return $attempts >= $max_attempts;
    } catch (PDOException $e) {
        return false;
    }
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if ($maintenance_mode) {
        $error = 'System is currently in maintenance mode. Please try again later.';
    } elseif (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $user_ip = $_SERVER['REMOTE_ADDR'];
        
        // Check if IP is locked out
        if (isIPLockedOut($pdo, $user_ip, $lockout_duration)) {
            $error = 'Too many failed login attempts. Please try again after ' . $lockout_duration . ' minutes.';
        } elseif (empty($email) || empty($password)) {
            $error = 'Please enter both email and password.';
        } else {
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                
                if ($user && password_verify($password, $user['password'])) {
                    // Check if password needs to be changed
                    $password_expiry_days = (int)getSetting($pdo, 'password_expiry_days', 90);
                    if ($password_expiry_days > 0 && isset($user['password_changed_at'])) {
                        $password_age = time() - strtotime($user['password_changed_at']);
                        if ($password_age > ($password_expiry_days * 86400)) {
                            $_SESSION['force_password_change'] = true;
                            $_SESSION['user_id_temp'] = $user['id'];
                            header("Location: change_password.php");
                            exit();
                        }
                    }
                    
                    // Regenerate session ID to prevent session fixation
                    session_regenerate_id(true);
                    
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['name'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $_SESSION['department_code'] = $user['department_code'] ?? '';
                    $_SESSION['department_name'] = $user['department_name'] ?? '';
                    $_SESSION['logged_in'] = true;
                    $_SESSION['login_time'] = time();
                    
                    // Remember me functionality
                    if (isset($_POST['remember_me'])) {
                        $token = bin2hex(random_bytes(32));
                        $expiry = time() + (86400 * 30);
                        
                        // Store token in database
                        $stmt = $pdo->prepare("UPDATE users SET remember_token = ?, remember_token_expiry = ? WHERE id = ?");
                        $stmt->execute([$token, date('Y-m-d H:i:s', $expiry), $user['id']]);
                        
                        setcookie('remember_token', $token, $expiry, '/', '', true, true);
                    }
                    
                    // Clear failed login attempts for this IP
                    $stmt = $pdo->prepare("DELETE FROM failed_logins WHERE ip_address = ?");
                    $stmt->execute([$user_ip]);
                    
                    // Log successful login
                    $stmt = $pdo->prepare("INSERT INTO login_logs (user_id, ip_address, user_agent, login_time) VALUES (?, ?, ?, NOW())");
                    $stmt->execute([$user['id'], $user_ip, $_SERVER['HTTP_USER_AGENT'] ?? '']);
                    
                    // Redirect based on user type
                    if ($user['role'] === 'admin' || $user['user_type'] === 'admin') {
                        header("Location: dashboard.php");
                    } else {
                        header("Location: staff_dashboard.php");
                    }
                    exit();
                } else {
                    $error = 'Invalid email or password.';
                    
                    // Log failed attempt
                    $stmt = $pdo->prepare("INSERT INTO failed_logins (email, ip_address, attempt_time) VALUES (?, ?, NOW())");
                    $stmt->execute([$email, $user_ip]);
                    
                    // Check if now locked out
                    if (isIPLockedOut($pdo, $user_ip, $lockout_duration)) {
                        $error = 'Too many failed login attempts. Please try again after ' . $lockout_duration . ' minutes.';
                    }
                }
            } catch (PDOException $e) {
                $error = 'Login failed. Please try again.';
                error_log($e->getMessage());
            }
        }
    }
}

// Check if user is already logged in
if (isset($_SESSION['user_id']) && !isset($_SESSION['force_password_change'])) {
    if ($_SESSION['role'] === 'admin' || $_SESSION['user_type'] === 'admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: staff_dashboard.php");
    }
    exit();
}

// Check for remember me token
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token']) && !$maintenance_mode) {
    $token = $_COOKIE['remember_token'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? AND remember_token_expiry > NOW() AND status = 'active'");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['logged_in'] = true;
            
            if ($user['role'] === 'admin' || $user['user_type'] === 'admin') {
                header("Location: dashboard.php");
            } else {
                header("Location: staff_dashboard.php");
            }
            exit();
        }
    } catch (PDOException $e) {
        // Token invalid, continue to login page
    }
}

// Get site settings for display
$site_name = getSetting($pdo, 'site_name', 'IT Solutions');
$site_description = getSetting($pdo, 'site_description', 'Enterprise IT Management System');

$companyName = company('company.name', 'IT Solutions');
$logoText = company('company.logo_text', $companyName);
$logoIcon = company('company.logo_icon', 'bi-cpu');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($site_name) ?> | Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--primary-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            width: 100%;
            max-width: 450px;
            animation: fadeInUp 0.5s ease-out;
        }

        .login-card {
            background: white;
            border-radius: 24px;
            padding: 2rem;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            position: relative;
            overflow: hidden;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--primary-gradient);
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo {
            font-size: 2.5rem;
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 0.5rem;
        }

        .logo i {
            font-size: 2.5rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .tagline {
            color: #64748b;
            font-size: 0.85rem;
        }

        .info-banner {
            background: linear-gradient(135deg, #fef3c7, #fffbeb);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            margin-bottom: 1.5rem;
            font-size: 0.8rem;
            color: #92400e;
            text-align: center;
            border-left: 4px solid var(--primary);
        }

        .form-label {
            font-weight: 600;
            font-size: 0.8rem;
            color: #1e293b;
            margin-bottom: 0.4rem;
        }

        .input-group {
            border-radius: 12px;
            overflow: hidden;
        }

        .input-group-text {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            color: #64748b;
        }

        .form-control {
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }

        .toggle-password {
            border: 1px solid #e2e8f0;
            border-left: none;
        }

        .btn-login {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(243,156,18,0.3);
        }

        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .btn-outline-ticket {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            width: 100%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-outline-ticket:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }

        .btn-outline-register {
            background: transparent;
            border: 2px solid #10b981;
            color: #10b981;
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            width: 100%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-outline-register:hover {
            background: #10b981;
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }

        .login-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1rem;
            border-top: 1px solid #e2e8f0;
        }

        .login-footer a {
            color: #64748b;
            font-size: 0.8rem;
            text-decoration: none;
        }

        .login-footer a:hover {
            color: var(--primary);
        }

        .alert-custom {
            border-radius: 12px;
            border: none;
            padding: 0.75rem 1rem;
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
        }

        .public-ticket-section {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e2e8f0;
        }

        .maintenance-badge {
            background: #ef4444;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 1rem;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 576px) {
            .login-card {
                padding: 1.5rem;
            }
            .logo {
                font-size: 2rem;
            }
            .logo i {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="bi bi-cpu"></i>
                    <span><?= htmlspecialchars($site_name) ?></span>
                </div>
                <p class="tagline"><?= htmlspecialchars($site_description) ?></p>
            </div>
            
            <?php if ($maintenance_mode): ?>
                <div class="text-center">
                    <div class="maintenance-badge">
                        <i class="bi bi-tools me-1"></i> Maintenance Mode
                    </div>
                    <div class="alert alert-warning alert-custom">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <?= htmlspecialchars($maintenance_message) ?>
                    </div>
                </div>
            <?php else: ?>
            
            <?php if ($registration_enabled): ?>
            <div class="info-banner">
                <i class="bi bi-info-circle-fill me-1"></i>
                <strong>New to <?= htmlspecialchars($site_name) ?>?</strong> Register for an account to get started.
            </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-custom alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="loginForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" name="email" id="email" 
                               placeholder="Enter your email" required autofocus>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password" id="password" 
                               placeholder="Enter your password" required>
                        <button class="btn btn-outline-secondary toggle-password" type="button">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mb-3 d-flex justify-content-between align-items-center">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me">
                        <label class="form-check-label" for="remember_me">Remember me</label>
                    </div>
                    <a href="forgot-password.php" class="text-decoration-none small">Forgot Password?</a>
                </div>
                
                <button type="submit" name="login" class="btn btn-login" id="loginBtn">
                    <i class="bi bi-box-arrow-in-right me-2"></i> Sign In
                </button>
            </form>

            <div class="public-ticket-section">
                <div class="text-center mb-3">
                    <span class="text-muted small">or</span>
                </div>
                <div class="row g-2">
                    <?php if ($registration_enabled): ?>
                    <div class="col-6">
                        <a href="register.php" class="btn-outline-register">
                            <i class="bi bi-person-plus me-2"></i> Create Account
                        </a>
                    </div>
                    <?php endif; ?>
                    <div class="<?= $registration_enabled ? 'col-6' : 'col-12' ?>">
                        <a href="ticket-assistance.php" class="btn-outline-ticket">
                            <i class="bi bi-headset me-2"></i> Submit Ticket
                        </a>
                    </div>
                </div>
                <p class="text-center text-muted small mt-3 mb-0">
                    <i class="bi bi-clock"></i> No account? <?= $registration_enabled ? 'Register now or ' : '' ?>submit a support ticket
                </p>
            </div>
            
            <div class="login-footer">
                <a href="privacy-policy.php">Privacy Policy</a>
                <span class="mx-2">•</span>
                <a href="terms.php">Terms of Service</a>
                <span class="mx-2">•</span>
                <a href="contact.php">Contact Support</a>
            </div>
            
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password visibility toggle
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const icon = this.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });
        
        // Rate limiting for login attempts (client-side)
        let loginAttempts = parseInt(localStorage.getItem('loginAttempts') || '0');
        const maxAttempts = <?= $max_login_attempts ?>;
        const lockoutTime = <?= $lockout_duration ?> * 60 * 1000;
        
        function checkRateLimit() {
            const lastAttempt = localStorage.getItem('lastLoginAttempt');
            
            if (lastAttempt && (Date.now() - parseInt(lastAttempt)) < lockoutTime && loginAttempts >= maxAttempts) {
                const minutesLeft = Math.ceil((lockoutTime - (Date.now() - parseInt(lastAttempt))) / 60000);
                const errorDiv = document.createElement('div');
                errorDiv.className = 'alert alert-danger alert-custom mt-3';
                errorDiv.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-2"></i>Too many failed attempts. Please try again in ${minutesLeft} minutes.`;
                
                const form = document.getElementById('loginForm');
                const existingAlert = form.querySelector('.alert-danger');
                if (existingAlert) existingAlert.remove();
                form.insertBefore(errorDiv, form.firstChild);
                
                document.getElementById('loginBtn').disabled = true;
                setTimeout(() => {
                    document.getElementById('loginBtn').disabled = false;
                }, lockoutTime - (Date.now() - parseInt(lastAttempt)));
                
                return false;
            }
            return true;
        }
        
        function recordLoginAttempt() {
            loginAttempts++;
            localStorage.setItem('loginAttempts', loginAttempts);
            localStorage.setItem('lastLoginAttempt', Date.now());
        }
        
        function resetLoginAttempts() {
            localStorage.removeItem('loginAttempts');
            localStorage.removeItem('lastLoginAttempt');
            loginAttempts = 0;
        }
        
        // Form submission with rate limiting
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            if (!checkRateLimit()) {
                e.preventDefault();
            } else {
                recordLoginAttempt();
            }
        });
        
        // Reset attempts on successful login (will be called after redirect)
        if (window.location.search.includes('login=success')) {
            resetLoginAttempts();
        }
    </script>
</body>
</html>