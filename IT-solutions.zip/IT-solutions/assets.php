<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Create CSV import queue table if not exists
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `csv_import_queue` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `row_index` INT(11) NOT NULL,
            `asset_tag` VARCHAR(50) DEFAULT NULL,
            `name` VARCHAR(200) DEFAULT NULL,
            `category` VARCHAR(50) DEFAULT 'other',
            `serial_number` VARCHAR(100) DEFAULT NULL,
            `model` VARCHAR(100) DEFAULT NULL,
            `manufacturer` VARCHAR(100) DEFAULT NULL,
            `purchase_date` DATE DEFAULT NULL,
            `warranty_expiry` DATE DEFAULT NULL,
            `cost` DECIMAL(10,2) DEFAULT NULL,
            `notes` TEXT,
            `validation_status` ENUM('pending','valid','error','skipped') DEFAULT 'pending',
            `validation_message` TEXT,
            `selected_for_import` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_validation_status` (`validation_status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
} catch (PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
}

// Get all assets with user assignment info
$assets = $pdo->query("
    SELECT a.*, u.username as assigned_username 
    FROM assets a 
    LEFT JOIN users u ON a.assigned_to = u.id 
    ORDER BY a.created_at DESC
")->fetchAll();

// Get all users for assignment dropdown
$users = $pdo->query("SELECT id, username FROM users ORDER BY username")->fetchAll();

// Statistics
$total_assets = count($assets);
$available_assets = count(array_filter($assets, fn($a) => $a['status'] == 'available'));
$assigned_assets = count(array_filter($assets, fn($a) => $a['status'] == 'assigned'));
$maintenance_assets = count(array_filter($assets, fn($a) => $a['status'] == 'maintenance'));

// Get existing CSV import queue
$existing_queue = $pdo->query("SELECT * FROM csv_import_queue ORDER BY row_index ASC")->fetchAll();

// Get unread notifications count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$_SESSION['user_id']]);
$unreadCount = $stmt->fetchColumn();

// Display columns for the table
$display_columns = [
    ['label' => 'Asset Tag',    'width' => '12%', 'icon' => 'bi-tag',        'class' => ''],
    ['label' => 'Name',         'width' => '15%', 'icon' => 'bi-box',        'class' => ''],
    ['label' => 'Category',     'width' => '10%', 'icon' => 'bi-folder',     'class' => ''],
    ['label' => 'Serial #',     'width' => '10%', 'icon' => 'bi-upc-scan',   'class' => ''],
    ['label' => 'Model',        'width' => '10%', 'icon' => 'bi-device-ssd', 'class' => ''],
    ['label' => 'Manufacturer', 'width' => '10%', 'icon' => 'bi-building',   'class' => ''],
    ['label' => 'Status',       'width' => '10%', 'icon' => 'bi-toggle-on',  'class' => ''],
    ['label' => 'Assigned To',  'width' => '13%', 'icon' => 'bi-person',     'class' => ''],
    ['label' => 'Actions',      'width' => '10%', 'icon' => 'bi-gear',       'class' => 'text-center']
];

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_status':
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
            $status = $_POST['status'] ?? '';
            $validStatuses = ['available', 'assigned', 'maintenance', 'retired', 'lost'];
            if (!$id || !in_array($status, $validStatuses)) {
                echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
                exit();
            }
            $stmt = $pdo->prepare("UPDATE assets SET status = ? WHERE id = ?");
            $success = $stmt->execute([$status, $id]);
            echo json_encode(['success' => $success]);
            break;

        case 'assign':
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
            $userId = filter_var($_POST['user_id'] ?? 0, FILTER_VALIDATE_INT);
            if (!$id || !$userId) {
                echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
                exit();
            }
            $stmt = $pdo->prepare("UPDATE assets SET assigned_to = ?, status = 'assigned' WHERE id = ?");
            $success = $stmt->execute([$userId, $id]);
            echo json_encode(['success' => $success]);
            break;

        case 'unassign':
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Invalid ID']);
                exit();
            }
            $stmt = $pdo->prepare("UPDATE assets SET assigned_to = NULL, status = 'available' WHERE id = ?");
            $success = $stmt->execute([$id]);
            echo json_encode(['success' => $success]);
            break;

        case 'delete':
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Invalid ID']);
                exit();
            }
            $stmt = $pdo->prepare("DELETE FROM assets WHERE id = ?");
            $success = $stmt->execute([$id]);
            echo json_encode(['success' => $success]);
            break;

        case 'add':
            $assetTag     = trim($_POST['asset_tag'] ?? '');
            $name         = trim($_POST['name'] ?? '');
            $category     = $_POST['category'] ?? 'other';
            $serialNumber = trim($_POST['serial_number'] ?? '');
            $model        = trim($_POST['model'] ?? '');
            $manufacturer = trim($_POST['manufacturer'] ?? '');
            $purchaseDate = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
            $warrantyExpiry = !empty($_POST['warranty_expiry']) ? $_POST['warranty_expiry'] : null;
            $cost         = !empty($_POST['cost']) ? floatval($_POST['cost']) : null;
            $notes        = trim($_POST['notes'] ?? '');

            if (empty($assetTag) || empty($name)) {
                echo json_encode(['success' => false, 'error' => 'Asset tag and name are required']);
                exit();
            }
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM assets WHERE asset_tag = ?");
            $stmt->execute([$assetTag]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'error' => 'Asset tag already exists']);
                exit();
            }
            $stmt = $pdo->prepare("
                INSERT INTO assets (asset_tag, name, category, serial_number, model, manufacturer, purchase_date, warranty_expiry, cost, notes, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', NOW())
            ");
            $success = $stmt->execute([$assetTag, $name, $category, $serialNumber, $model, $manufacturer, $purchaseDate, $warrantyExpiry, $cost, $notes]);
            echo json_encode(['success' => $success]);
            break;

        case 'upload_csv':
            if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'error' => 'File upload failed']);
                exit();
            }
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');
            if (!$handle) {
                echo json_encode(['success' => false, 'error' => 'Cannot read file']);
                exit();
            }
            $pdo->exec("TRUNCATE TABLE csv_import_queue");
            $headers = fgetcsv($handle);
            $expectedHeaders = ['asset_tag','name','category','serial_number','model','manufacturer','purchase_date','warranty_expiry','cost','notes'];
            $rowIndex = 1;
            $importedRows = 0;
            $errorRows = 0;
            while (($data = fgetcsv($handle)) !== false) {
                $rowIndex++;
                $assetData = [];
                foreach ($expectedHeaders as $idx => $header) {
                    $assetData[$header] = isset($data[$idx]) ? trim($data[$idx]) : '';
                }
                $validationStatus = 'pending';
                $validationMessage = '';
                if (empty($assetData['asset_tag'])) {
                    $validationStatus = 'error';
                    $validationMessage = 'Asset tag is required';
                } elseif (empty($assetData['name'])) {
                    $validationStatus = 'error';
                    $validationMessage = 'Asset name is required';
                } else {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM assets WHERE asset_tag = ?");
                    $stmt->execute([$assetData['asset_tag']]);
                    if ($stmt->fetchColumn() > 0) {
                        $validationStatus = 'skipped';
                        $validationMessage = 'Asset tag already exists in system';
                    } elseif (!empty($assetData['purchase_date']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $assetData['purchase_date'])) {
                        $validationStatus = 'error';
                        $validationMessage = 'Invalid purchase date format. Use YYYY-MM-DD';
                    } elseif (!empty($assetData['warranty_expiry']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $assetData['warranty_expiry'])) {
                        $validationStatus = 'error';
                        $validationMessage = 'Invalid warranty date format. Use YYYY-MM-DD';
                    } else {
                        $validationStatus = 'valid';
                        $validationMessage = 'Ready to import';
                    }
                }
                $stmt = $pdo->prepare("
                    INSERT INTO csv_import_queue (row_index, asset_tag, name, category, serial_number, model, manufacturer, purchase_date, warranty_expiry, cost, notes, validation_status, validation_message, selected_for_import) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $selected = ($validationStatus === 'valid') ? 1 : 0;
                $ok = $stmt->execute([
                    $rowIndex, $assetData['asset_tag'], $assetData['name'], $assetData['category'],
                    $assetData['serial_number'], $assetData['model'], $assetData['manufacturer'],
                    !empty($assetData['purchase_date']) ? $assetData['purchase_date'] : null,
                    !empty($assetData['warranty_expiry']) ? $assetData['warranty_expiry'] : null,
                    !empty($assetData['cost']) ? floatval($assetData['cost']) : null,
                    $assetData['notes'], $validationStatus, $validationMessage, $selected
                ]);
                if ($ok) {
                    $importedRows++;
                    if ($validationStatus === 'error') $errorRows++;
                }
            }
            fclose($handle);
            echo json_encode([
                'success'  => true,
                'imported' => $importedRows,
                'errors'   => $errorRows,
                'message'  => "Processed $importedRows rows, $errorRows have errors"
            ]);
            break;

        case 'get_queue':
            $queue = $pdo->query("SELECT * FROM csv_import_queue ORDER BY row_index ASC")->fetchAll();
            echo json_encode(['success' => true, 'queue' => $queue]);
            break;

        case 'update_queue_selection':
            $queueId  = filter_var($_POST['queue_id'] ?? 0, FILTER_VALIDATE_INT);
            $selected = filter_var($_POST['selected'] ?? 0, FILTER_VALIDATE_INT);
            if (!$queueId) {
                echo json_encode(['success' => false, 'error' => 'Invalid queue ID']);
                exit();
            }
            $stmt = $pdo->prepare("UPDATE csv_import_queue SET selected_for_import = ? WHERE id = ?");
            $success = $stmt->execute([$selected, $queueId]);
            echo json_encode(['success' => $success]);
            break;

        case 'import_selected':
            $queue = $pdo->query("SELECT * FROM csv_import_queue WHERE selected_for_import = 1 AND validation_status = 'valid'")->fetchAll();
            if (empty($queue)) {
                echo json_encode(['success' => false, 'error' => 'No valid rows selected for import']);
                exit();
            }
            $imported = 0;
            $failed   = 0;
            $errors   = [];
            foreach ($queue as $row) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM assets WHERE asset_tag = ?");
                $stmt->execute([$row['asset_tag']]);
                if ($stmt->fetchColumn() > 0) {
                    $failed++;
                    $errors[] = "Asset tag {$row['asset_tag']} already exists";
                    continue;
                }
                $stmt = $pdo->prepare("
                    INSERT INTO assets (asset_tag, name, category, serial_number, model, manufacturer, purchase_date, warranty_expiry, cost, notes, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', NOW())
                ");
                $ok = $stmt->execute([
                    $row['asset_tag'], $row['name'], $row['category'],
                    $row['serial_number'], $row['model'], $row['manufacturer'],
                    $row['purchase_date'], $row['warranty_expiry'], $row['cost'], $row['notes']
                ]);
                if ($ok) {
                    $imported++;
                    $upd = $pdo->prepare("UPDATE csv_import_queue SET validation_status = 'imported' WHERE id = ?");
                    $upd->execute([$row['id']]);
                } else {
                    $failed++;
                    $errors[] = "Failed to import {$row['asset_tag']}";
                }
            }
            $pdo->exec("DELETE FROM csv_import_queue WHERE validation_status IN ('imported', 'skipped')");
            echo json_encode(['success' => true, 'imported' => $imported, 'failed' => $failed, 'errors' => $errors]);
            break;

        case 'clear_queue':
            $pdo->exec("TRUNCATE TABLE csv_import_queue");
            echo json_encode(['success' => true]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit();
}

// Build assets JSON for the View All modal (safe, encoded)
$assetsJson = json_encode(array_map(fn($a) => [
    'id'               => $a['id'],
    'asset_tag'        => $a['asset_tag'],
    'name'             => $a['name'],
    'category'         => $a['category'],
    'serial_number'    => $a['serial_number'] ?? '',
    'model'            => $a['model'] ?? '',
    'manufacturer'     => $a['manufacturer'] ?? '',
    'status'           => $a['status'],
    'assigned_to'      => $a['assigned_to'],
    'assigned_username'=> $a['assigned_username'] ?? '',
    'purchase_date'    => $a['purchase_date'] ?? '',
    'warranty_expiry'  => $a['warranty_expiry'] ?? '',
    'cost'             => $a['cost'] ?? '',
    'notes'            => $a['notes'] ?? '',
], $assets));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Management | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }

        /* Navbar */
        .navbar { background: var(--primary-gradient); box-shadow: 0 4px 20px rgba(0,0,0,0.12); padding: 0.75rem 1.5rem; }
        .navbar-brand { font-weight: 700; font-size: 1.4rem; letter-spacing: -0.5px; display: flex; align-items: center; gap: 10px; color: white; }
        .navbar-brand i { font-size: 1.6rem; }
        .navbar-brand:hover { color: white; }
        .navbar-nav .nav-link { color: rgba(255,255,255,0.9) !important; font-weight: 500; padding: 0.5rem 1rem; border-radius: 10px; transition: all 0.3s ease; margin: 0 2px; }
        .navbar-nav .nav-link:hover { background: rgba(255,255,255,0.15); transform: translateY(-2px); }
        .navbar-nav .nav-link.active { background: rgba(255,255,255,0.25); font-weight: 600; }

        /* Notification Bell */
        .notification-bell { position: relative; cursor: pointer; padding: 0.5rem; border-radius: 50%; transition: all 0.3s ease; color: white; }
        .notification-bell:hover { background: rgba(255,255,255,0.15); }
        .notification-badge {
            position: absolute; top: -5px; right: -5px;
            background: #ef4444; color: white; border-radius: 50%;
            font-size: 0.6rem; font-weight: 600; min-width: 18px; height: 18px;
            display: flex; align-items: center; justify-content: center;
            border: 2px solid var(--primary);
        }
        .notifications-dropdown { width: 380px; max-height: 500px; overflow-y: auto; border-radius: 16px; border: none; box-shadow: 0 20px 40px -12px rgba(0,0,0,0.2); padding: 0; }
        .notifications-header { padding: 1rem 1.25rem; border-bottom: 1px solid #e9ecef; background: white; position: sticky; top: 0; z-index: 1; }
        .notification-item { padding: 0.875rem 1.25rem; border-bottom: 1px solid #f1f5f9; transition: all 0.2s ease; cursor: pointer; }
        .notification-item:hover { background: #fefce8; }
        .notification-item.unread { background: var(--primary-light); border-left: 3px solid var(--primary); }
        .notification-icon { width: 36px; height: 36px; border-radius: 12px; background: #fed7aa; color: #f59e0b; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }

        /* Layout */
        .main-content { margin-top: 80px; padding: 24px 28px; animation: fadeIn 0.4s ease-out; }
        @keyframes fadeIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }

        /* Stat Cards */
        .stat-card { background: white; border-radius: 20px; padding: 1.25rem; transition: all 0.3s cubic-bezier(0.4,0,0.2,1); border: 1px solid rgba(0,0,0,0.05); position: relative; overflow: hidden; cursor: pointer; }
        .stat-card::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background: var(--primary-gradient); }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 20px 35px -12px rgba(0,0,0,0.15); }
        .stat-icon { width:50px; height:50px; border-radius:15px; display:flex; align-items:center; justify-content:center; font-size:1.8rem; }
        .stat-value { font-size:2rem; font-weight:700; color:#1e293b; line-height:1.2; }
        .stat-label { font-size:0.75rem; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; }

        /* Main Card */
        .main-card { background: white; border-radius: 24px; box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12); overflow: hidden; border: none; }
        .card-header-custom { background: white; padding: 1.25rem 1.5rem; border-bottom: 1px solid #e9ecef; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        .card-header-custom h5 { font-weight:700; color:#1e293b; margin:0; display:flex; align-items:center; gap:10px; }
        .card-header-custom h5 i { color: var(--primary); font-size:1.4rem; }

        /* Buttons */
        .btn-primary { background: var(--primary-gradient); border: none; color: white; font-weight:600; padding:0.5rem 1.25rem; border-radius:12px; transition: all 0.3s ease; display:inline-flex; align-items:center; gap:8px; }
        .btn-primary:hover { transform:translateY(-2px); box-shadow:0 8px 20px rgba(243,156,18,0.3); color:white; }
        .btn-outline-primary { border:2px solid var(--primary); background:transparent; color: var(--primary); font-weight:600; border-radius:12px; transition:all 0.3s ease; }
        .btn-outline-primary:hover { background: var(--primary-gradient); border-color:transparent; color:white; transform:translateY(-1px); }

        /* Import Area */
        .import-area { border: 2px dashed #cbd5e1; border-radius: 20px; padding: 32px 24px; text-align: center; transition: all 0.3s ease; cursor: pointer; background: #f8fafc; }
        .import-area:hover, .import-area.dragover { border-color: var(--primary); background: var(--primary-light); }
        .import-area i.upload-icon { font-size: 3rem; color: #94a3b8; transition: color 0.3s; }
        .import-area:hover i.upload-icon { color: var(--primary); }
        .file-preview { display: none; align-items: center; gap: 12px; background: var(--primary-light); border: 1px solid #fcd34d; border-radius: 16px; padding: 12px 16px; margin-top: 16px; }
        .file-preview.show { display: flex; }
        .file-preview i { color: var(--primary); font-size: 1.5rem; }
        .file-preview .file-info { flex: 1; text-align: left; }
        .file-preview .file-name { font-weight: 600; font-size: 0.85rem; color: #334155; }
        .file-preview .file-size { font-size: 0.7rem; color: #64748b; }
        .help-text { background: #f8fafc; border-radius: 16px; padding: 12px 16px; font-size: 0.75rem; color: #64748b; }

        /* Queue Panel */
        .queue-panel { background: white; border-radius: 24px; box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12); overflow: hidden; margin-top: 24px; }
        .queue-panel-header { background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); padding: 1rem 1.5rem; border-bottom: 1px solid #fde68a; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .queue-panel-header h6 { font-weight: 700; color: #92400e; margin: 0; }
        .queue-filter-bar { padding: 0.75rem 1.25rem; background: #fafafa; border-bottom: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        .q-filter-btn { padding: 3px 12px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; cursor: pointer; border: 1px solid #e2e8f0; background: white; transition: all 0.2s ease; }
        .q-filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        .queue-table-wrap { max-height: 380px; overflow-y: auto; }
        .queue-tbl { margin-bottom: 0; font-size: 0.78rem; }
        .queue-tbl thead th { position: sticky; top: 0; background: #f8fafc; z-index: 5; padding: 0.65rem 0.75rem; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #475569; border-bottom: 2px solid #e2e8f0; white-space: nowrap; }
        .queue-tbl tbody td { padding: 0.55rem 0.75rem; vertical-align: middle; }
        .q-valid   { background-color: #f0fdf4 !important; }
        .q-error   { background-color: #fef2f2 !important; }
        .q-skipped { background-color: #f3f4f6 !important; opacity: 0.7; }
        .q-pending { background-color: #fffbeb !important; }
        .vbadge    { font-size: 0.68rem; padding: 2px 9px; border-radius: 20px; font-weight: 600; white-space: nowrap; }
        .vb-valid   { background: #d4f8e8; color: #065f46; }
        .vb-error   { background: #fee2e2; color: #991b1b; }
        .vb-skipped { background: #e2e8f0; color: #475569; }
        .vb-pending { background: #fed7aa; color: #9b2c1d; }
        .queue-empty { text-align: center; padding: 2rem; color: #94a3b8; }
        .queue-stat-pill { display: inline-flex; align-items: center; gap: 5px; background: white; border: 1px solid #e2e8f0; border-radius: 20px; padding: 3px 10px; font-size: 0.72rem; font-weight: 600; }

        /* Asset Table */
        .assets-table { margin-bottom:0; }
        .assets-table thead th { background:#f8fafc; color:#475569; font-weight:600; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.5px; padding:1rem; border-bottom:2px solid #e2e8f0; white-space:nowrap; }
        .assets-table tbody tr { transition:all 0.2s ease; border-bottom:1px solid #f1f5f9; }
        .assets-table tbody tr:hover { background:#fefce8; transform:scale(1.01); box-shadow:0 2px 8px rgba(0,0,0,0.05); }
        .assets-table tbody td { padding:1rem; vertical-align:middle; color:#334155; font-size:0.85rem; }
        .asset-code { font-family:'Monaco','Courier New',monospace; background:#f1f5f9; padding:4px 10px; border-radius:10px; font-size:0.8rem; font-weight:600; color:#1e293b; }
        .category-badge { background:#e2e8f0; color:#475569; padding:4px 10px; border-radius:30px; font-size:0.7rem; font-weight:500; display:inline-flex; align-items:center; gap:5px; }
        .status-select, .assign-select { font-size:0.75rem; padding:0.35rem 2rem 0.35rem 0.75rem; border-radius:10px; border:1px solid #e2e8f0; background-color:white; cursor:pointer; transition:all 0.2s ease; }
        .status-select:focus, .assign-select:focus { border-color: var(--primary); box-shadow:0 0 0 3px rgba(243,156,18,0.1); }
        .action-btn { padding:6px 10px; border-radius:10px; transition:all 0.2s ease; border:none; background:transparent; }
        .action-btn:hover { transform:scale(1.05); }
        .unassign-asset, .delete-asset { color:#ef4444; background:#fee2e2; }
        .unassign-asset:hover, .delete-asset:hover { background:#ef4444; color:white; }

        /* Search */
        .search-box { position:relative; }
        .search-box i { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:#94a3b8; font-size:0.9rem; }
        .search-box input { padding-left:38px; border-radius:30px; border:1px solid #e2e8f0; width:260px; transition:all 0.3s ease; font-size:0.85rem; }
        .search-box input:focus { border-color: var(--primary); box-shadow:0 0 0 3px rgba(243,156,18,0.1); width:300px; }

        /* Modals */
        .modal-content { border-radius:24px; border:none; overflow:hidden; }
        .modal-header { background: linear-gradient(135deg,#fef3c7 0%,#fffbeb 100%); border-bottom:1px solid #fde68a; padding:1.25rem 1.5rem; }
        .modal-header h5 { font-weight:700; color:#92400e; }
        .modal-header h5 i { color: var(--primary); }
        .modal-body { padding:1.75rem; }
        .modal-footer { border-top:1px solid #e9ecef; padding:1.25rem 1.5rem; }
        .form-label { font-weight:600; font-size:0.8rem; color:#475569; margin-bottom:0.4rem; }
        .form-control, .form-select { border-radius:12px; border:1px solid #e2e8f0; padding:0.6rem 1rem; transition:all 0.2s ease; }
        .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow:0 0 0 3px rgba(243,156,18,0.1); }

        /* Empty state */
        .empty-state { text-align:center; padding:3rem; color:#94a3b8; }
        .empty-state i { font-size:3rem; margin-bottom:1rem; opacity:0.5; }

        /* View All Modal */
        .view-all-header { background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%); border-bottom: 2px solid #fde68a; padding: 1.5rem 2rem; }
        .view-all-header h4 { font-weight: 800; color: #92400e; margin: 0; display: flex; align-items: center; gap: 12px; }
        .view-all-header h4 i { font-size: 2rem; color: var(--primary); }
        .view-all-stats { background: white; padding: 1rem 2rem; border-bottom: 1px solid #e2e8f0; display: flex; gap: 20px; flex-wrap: wrap; align-items: center; }
        .view-all-stat-badge { background: #f8fafc; padding: 6px 15px; border-radius: 30px; font-size: 0.8rem; font-weight: 600; color: #475569; }
        .view-all-filters { padding: 1rem 2rem; background: #fafafa; border-bottom: 1px solid #e2e8f0; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .view-all-search { flex: 1; min-width: 200px; position: relative; }
        .view-all-search i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        .view-all-search input { width: 100%; padding: 8px 12px 8px 35px; border: 1px solid #e2e8f0; border-radius: 25px; font-size: 0.85rem; transition: all 0.3s ease; }
        .view-all-search input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(243,156,18,0.1); }
        .view-all-filter-select { padding: 8px 15px; border: 1px solid #e2e8f0; border-radius: 25px; font-size: 0.85rem; background: white; cursor: pointer; }
        .view-all-table-wrap { max-height: 60vh; overflow-y: auto; padding: 0; }
        .view-all-table { margin-bottom: 0; font-size: 0.8rem; }
        .view-all-table thead th { position: sticky; top: 0; background: #f8fafc; z-index: 10; padding: 1rem; font-weight: 700; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: #475569; border-bottom: 2px solid #e2e8f0; white-space: nowrap; }
        .view-all-table tbody tr { transition: all 0.2s ease; border-bottom: 1px solid #f1f5f9; }
        .view-all-table tbody tr:hover { background: #fefce8; }
        .view-all-table tbody td { padding: 0.9rem 1rem; vertical-align: middle; color: #334155; }
        .status-badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 600; }
        .status-available   { background: #d4f8e8; color: #065f46; }
        .status-assigned    { background: #dbeafe; color: #1e40af; }
        .status-maintenance { background: #fed7aa; color: #9b2c1d; }
        .status-retired     { background: #e2e8f0; color: #475569; }
        .status-lost        { background: #fee2e2; color: #991b1b; }
        .view-all-footer { padding: 1rem 2rem; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center; font-size: 0.75rem; color: #64748b; }

        /* Responsive */
        @media (max-width:768px) {
            .main-content { padding:16px; margin-top:70px; }
            .card-header-custom { flex-direction:column; align-items:stretch; }
            .search-box input, .search-box input:focus { width:100%; }
            .stat-value { font-size:1.5rem; }
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width:8px; height:8px; }
        ::-webkit-scrollbar-track { background:#f1f1f1; border-radius:10px; }
        ::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary); }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php"><i class="bi bi-laptop me-1"></i> Devices</a></li>
                    <li class="nav-item"><a class="nav-link active" href="assets.php"><i class="bi bi-box-seam me-1"></i> Assets</a></li>
                    <li class="nav-item"><a class="nav-link" href="tickets.php"><i class="bi bi-ticket-detailed me-1"></i> Tickets</a></li>
                    <li class="nav-item"><a class="nav-link" href="technicians.php"><i class="bi bi-people me-1"></i> Technicians</a></li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <!-- BUG FIX: badge always rendered, visibility controlled by JS -->
                            <span class="notification-badge" id="notifBadge" style="display:<?= $unreadCount > 0 ? 'flex' : 'none' ?>">
                                <?= min($unreadCount, 99) ?>
                            </span>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header d-flex justify-content-between align-items-center">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small">View all notifications</a>
                            </div>
                        </div>
                    </li>

                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Stat Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="openViewAllModal()">
                    <div class="d-flex align-items-center justify-content-between">
                        <div><div class="stat-value"><?= $total_assets ?></div><div class="stat-label">Total Assets</div></div>
                        <div class="stat-icon" style="background:var(--primary-light);color:var(--primary);"><i class="bi bi-box-seam"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="openViewAllModal('available')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div><div class="stat-value text-success"><?= $available_assets ?></div><div class="stat-label">Available</div></div>
                        <div class="stat-icon" style="background:#d4f8e8;color:#10b981;"><i class="bi bi-check-circle-fill"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="openViewAllModal('assigned')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div><div class="stat-value text-primary"><?= $assigned_assets ?></div><div class="stat-label">Assigned</div></div>
                        <div class="stat-icon" style="background:#dbeafe;color:#3b82f6;"><i class="bi bi-person-check-fill"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="openViewAllModal('maintenance')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div><div class="stat-value text-warning"><?= $maintenance_assets ?></div><div class="stat-label">Maintenance</div></div>
                        <div class="stat-icon" style="background:#fed7aa;color:#f59e0b;"><i class="bi bi-tools"></i></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Upload + Inventory Row -->
        <div class="row g-4">
            <!-- CSV Import Card -->
            <div class="col-lg-4">
                <div class="main-card h-100">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-upload me-2"></i> Bulk Import Assets</h5>
                        <button class="btn btn-outline-primary btn-sm" onclick="downloadTemplate()">
                            <i class="bi bi-download"></i> Template
                        </button>
                    </div>
                    <div class="card-body p-4">
                        <div class="import-area" id="dropZone">
                            <i class="bi bi-filetype-csv upload-icon"></i>
                            <p class="mt-3 mb-1 fw-semibold text-secondary">Drag & drop your CSV here</p>
                            <p class="mb-0 text-muted" style="font-size:0.8rem;">or <span style="color:var(--primary);text-decoration:underline;">browse to upload</span></p>
                            <small class="text-muted d-block mt-2">Supported: .csv files only</small>
                            <input type="file" name="csv_file" id="csv_file_input" accept=".csv" style="display:none;">
                        </div>

                        <div class="file-preview" id="filePreview">
                            <i class="bi bi-file-earmark-spreadsheet-fill"></i>
                            <div class="file-info">
                                <div class="file-name" id="fileName">—</div>
                                <div class="file-size" id="fileSize">—</div>
                            </div>
                            <!-- BUG FIX: stopPropagation prevents re-opening file picker on remove -->
                            <button type="button" class="btn btn-sm btn-outline-danger" id="removeFile" title="Remove file">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>

                        <div id="importProgress" style="display:none;" class="mt-3">
                            <div class="d-flex justify-content-between mb-1">
                                <small class="text-muted">Processing CSV...</small>
                            </div>
                            <div class="progress" style="height:6px;border-radius:10px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning" style="width:100%"></div>
                            </div>
                        </div>

                        <div class="help-text mt-4">
                            <i class="bi bi-info-circle me-1 text-warning"></i>
                            <strong>Required columns:</strong> asset_tag, name<br>
                            <i class="bi bi-check-circle me-1 text-success"></i>
                            Duplicate asset tags will be highlighted and skipped.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Asset Inventory Table -->
            <div class="col-lg-8">
                <div class="main-card">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-grid-3x3-gap-fill me-2"></i> Asset Inventory</h5>
                        <div class="d-flex gap-2 flex-wrap">
                            <div class="search-box">
                                <i class="bi bi-search"></i>
                                <input type="text" id="searchInput" class="form-control" placeholder="Search assets...">
                            </div>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAssetModal">
                                <i class="bi bi-plus-lg"></i> Add Asset
                            </button>
                            <button class="btn btn-outline-primary" onclick="openViewAllModal()">
                                <i class="bi bi-eye"></i> View All
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table assets-table mb-0" id="assetsTable">
                            <thead>
                                <tr>
                                    <?php foreach ($display_columns as $col): ?>
                                        <th style="width:<?= $col['width'] ?>;" class="<?= $col['class'] ?? '' ?>">
                                            <i class="<?= $col['icon'] ?> me-1"></i> <?= $col['label'] ?>
                                        </th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody id="assetsTableBody">
                                <?php if (empty($assets)): ?>
                                    <tr>
                                        <td colspan="<?= count($display_columns) ?>" class="empty-state">
                                            <i class="bi bi-inbox"></i>
                                            <p class="mb-0">No assets found. Click "Add Asset" to get started.</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($assets as $asset): ?>
                                        <tr data-id="<?= $asset['id'] ?>">
                                            <td><span class="asset-code"><?= htmlspecialchars($asset['asset_tag']) ?></span></td>
                                            <td class="fw-semibold"><?= htmlspecialchars($asset['name']) ?></td>
                                            <td><span class="category-badge"><i class="bi bi-folder"></i> <?= ucfirst($asset['category']) ?></span></td>
                                            <td><small><?= htmlspecialchars($asset['serial_number'] ?: '—') ?></small></td>
                                            <td><small><?= htmlspecialchars($asset['model'] ?: '—') ?></small></td>
                                            <td><small><?= htmlspecialchars($asset['manufacturer'] ?: '—') ?></small></td>
                                            <td>
                                                <select class="status-select" data-id="<?= $asset['id'] ?>" onchange="updateAssetStatus(<?= $asset['id'] ?>, this.value)">
                                                    <option value="available"   <?= $asset['status']==='available'   ? 'selected':'' ?>>🟢 Available</option>
                                                    <option value="assigned"    <?= $asset['status']==='assigned'    ? 'selected':'' ?>>🔵 Assigned</option>
                                                    <option value="maintenance" <?= $asset['status']==='maintenance' ? 'selected':'' ?>>🟠 Maintenance</option>
                                                    <option value="retired"     <?= $asset['status']==='retired'     ? 'selected':'' ?>>⚪ Retired</option>
                                                    <option value="lost"        <?= $asset['status']==='lost'        ? 'selected':'' ?>>🔴 Lost</option>
                                                </select>
                                            </td>
                                            <td>
                                                <?php if ($asset['assigned_to']): ?>
                                                    <div class="d-flex align-items-center gap-1">
                                                        <span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1 rounded-pill">
                                                            <i class="bi bi-person-check me-1"></i><?= htmlspecialchars($asset['assigned_username']) ?>
                                                        </span>
                                                        <button class="action-btn unassign-asset" onclick="unassignAsset(<?= $asset['id'] ?>)" title="Unassign">
                                                            <i class="bi bi-x-circle"></i>
                                                        </button>
                                                    </div>
                                                <?php else: ?>
                                                    <select class="assign-select" onchange="assignAsset(<?= $asset['id'] ?>, this.value)">
                                                        <option value="">📋 Assign to...</option>
                                                        <?php foreach ($users as $user): ?>
                                                            <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['username']) ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <button class="action-btn delete-asset" onclick="deleteAsset(<?= $asset['id'] ?>)" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div><!-- /row -->

        <!-- CSV Queue Panel -->
        <div class="queue-panel" id="queuePanel" <?= empty($existing_queue) ? 'style="display:none;"' : '' ?>>
            <div class="queue-panel-header">
                <div>
                    <h6><i class="bi bi-list-check me-2"></i> CSV Import Queue</h6>
                    <div class="d-flex flex-wrap gap-2 mt-2" id="queueStats">
                        <?php
                        if (!empty($existing_queue)) {
                            $qt = count($existing_queue);
                            $qv = count(array_filter($existing_queue, fn($i) => $i['validation_status']==='valid'));
                            $qe = count(array_filter($existing_queue, fn($i) => $i['validation_status']==='error'));
                            $qs = count(array_filter($existing_queue, fn($i) => $i['validation_status']==='skipped'));
                        ?>
                        <span class="queue-stat-pill"><span class="text-muted">Total</span> <strong><?= $qt ?></strong></span>
                        <span class="queue-stat-pill"><span style="color:#065f46">Valid</span> <strong><?= $qv ?></strong></span>
                        <span class="queue-stat-pill"><span style="color:#991b1b">Errors</span> <strong><?= $qe ?></strong></span>
                        <span class="queue-stat-pill"><span class="text-secondary">Skipped</span> <strong><?= $qs ?></strong></span>
                        <?php } ?>
                    </div>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button class="btn btn-sm btn-primary" onclick="importSelectedRows()">
                        <i class="bi bi-cloud-upload me-1"></i> Import Selected
                    </button>
                    <button class="btn btn-sm btn-outline-secondary" onclick="clearQueue()">
                        <i class="bi bi-trash me-1"></i> Clear
                    </button>
                </div>
            </div>

            <div class="queue-filter-bar">
                <span class="small text-muted me-1">Filter:</span>
                <button class="q-filter-btn active" data-qfilter="all">All</button>
                <button class="q-filter-btn" data-qfilter="valid">✓ Valid</button>
                <button class="q-filter-btn" data-qfilter="error">✗ Error</button>
                <button class="q-filter-btn" data-qfilter="skipped">⊘ Skipped</button>
                <div class="ms-auto">
                    <label style="font-size:0.75rem; cursor:pointer;">
                        <input type="checkbox" id="queueSelectAll"> Select all valid
                    </label>
                </div>
            </div>

            <div class="queue-table-wrap">
                <table class="table table-bordered queue-tbl mb-0" id="queueTable">
                    <thead>
                        <tr>
                            <th style="width:36px;"></th>
                            <th>#</th>
                            <th>Asset Tag</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Serial #</th>
                            <th>Model</th>
                            <th>Manufacturer</th>
                            <th>Purchase Date</th>
                            <th>Warranty Expiry</th>
                            <th>Cost</th>
                            <th>Notes</th>
                            <th>Status</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody id="queueTableBody">
                        <?php if (empty($existing_queue)): ?>
                            <tr><td colspan="14" class="queue-empty"><i class="bi bi-inbox fs-3 d-block mb-2"></i>No items in queue</td></tr>
                        <?php else: ?>
                            <?php foreach ($existing_queue as $qi):
                                $qrc = match($qi['validation_status']) {
                                    'valid'   => 'q-valid',
                                    'error'   => 'q-error',
                                    'skipped' => 'q-skipped',
                                    default   => 'q-pending'
                                };
                                $vbc = match($qi['validation_status']) {
                                    'valid'   => 'vb-valid',
                                    'error'   => 'vb-error',
                                    'skipped' => 'vb-skipped',
                                    default   => 'vb-pending'
                                };
                            ?>
                            <tr class="<?= $qrc ?>" data-qstatus="<?= $qi['validation_status'] ?>" data-qid="<?= $qi['id'] ?>">
                                <td class="text-center">
                                    <input type="checkbox" class="queue-row-selector"
                                        data-id="<?= $qi['id'] ?>"
                                        <?= $qi['selected_for_import'] ? 'checked' : '' ?>
                                        <?= $qi['validation_status'] !== 'valid' ? 'disabled' : '' ?>>
                                </td>
                                <td><?= $qi['row_index'] ?></td>
                                <td><span class="asset-code" style="font-size:0.72rem;"><?= htmlspecialchars($qi['asset_tag'] ?: '—') ?></span></td>
                                <td class="fw-semibold"><?= htmlspecialchars($qi['name'] ?: '—') ?></td>
                                <td><?= htmlspecialchars(ucfirst($qi['category'] ?: '—')) ?></td>
                                <td><small><?= htmlspecialchars($qi['serial_number'] ?: '—') ?></small></td>
                                <td><small><?= htmlspecialchars($qi['model'] ?: '—') ?></small></td>
                                <td><small><?= htmlspecialchars($qi['manufacturer'] ?: '—') ?></small></td>
                                <td><small><?= htmlspecialchars($qi['purchase_date'] ?: '—') ?></small></td>
                                <td><small><?= htmlspecialchars($qi['warranty_expiry'] ?: '—') ?></small></td>
                                <td><?= $qi['cost'] ? 'R '.number_format((float)$qi['cost'],2) : '—' ?></td>
                                <td><small><?= htmlspecialchars($qi['notes'] ?: '—') ?></small></td>
                                <td><span class="vbadge <?= $vbc ?>"><?= ucfirst($qi['validation_status']) ?></span></td>
                                <td><small class="text-muted"><?= htmlspecialchars($qi['validation_message'] ?: '—') ?></small></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="p-3 border-top bg-light" style="font-size:0.75rem; color:#64748b;">
                <i class="bi bi-info-circle me-1"></i>
                Only <span class="vbadge vb-valid mx-1">Valid</span> rows that are checked can be imported.
            </div>
        </div><!-- /queue-panel -->
    </div><!-- /main-content -->

    <!-- View All Assets Modal -->
    <div class="modal fade" id="viewAllModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-fullscreen modal-dialog-scrollable">
            <div class="modal-content">
                <div class="view-all-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4><i class="bi bi-box-seam"></i> All Assets Inventory</h4>
                        <button type="button" class="btn-close btn-close-dark" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
                <div class="view-all-stats">
                    <div class="view-all-stat-badge"><i class="bi bi-box-seam"></i> Total: <span id="statTotal"><?= $total_assets ?></span></div>
                    <div class="view-all-stat-badge"><i class="bi bi-check-circle-fill text-success"></i> Available: <span id="statAvailable"><?= $available_assets ?></span></div>
                    <div class="view-all-stat-badge"><i class="bi bi-person-check-fill text-primary"></i> Assigned: <span id="statAssigned"><?= $assigned_assets ?></span></div>
                    <div class="view-all-stat-badge"><i class="bi bi-tools text-warning"></i> Maintenance: <span id="statMaintenance"><?= $maintenance_assets ?></span></div>
                </div>
                <div class="view-all-filters">
                    <div class="view-all-search">
                        <i class="bi bi-search"></i>
                        <input type="text" id="viewAllSearch" placeholder="Search by tag, name, serial number...">
                    </div>
                    <select class="view-all-filter-select" id="viewAllStatusFilter">
                        <option value="all">All Statuses</option>
                        <option value="available">🟢 Available</option>
                        <option value="assigned">🔵 Assigned</option>
                        <option value="maintenance">🟠 Maintenance</option>
                        <option value="retired">⚪ Retired</option>
                        <option value="lost">🔴 Lost</option>
                    </select>
                    <select class="view-all-filter-select" id="viewAllCategoryFilter">
                        <option value="all">All Categories</option>
                        <option value="laptop">💻 Laptop</option>
                        <option value="desktop">🖥️ Desktop</option>
                        <option value="monitor">🖵 Monitor</option>
                        <option value="peripheral">⌨️ Peripheral</option>
                        <option value="software">📦 Software</option>
                        <option value="other">📎 Other</option>
                    </select>
                    <button class="btn btn-sm btn-primary" onclick="renderViewAll()">
                        <i class="bi bi-arrow-repeat"></i> Refresh
                    </button>
                </div>
                <div class="view-all-table-wrap">
                    <table class="table view-all-table">
                        <thead>
                            <tr>
                                <th>Asset Tag</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Serial #</th>
                                <th>Model</th>
                                <th>Manufacturer</th>
                                <th>Status</th>
                                <th>Assigned To</th>
                                <th>Purchase Date</th>
                                <th>Warranty Expiry</th>
                                <th>Cost</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody id="viewAllTableBody">
                            <tr><td colspan="12" class="text-center py-4 text-muted">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="view-all-footer" id="viewAllFooter">
                    <i class="bi bi-info-circle"></i> Use filters above to narrow down results.
                </div>
            </div>
        </div>
    </div>

    <!-- Add Asset Modal -->
    <div class="modal fade" id="addAssetModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-box-seam me-2"></i> Add New Asset</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addAssetForm" onsubmit="return false;">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Asset Tag <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="assetTag" placeholder="e.g., IT-ASSET-001" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Asset Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="assetName" placeholder="e.g., Dell XPS 15" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Category</label>
                                <select class="form-select" id="assetCategory">
                                    <option value="laptop">💻 Laptop</option>
                                    <option value="desktop">🖥️ Desktop</option>
                                    <option value="monitor">🖵 Monitor</option>
                                    <option value="peripheral">⌨️ Peripheral</option>
                                    <option value="software">📦 Software</option>
                                    <option value="other">📎 Other</option>
                                </select>
                            </div>
                            <div class="col-md-4"><label class="form-label">Serial Number</label><input type="text" class="form-control" id="serialNumber" placeholder="SN-..."></div>
                            <div class="col-md-4"><label class="form-label">Model</label><input type="text" class="form-control" id="assetModel"></div>
                            <div class="col-md-4"><label class="form-label">Manufacturer</label><input type="text" class="form-control" id="manufacturer"></div>
                            <div class="col-md-4"><label class="form-label">Purchase Date</label><input type="date" class="form-control" id="purchaseDate"></div>
                            <div class="col-md-4"><label class="form-label">Warranty Expiry</label><input type="date" class="form-control" id="warrantyExpiry"></div>
                            <div class="col-md-4"><label class="form-label">Cost (ZAR)</label><input type="number" step="0.01" min="0" class="form-control" id="assetCost" placeholder="0.00"></div>
                            <div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" id="assetNotes" rows="2" placeholder="Additional information..."></textarea></div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="addAsset()"><i class="bi bi-plus-lg me-1"></i>Add Asset</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Template Info Modal -->
    <div class="modal fade" id="templateModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-download me-2"></i> CSV Template Format</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-2">Create a CSV file with the following columns (in order):</p>
                    <div class="bg-light p-3 rounded mb-3">
                        <code class="small">asset_tag, name, category, serial_number, model, manufacturer, purchase_date, warranty_expiry, cost, notes</code>
                    </div>
                    <p class="mb-2 fw-semibold">Example row:</p>
                    <div class="bg-light p-3 rounded">
                        <code class="small">IT-ASSET-001, Dell XPS 15, laptop, SN123456, XPS 15-9520, Dell, 2024-01-15, 2026-01-15, 25000, Company laptop</code>
                    </div>
                    <hr>
                    <div class="small text-muted">
                        <i class="bi bi-info-circle"></i> Notes:
                        <ul class="mt-1 mb-0">
                            <li>Only <strong>.csv</strong> files are supported</li>
                            <li><strong>asset_tag</strong> and <strong>name</strong> are required</li>
                            <li>Dates must be in <strong>YYYY-MM-DD</strong> format</li>
                            <li>Valid categories: laptop, desktop, monitor, peripheral, software, other</li>
                            <li>Cost should be a number (no currency symbol)</li>
                        </ul>
                    </div>
                    <div class="mt-3 text-center">
                        <button class="btn btn-primary btn-sm" onclick="downloadTemplate()"><i class="bi bi-download me-1"></i> Download Sample CSV</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ========== PHP DATA BRIDGE ==========
        // BUG FIX: Embed full asset data from PHP so View All modal has purchase date, warranty, cost, notes
        const PHP_ASSETS = <?= $assetsJson ?>;

        // ========== NOTIFICATIONS ==========
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => { if (data.success) updateNotificationsUI(data.notifications, data.unread_count); })
                .catch(() => {});
        }

        function updateNotificationsUI(notifications, unreadCount) {
            const badge = document.getElementById('notifBadge');
            if (badge) {
                badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                badge.style.display = unreadCount > 0 ? 'flex' : 'none';
            }
            const list = document.getElementById('notificationsList');
            if (!list) return;
            if (!notifications || notifications.length === 0) {
                list.innerHTML = `<div class="text-center py-4 text-muted"><i class="bi bi-bell-slash fs-4"></i><p class="mb-0 small">No notifications</p></div>`;
                return;
            }
            list.innerHTML = notifications.slice(0, 10).map(n => `
                <div class="notification-item ${!n.is_read ? 'unread' : ''}">
                    <div class="d-flex gap-3">
                        <div class="notification-icon"><i class="bi bi-info-circle"></i></div>
                        <div class="flex-grow-1">
                            <div class="fw-semibold">${escapeHtml(n.title)}</div>
                            <div class="small">${escapeHtml(n.message)}</div>
                            <div class="small text-muted">${timeAgo(n.created_at)}</div>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=mark_all_read'
            }).then(r => r.json()).then(d => { if (d.success) loadNotifications(); }).catch(() => {});
        }

        function timeAgo(dateString) {
            const s = Math.floor((new Date() - new Date(dateString)) / 1000);
            if (s < 60) return 'Just now';
            const m = Math.floor(s / 60); if (m < 60) return m + ' min ago';
            const h = Math.floor(m / 60); if (h < 24) return h + ' hr ago';
            const d = Math.floor(h / 24); if (d < 7) return d + ' day' + (d > 1 ? 's' : '') + ' ago';
            return new Date(dateString).toLocaleDateString();
        }

        function escapeHtml(text) {
            if (!text) return '';
            const d = document.createElement('div');
            d.textContent = text;
            return d.innerHTML;
        }

        function ucfirst(str) {
            if (!str) return '';
            return str.charAt(0).toUpperCase() + str.slice(1);
        }

        // ========== CSV UPLOAD ==========
        const fileInput    = document.getElementById('csv_file_input');
        const filePreview  = document.getElementById('filePreview');
        const fileNameEl   = document.getElementById('fileName');
        const fileSizeEl   = document.getElementById('fileSize');
        const removeFileBtn= document.getElementById('removeFile');
        const dropZone     = document.getElementById('dropZone');
        const importProgress = document.getElementById('importProgress');

        // BUG FIX: click only triggers file input, not the whole dropzone, to avoid conflicts
        dropZone.addEventListener('click', function(e) {
            if (e.target === removeFileBtn || removeFileBtn.contains(e.target)) return;
            fileInput.click();
        });

        // BUG FIX: stopPropagation on remove button so it doesn't bubble to dropZone click
        removeFileBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            fileInput.value = '';
            filePreview.classList.remove('show');
        });

        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) handleFile(this.files[0]);
        });

        dropZone.addEventListener('dragover', function(e) { e.preventDefault(); this.classList.add('dragover'); });
        dropZone.addEventListener('dragleave', function(e) { e.preventDefault(); this.classList.remove('dragover'); });
        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file && file.name.toLowerCase().endsWith('.csv')) {
                handleFile(file);
            } else {
                showAlert('Please upload a .csv file', 'danger');
            }
        });

        function handleFile(file) {
            fileNameEl.textContent = file.name;
            fileSizeEl.textContent = (file.size / 1024).toFixed(2) + ' KB';
            filePreview.classList.add('show');
            uploadCSV(file);
        }

        function uploadCSV(file) {
            const formData = new FormData();
            formData.append('action', 'upload_csv');
            formData.append('csv_file', file);
            importProgress.style.display = 'block';
            fetch('assets.php', {
                method: 'POST',
                headers: {'X-Requested-With': 'XMLHttpRequest'},
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                importProgress.style.display = 'none';
                if (data.success) {
                    showAlert(data.message, 'success');
                    loadQueue();
                } else {
                    showAlert(data.error || 'Upload failed', 'danger');
                }
            })
            .catch(() => {
                importProgress.style.display = 'none';
                showAlert('Upload failed. Please try again.', 'danger');
            });
        }

        function loadQueue() {
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: 'action=get_queue'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.queue.length > 0) {
                    updateQueueTable(data.queue);
                    document.getElementById('queuePanel').style.display = 'block';
                } else {
                    document.getElementById('queuePanel').style.display = 'none';
                }
            })
            .catch(() => {});
        }

        function updateQueueTable(queue) {
            let html = '', valid = 0, errors = 0, skipped = 0;
            queue.forEach(row => {
                const s = row.validation_status;
                const qrc = s === 'valid' ? 'q-valid' : s === 'error' ? 'q-error' : s === 'skipped' ? 'q-skipped' : 'q-pending';
                const vbc = s === 'valid' ? 'vb-valid' : s === 'error' ? 'vb-error' : s === 'skipped' ? 'vb-skipped' : 'vb-pending';
                if (s === 'valid')   valid++;
                if (s === 'error')   errors++;
                if (s === 'skipped') skipped++;
                html += `
                    <tr class="${qrc}" data-qstatus="${s}" data-qid="${row.id}">
                        <td class="text-center">
                            <input type="checkbox" class="queue-row-selector" data-id="${row.id}"
                                ${row.selected_for_import ? 'checked' : ''}
                                ${s !== 'valid' ? 'disabled' : ''}>
                        </td>
                        <td>${row.row_index}</td>
                        <td><span class="asset-code" style="font-size:0.72rem;">${escapeHtml(row.asset_tag || '—')}</span></td>
                        <td class="fw-semibold">${escapeHtml(row.name || '—')}</td>
                        <td>${escapeHtml(ucfirst(row.category || '—'))}</td>
                        <td><small>${escapeHtml(row.serial_number || '—')}</small></td>
                        <td><small>${escapeHtml(row.model || '—')}</small></td>
                        <td><small>${escapeHtml(row.manufacturer || '—')}</small></td>
                        <td><small>${escapeHtml(row.purchase_date || '—')}</small></td>
                        <td><small>${escapeHtml(row.warranty_expiry || '—')}</small></td>
                        <td>${row.cost ? 'R ' + parseFloat(row.cost).toLocaleString('en-ZA', {minimumFractionDigits:2}) : '—'}</td>
                        <td><small>${escapeHtml((row.notes || '').substring(0, 40))}</small></td>
                        <td><span class="vbadge ${vbc}">${ucfirst(s)}</span></td>
                        <td><small class="text-muted">${escapeHtml(row.validation_message || '—')}</small></td>
                    </tr>`;
            });

            document.getElementById('queueTableBody').innerHTML = html;
            document.getElementById('queueStats').innerHTML = `
                <span class="queue-stat-pill"><span class="text-muted">Total</span> <strong>${queue.length}</strong></span>
                <span class="queue-stat-pill"><span style="color:#065f46">Valid</span> <strong>${valid}</strong></span>
                <span class="queue-stat-pill"><span style="color:#991b1b">Errors</span> <strong>${errors}</strong></span>
                <span class="queue-stat-pill"><span class="text-secondary">Skipped</span> <strong>${skipped}</strong></span>`;

            // Attach checkbox listeners
            document.querySelectorAll('.queue-row-selector').forEach(cb => {
                cb.addEventListener('change', function() {
                    updateQueueSelection(this.dataset.id, this.checked ? 1 : 0);
                });
            });

            // BUG FIX: Clone select-all to remove stacked duplicate listeners
            const oldSA = document.getElementById('queueSelectAll');
            const newSA = oldSA.cloneNode(true);
            oldSA.parentNode.replaceChild(newSA, oldSA);
            newSA.addEventListener('change', function() {
                document.querySelectorAll('.queue-row-selector:not(:disabled)').forEach(cb => {
                    cb.checked = this.checked;
                    updateQueueSelection(cb.dataset.id, cb.checked ? 1 : 0);
                });
            });

            // Re-apply active queue filter
            const activeFilter = document.querySelector('.q-filter-btn.active');
            if (activeFilter) applyQueueFilter(activeFilter.dataset.qfilter);
        }

        function updateQueueSelection(queueId, selected) {
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: `action=update_queue_selection&queue_id=${queueId}&selected=${selected}`
            }).catch(() => {});
        }

        function importSelectedRows() {
            if (!confirm('Import all selected valid assets into the system?')) return;
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: 'action=import_selected'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showAlert(`✅ Imported ${data.imported} asset(s). Failed: ${data.failed}`, data.failed > 0 ? 'warning' : 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showAlert(data.error || 'Import failed', 'danger');
                }
            })
            .catch(() => showAlert('Import failed. Please try again.', 'danger'));
        }

        function clearQueue() {
            if (!confirm('Clear all items from the import queue?')) return;
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: 'action=clear_queue'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('queuePanel').style.display = 'none';
                    showAlert('Import queue cleared', 'success');
                }
            }).catch(() => {});
        }

        // BUG FIX: downloadTemplate() string was broken across lines — fixed as a clean concatenated string
        function downloadTemplate() {
            const rows = [
                'asset_tag,name,category,serial_number,model,manufacturer,purchase_date,warranty_expiry,cost,notes',
                'IT-ASSET-001,Dell XPS 15,laptop,SN123456,XPS 15-9520,Dell,2024-01-15,2026-01-15,25000,Company laptop',
                'IT-ASSET-002,HP Monitor 27,monitor,SN789012,HP E27 G4,HP,2024-03-10,2027-03-10,8500,Office monitor',
                'IT-ASSET-003,Logitech MX Keys,peripheral,SN345678,MX Keys,Logitech,2024-02-20,2025-02-20,1200,Wireless keyboard'
            ];
            const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = 'assets_import_template.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        // Queue filter buttons
        function applyQueueFilter(filter) {
            document.querySelectorAll('#queueTableBody tr').forEach(row => {
                row.style.display = (filter === 'all' || row.dataset.qstatus === filter) ? '' : 'none';
            });
        }

        document.querySelectorAll('.q-filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.q-filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                applyQueueFilter(this.dataset.qfilter);
            });
        });

        // ========== ASSET CRUD ==========
        function updateAssetStatus(id, status) {
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: `action=update_status&id=${id}&status=${status}`
            })
            .then(r => r.json())
            .then(data => { if (!data.success) showAlert('Failed to update status', 'danger'); })
            .catch(() => showAlert('Failed to update status', 'danger'));
        }

        function assignAsset(id, userId) {
            if (!userId) return;
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: `action=assign&id=${id}&user_id=${userId}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) { location.reload(); }
                else showAlert('Failed to assign asset', 'danger');
            })
            .catch(() => showAlert('Failed to assign asset', 'danger'));
        }

        function unassignAsset(id) {
            if (!confirm('Unassign this asset?')) return;
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: `action=unassign&id=${id}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) { location.reload(); }
                else showAlert('Failed to unassign asset', 'danger');
            })
            .catch(() => showAlert('Failed to unassign asset', 'danger'));
        }

        function deleteAsset(id) {
            if (!confirm('Permanently delete this asset? This cannot be undone.')) return;
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: `action=delete&id=${id}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const row = document.querySelector(`#assetsTableBody tr[data-id="${id}"]`);
                    if (row) row.remove();
                    showAlert('Asset deleted', 'success');
                } else {
                    showAlert('Failed to delete asset', 'danger');
                }
            })
            .catch(() => showAlert('Failed to delete asset', 'danger'));
        }

        function addAsset() {
            const assetTag  = document.getElementById('assetTag').value.trim();
            const assetName = document.getElementById('assetName').value.trim();
            if (!assetTag || !assetName) {
                showAlert('Asset tag and name are required', 'danger');
                return;
            }
            const params = new URLSearchParams({
                action:          'add',
                asset_tag:       assetTag,
                name:            assetName,
                category:        document.getElementById('assetCategory').value,
                serial_number:   document.getElementById('serialNumber').value.trim(),
                model:           document.getElementById('assetModel').value.trim(),
                manufacturer:    document.getElementById('manufacturer').value.trim(),
                purchase_date:   document.getElementById('purchaseDate').value,
                warranty_expiry: document.getElementById('warrantyExpiry').value,
                cost:            document.getElementById('assetCost').value,
                notes:           document.getElementById('assetNotes').value.trim()
            });
            fetch('assets.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
                body: params.toString()
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    bootstrap.Modal.getInstance(document.getElementById('addAssetModal')).hide();
                    document.getElementById('addAssetForm').reset();
                    showAlert('Asset added successfully', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert(data.error || 'Failed to add asset', 'danger');
                }
            })
            .catch(() => showAlert('Failed to add asset', 'danger'));
        }

        // ========== VIEW ALL MODAL ==========
        // BUG FIX: use getOrCreateInstance to avoid duplicate modal instances / stacked backdrops
        function openViewAllModal(statusFilter) {
            if (statusFilter) {
                document.getElementById('viewAllStatusFilter').value = statusFilter;
            }
            bootstrap.Modal.getOrCreateInstance(document.getElementById('viewAllModal')).show();
            renderViewAll();
        }

        function renderViewAll() {
            const search   = document.getElementById('viewAllSearch').value.toLowerCase().trim();
            const status   = document.getElementById('viewAllStatusFilter').value;
            const category = document.getElementById('viewAllCategoryFilter').value;

            // BUG FIX: use PHP_ASSETS data bridge instead of trying to parse DOM or fetch a non-existent endpoint
            // This gives us ALL columns including purchase_date, warranty_expiry, cost, notes
            let filtered = PHP_ASSETS.filter(a => {
                if (status !== 'all' && a.status !== status) return false;
                if (category !== 'all' && a.category !== category) return false;
                if (search) {
                    const hay = (a.asset_tag + ' ' + a.name + ' ' + a.serial_number + ' ' + a.model + ' ' + a.manufacturer).toLowerCase();
                    if (!hay.includes(search)) return false;
                }
                return true;
            });

            const tbody = document.getElementById('viewAllTableBody');
            if (filtered.length === 0) {
                tbody.innerHTML = `<tr><td colspan="12" class="text-center py-5 text-muted"><i class="bi bi-inbox fs-1 d-block mb-2"></i>No assets found</td></tr>`;
                document.getElementById('viewAllFooter').innerHTML = `<i class="bi bi-info-circle"></i> No results match your filters.`;
                return;
            }

            tbody.innerHTML = filtered.map(a => {
                const statusClass = 'status-' + (a.status || 'available');
                const statusLabel = ucfirst(a.status || 'available');
                const assignedHtml = a.assigned_to
                    ? `<span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1 rounded-pill"><i class="bi bi-person-check me-1"></i>${escapeHtml(a.assigned_username)}</span>`
                    : '<span class="text-muted">—</span>';
                const costHtml = a.cost ? 'R ' + parseFloat(a.cost).toLocaleString('en-ZA', {minimumFractionDigits:2, maximumFractionDigits:2}) : '—';
                return `
                    <tr>
                        <td><span class="asset-code">${escapeHtml(a.asset_tag)}</span></td>
                        <td class="fw-semibold">${escapeHtml(a.name)}</td>
                        <td><span class="category-badge"><i class="bi bi-folder me-1"></i>${escapeHtml(ucfirst(a.category))}</span></td>
                        <td><small>${escapeHtml(a.serial_number || '—')}</small></td>
                        <td><small>${escapeHtml(a.model || '—')}</small></td>
                        <td><small>${escapeHtml(a.manufacturer || '—')}</small></td>
                        <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                        <td>${assignedHtml}</td>
                        <td><small>${escapeHtml(a.purchase_date || '—')}</small></td>
                        <td><small>${escapeHtml(a.warranty_expiry || '—')}</small></td>
                        <td>${costHtml}</td>
                        <td><small>${escapeHtml(a.notes || '—')}</small></td>
                    </tr>`;
            }).join('');

            document.getElementById('viewAllFooter').innerHTML =
                `<i class="bi bi-info-circle"></i> Showing <strong>${filtered.length}</strong> of <strong>${PHP_ASSETS.length}</strong> asset(s).`;
        }

        // Main table live search
        document.getElementById('searchInput').addEventListener('input', function() {
            const q = this.value.toLowerCase();
            document.querySelectorAll('#assetsTableBody tr[data-id]').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
            });
        });

        // View All filter/search listeners
        document.getElementById('viewAllSearch').addEventListener('input', renderViewAll);
        document.getElementById('viewAllStatusFilter').addEventListener('change', renderViewAll);
        document.getElementById('viewAllCategoryFilter').addEventListener('change', renderViewAll);

        // ========== ALERT UTILITY ==========
        function showAlert(message, type = 'success') {
            const el = document.createElement('div');
            el.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
            el.style.cssText = 'top:90px;right:20px;z-index:9999;min-width:300px;max-width:400px;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,0.15);';
            const icon = type === 'success' ? 'check-circle-fill' : type === 'warning' ? 'exclamation-triangle-fill' : 'x-circle-fill';
            el.innerHTML = `<i class="bi bi-${icon} me-2"></i>${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
            document.body.appendChild(el);
            setTimeout(() => { if (el.parentNode) el.remove(); }, 4500);
        }

        // ========== INIT ==========
        document.addEventListener('DOMContentLoaded', function () {
            loadNotifications();
            setInterval(loadNotifications, 60000);

            // Load notifications when bell dropdown opens
            const bell = document.querySelector('.notification-bell');
            if (bell) bell.addEventListener('shown.bs.dropdown', loadNotifications);

            // Wire up PHP-rendered queue checkboxes
            document.querySelectorAll('.queue-row-selector').forEach(cb => {
                cb.addEventListener('change', function () {
                    updateQueueSelection(this.dataset.id, this.checked ? 1 : 0);
                });
            });

            // Wire up select-all for PHP-rendered queue
            const sa = document.getElementById('queueSelectAll');
            if (sa) {
                sa.addEventListener('change', function () {
                    document.querySelectorAll('.queue-row-selector:not(:disabled)').forEach(cb => {
                        cb.checked = this.checked;
                        updateQueueSelection(cb.dataset.id, cb.checked ? 1 : 0);
                    });
                });
            }
        });
    </script>
</body>
</html>