<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];
$userType = $_SESSION['user_type'];
$isAdmin = ($userRole === 'admin' || $userType === 'admin');
$success = '';
$error = '';

// Get unread notifications count for the bell
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    $unreadCount = $stmt->fetchColumn();
} catch (PDOException $e) {
    $unreadCount = 0;
}

// Handle different actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $action = $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'add_device':
                    $device_number = trim($_POST['device_number'] ?? '');
                    $device_name = trim($_POST['device_name'] ?? '');
                    $brand = trim($_POST['brand'] ?? '');
                    $model = trim($_POST['model'] ?? '');
                    $serial_number = trim($_POST['serial_number'] ?? '');
                    $status = $_POST['status'] ?? 'available';
                    $purchase_date = $_POST['purchase_date'] ?? null;
                    $warranty_expiry = $_POST['warranty_expiry'] ?? null;
                    $notes = trim($_POST['notes'] ?? '');
                    
                    if (empty($device_number) || empty($device_name)) {
                        $error = 'Device number and name are required.';
                    } else {
                        // Check if device number exists
                        $stmt = $pdo->prepare("SELECT id FROM devices WHERE device_number = ?");
                        $stmt->execute([$device_number]);
                        if ($stmt->fetch()) {
                            $error = 'Device number already exists.';
                        } else {
                            $stmt = $pdo->prepare("
                                INSERT INTO devices (device_number, device_name, brand, model, serial_number, status, purchase_date, warranty_expiry, notes, created_at) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                            ");
                            if ($stmt->execute([$device_number, $device_name, $brand, $model, $serial_number, $status, $purchase_date, $warranty_expiry, $notes])) {
                                $success = 'Device added successfully.';
                            } else {
                                $error = 'Failed to add device.';
                            }
                        }
                    }
                    break;
                    
                case 'edit_device':
                    $device_id = (int)($_POST['device_id'] ?? 0);
                    $device_number = trim($_POST['device_number'] ?? '');
                    $device_name = trim($_POST['device_name'] ?? '');
                    $brand = trim($_POST['brand'] ?? '');
                    $model = trim($_POST['model'] ?? '');
                    $serial_number = trim($_POST['serial_number'] ?? '');
                    $status = $_POST['status'] ?? 'available';
                    $purchase_date = $_POST['purchase_date'] ?? null;
                    $warranty_expiry = $_POST['warranty_expiry'] ?? null;
                    $notes = trim($_POST['notes'] ?? '');
                    
                    if ($device_id > 0 && !empty($device_number) && !empty($device_name)) {
                        $stmt = $pdo->prepare("
                            UPDATE devices SET 
                                device_number = ?, device_name = ?, brand = ?, model = ?, 
                                serial_number = ?, status = ?, purchase_date = ?, 
                                warranty_expiry = ?, notes = ?
                            WHERE id = ?
                        ");
                        if ($stmt->execute([$device_number, $device_name, $brand, $model, $serial_number, $status, $purchase_date, $warranty_expiry, $notes, $device_id])) {
                            $success = 'Device updated successfully.';
                        } else {
                            $error = 'Failed to update device.';
                        }
                    } else {
                        $error = 'Invalid device data.';
                    }
                    break;
                    
                case 'delete_device':
                    $device_id = (int)($_POST['device_id'] ?? 0);
                    
                    if ($device_id > 0) {
                        // Check if device is assigned
                        $stmt = $pdo->prepare("SELECT assigned_to, device_number FROM devices WHERE id = ?");
                        $stmt->execute([$device_id]);
                        $device = $stmt->fetch();
                        
                        if ($device && $device['assigned_to']) {
                            $error = 'Cannot delete a device that is currently assigned. Please unassign it first.';
                        } else {
                            $stmt = $pdo->prepare("DELETE FROM devices WHERE id = ?");
                            if ($stmt->execute([$device_id])) {
                                $success = 'Device deleted successfully.';
                            } else {
                                $error = 'Failed to delete device.';
                            }
                        }
                    }
                    break;
                    
                case 'assign_device':
                    $device_id = (int)($_POST['device_id'] ?? 0);
                    $assigned_to = (int)($_POST['assigned_to'] ?? 0);
                    
                    if ($device_id > 0 && $assigned_to > 0) {
                        // Get device details
                        $stmt = $pdo->prepare("SELECT device_number FROM devices WHERE id = ?");
                        $stmt->execute([$device_id]);
                        $device = $stmt->fetch();
                        
                        // Update device
                        $stmt = $pdo->prepare("UPDATE devices SET assigned_to = ?, status = 'in_use' WHERE id = ?");
                        if ($stmt->execute([$assigned_to, $device_id])) {
                            // Create notification for user
                            $stmt = $pdo->prepare("
                                INSERT INTO notifications (user_id, title, message, type, created_at) 
                                VALUES (?, ?, ?, 'device', NOW())
                            ");
                            $stmt->execute([$assigned_to, 'Device Assigned', "Device {$device['device_number']} has been assigned to you."]);
                            
                            $success = 'Device assigned successfully.';
                        } else {
                            $error = 'Failed to assign device.';
                        }
                    } else {
                        $error = 'Invalid assignment data.';
                    }
                    break;
                    
                case 'unassign_device':
                    $device_id = (int)($_POST['device_id'] ?? 0);
                    
                    if ($device_id > 0) {
                        // Get device details
                        $stmt = $pdo->prepare("SELECT device_number, assigned_to FROM devices WHERE id = ?");
                        $stmt->execute([$device_id]);
                        $device = $stmt->fetch();
                        
                        if ($device && $device['assigned_to']) {
                            $previous_user = $device['assigned_to'];
                            
                            // Update device
                            $stmt = $pdo->prepare("UPDATE devices SET assigned_to = NULL, status = 'available' WHERE id = ?");
                            if ($stmt->execute([$device_id])) {
                                // Create notification for user
                                $stmt = $pdo->prepare("
                                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                                    VALUES (?, ?, ?, 'device', NOW())
                                ");
                                $stmt->execute([$previous_user, 'Device Unassigned', "Device {$device['device_number']} has been unassigned from you."]);
                                
                                $success = 'Device unassigned successfully.';
                            } else {
                                $error = 'Failed to unassign device.';
                            }
                        } else {
                            $error = 'Device is not currently assigned.';
                        }
                    }
                    break;
                    
                case 'update_status':
                    $device_id = (int)($_POST['device_id'] ?? 0);
                    $status = $_POST['status'] ?? 'available';
                    
                    if ($device_id > 0) {
                        $stmt = $pdo->prepare("UPDATE devices SET status = ? WHERE id = ?");
                        if ($stmt->execute([$status, $device_id])) {
                            $success = 'Device status updated successfully.';
                        } else {
                            $error = 'Failed to update status.';
                        }
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch all devices
$devices = [];
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$assigned_filter = $_GET['assigned'] ?? '';

try {
    $sql = "SELECT d.*, u.username as assigned_username, u.email as assigned_email 
            FROM devices d 
            LEFT JOIN users u ON d.assigned_to = u.id 
            WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (d.device_number LIKE ? OR d.device_name LIKE ? OR d.serial_number LIKE ? OR d.model LIKE ?)";
        $search_param = "%$search%";
        $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
    }
    
    if (!empty($status_filter)) {
        $sql .= " AND d.status = ?";
        $params[] = $status_filter;
    }
    
    if ($assigned_filter === 'assigned') {
        $sql .= " AND d.assigned_to IS NOT NULL";
    } elseif ($assigned_filter === 'unassigned') {
        $sql .= " AND d.assigned_to IS NULL";
    } elseif ($assigned_filter === 'my' && !$isAdmin) {
        $sql .= " AND d.assigned_to = ?";
        $params[] = $userId;
    }
    
    $sql .= " ORDER BY d.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $devices = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to fetch devices: ' . $e->getMessage();
}

// Fetch users for assignment dropdown
$users = [];
if ($isAdmin) {
    try {
        $stmt = $pdo->query("SELECT id, username, email FROM users WHERE status = 'active' ORDER BY username");
        $users = $stmt->fetchAll();
    } catch (PDOException $e) {
        // Handle error
    }
}

// Get device statistics
$stats = [];
try {
    $result = $pdo->query("SELECT COUNT(*) FROM devices");
    $stats['total'] = $result ? $result->fetchColumn() : 0;
    
    $result = $pdo->query("SELECT COUNT(*) FROM devices WHERE status = 'available'");
    $stats['available'] = $result ? $result->fetchColumn() : 0;
    
    $result = $pdo->query("SELECT COUNT(*) FROM devices WHERE status = 'in_use'");
    $stats['in_use'] = $result ? $result->fetchColumn() : 0;
    
    $result = $pdo->query("SELECT COUNT(*) FROM devices WHERE status = 'maintenance'");
    $stats['maintenance'] = $result ? $result->fetchColumn() : 0;
    
    $result = $pdo->query("SELECT COUNT(*) FROM devices WHERE warranty_expiry < CURDATE() AND warranty_expiry IS NOT NULL");
    $stats['expired_warranty'] = $result ? $result->fetchColumn() : 0;
} catch (PDOException $e) {
    // Handle error
}

// Generate CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Device Management | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }

        .navbar {
            background: var(--primary-gradient);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }

        .navbar-brand i {
            font-size: 1.6rem;
        }

        .navbar-brand:hover {
            color: white;
        }

        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            margin: 0 2px;
        }

        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }

        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
            font-weight: 600;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }

        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }

        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: var(--radius-md);
            border: none;
            box-shadow: var(--shadow-lg);
            padding: 0;
        }

        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background: white;
            z-index: 1;
        }

        .notifications-header h6 {
            margin: 0;
            font-weight: 600;
        }

        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid var(--border);
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .notification-item:hover {
            background: #fefce8;
        }

        .notification-item.unread {
            background: #fffbeb;
        }

        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            background: #fed7aa;
            color: var(--warning);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }

        .notification-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 4px;
        }

        .notification-message {
            font-size: 0.75rem;
            color: var(--gray);
            margin-bottom: 4px;
        }

        .notification-time {
            font-size: 0.65rem;
            color: #94a3b8;
        }

        .main-content {
            margin-top: 80px;
            padding: 24px 28px;
        }

        .stat-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--dark);
            line-height: 1.2;
        }

        .stat-label {
            font-size: 0.75rem;
            color: var(--gray);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .device-card {
            background: white;
            border-radius: var(--radius-lg);
            border: none;
            box-shadow: var(--shadow-md);
            transition: all 0.3s ease;
            height: 100%;
            overflow: hidden;
        }

        .device-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .device-card .card-header {
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 1rem 1.25rem;
            font-weight: 700;
            border-radius: var(--radius-lg) var(--radius-lg) 0 0;
        }

        .device-card .card-body {
            padding: 1.25rem;
        }

        .device-card .card-footer {
            background: transparent;
            border-top: 1px solid var(--border);
            padding: 1rem 1.25rem;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .status-available { background: #d4f8e8; color: #065f46; }
        .status-in_use { background: #dbeafe; color: #1e40af; }
        .status-maintenance { background: #fed7aa; color: #9b2c1d; }
        .status-retired { background: #fee2e2; color: #991b1b; }

        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }

        .btn-outline-primary {
            border: 2px solid var(--primary);
            background: transparent;
            color: var(--primary);
            font-weight: 600;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
        }

        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }

        .filter-bar {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
        }

        .modal-content {
            border-radius: var(--radius-lg);
            border: none;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }

        .form-control, .form-select {
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            padding: 0.6rem 1rem;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }

        .alert-custom {
            border-radius: var(--radius-md);
            border: none;
            padding: 0.75rem 1rem;
        }

        .device-info-item {
            margin-bottom: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid #f1f5f9;
        }

        .device-info-label {
            font-size: 0.7rem;
            color: var(--gray);
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .device-info-value {
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--dark);
        }

        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            opacity: 0.5;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .main-content {
            animation: fadeIn 0.4s ease-out;
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
                margin-top: 70px;
            }
            .stat-value {
                font-size: 1.3rem;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
        }

        @media (max-width: 576px) {
            .stat-card {
                text-align: center;
            }
            .stat-icon {
                margin: 0 auto 10px;
            }
            .notifications-dropdown {
                width: 300px;
                right: -80px !important;
            }
        }

        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="devices.php">
                            <i class="bi bi-laptop me-1"></i> Devices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="assets.php">
                            <i class="bi bi-box-seam me-1"></i> Assets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tickets.php">
                            <i class="bi bi-ticket-detailed me-1"></i> Tickets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="technicians.php">
                            <i class="bi bi-people me-1"></i> Technicians
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="mb-1">Device Management</h2>
                <p class="text-muted mb-0">Manage and track all IT devices in your organization</p>
            </div>
            <?php if ($isAdmin): ?>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDeviceModal">
                <i class="bi bi-plus-circle me-2"></i> Add New Device
            </button>
            <?php endif; ?>
        </div>

        <!-- Stats Row -->
        <div class="row g-3 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='devices.php'">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['total'] ?? 0 ?></div>
                            <div class="stat-label">Total Devices</div>
                        </div>
                        <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                            <i class="bi bi-laptop"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='devices.php?status=available'">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['available'] ?? 0 ?></div>
                            <div class="stat-label">Available</div>
                        </div>
                        <div class="stat-icon bg-success bg-opacity-10 text-success">
                            <i class="bi bi-check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='devices.php?status=in_use'">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['in_use'] ?? 0 ?></div>
                            <div class="stat-label">In Use</div>
                        </div>
                        <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                            <i class="bi bi-person-check"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='devices.php?status=maintenance'">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $stats['maintenance'] ?? 0 ?></div>
                            <div class="stat-label">Maintenance</div>
                        </div>
                        <div class="stat-icon bg-danger bg-opacity-10 text-danger">
                            <i class="bi bi-tools"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-custom alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Search and Filter Bar -->
        <div class="filter-bar">
            <form method="GET" action="" class="row g-3">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" name="search" placeholder="Search by device name, number, serial..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="status" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="available" <?= $status_filter == 'available' ? 'selected' : '' ?>>Available</option>
                        <option value="in_use" <?= $status_filter == 'in_use' ? 'selected' : '' ?>>In Use</option>
                        <option value="maintenance" <?= $status_filter == 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
                        <option value="retired" <?= $status_filter == 'retired' ? 'selected' : '' ?>>Retired</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="assigned" onchange="this.form.submit()">
                        <option value="">All Devices</option>
                        <option value="assigned" <?= $assigned_filter == 'assigned' ? 'selected' : '' ?>>Assigned Devices</option>
                        <option value="unassigned" <?= $assigned_filter == 'unassigned' ? 'selected' : '' ?>>Unassigned Devices</option>
                        <?php if (!$isAdmin): ?>
                        <option value="my" <?= $assigned_filter == 'my' ? 'selected' : '' ?>>My Devices</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-1">
                    <?php if (!empty($search) || !empty($status_filter) || !empty($assigned_filter)): ?>
                        <a href="devices.php" class="btn btn-outline-secondary w-100">Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Devices Grid -->
        <?php if (empty($devices)): ?>
            <div class="empty-state py-5">
                <i class="bi bi-laptop display-1 text-muted"></i>
                <h4 class="mt-3 text-muted">No devices found</h4>
                <p class="text-muted">Try adjusting your search or filter criteria.</p>
                <?php if ($isAdmin): ?>
                <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#addDeviceModal">
                    <i class="bi bi-plus-circle me-2"></i> Add Your First Device
                </button>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($devices as $device): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="device-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="bi bi-laptop me-2" style="color: var(--primary);"></i>
                                    <strong><?= htmlspecialchars($device['device_name']) ?></strong>
                                </div>
                                <span class="status-badge status-<?= $device['status'] ?>">
                                    <?= ucfirst(str_replace('_', ' ', $device['status'])) ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <div class="device-info-item">
                                    <div class="device-info-label">Device Number</div>
                                    <div class="device-info-value">
                                        <code><?= htmlspecialchars($device['device_number']) ?></code>
                                    </div>
                                </div>
                                
                                <?php if ($device['brand'] || $device['model']): ?>
                                <div class="device-info-item">
                                    <div class="device-info-label">Model</div>
                                    <div class="device-info-value">
                                        <?= htmlspecialchars($device['brand']) ?> <?= htmlspecialchars($device['model']) ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($device['serial_number']): ?>
                                <div class="device-info-item">
                                    <div class="device-info-label">Serial Number</div>
                                    <div class="device-info-value">
                                        <code><?= htmlspecialchars($device['serial_number']) ?></code>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($device['assigned_username']): ?>
                                <div class="device-info-item">
                                    <div class="device-info-label">Assigned To</div>
                                    <div class="device-info-value">
                                        <i class="bi bi-person-circle me-1"></i>
                                        <?= htmlspecialchars($device['assigned_username']) ?>
                                        <br><small class="text-muted"><?= htmlspecialchars($device['assigned_email']) ?></small>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="device-info-item">
                                    <div class="device-info-label">Status</div>
                                    <div class="device-info-value text-muted">
                                        <i class="bi bi-box"></i> Not Assigned
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($device['notes']): ?>
                                <div class="device-info-item">
                                    <div class="device-info-label">Notes</div>
                                    <div class="device-info-value small text-muted">
                                        <?= htmlspecialchars(substr($device['notes'], 0, 100)) ?>
                                        <?= strlen($device['notes']) > 100 ? '...' : '' ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer">
                                <div class="btn-group w-100" role="group">
                                    <button class="btn btn-sm btn-outline-primary" onclick="viewDevice(<?= htmlspecialchars(json_encode($device)) ?>)">
                                        <i class="bi bi-eye"></i> View
                                    </button>
                                    
                                    <?php if ($isAdmin): ?>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="editDevice(<?= htmlspecialchars(json_encode($device)) ?>)">
                                            <i class="bi bi-pencil"></i> Edit
                                        </button>
                                        
                                        <?php if ($device['assigned_to']): ?>
                                            <button class="btn btn-sm btn-outline-warning" onclick="unassignDevice(<?= $device['id'] ?>, '<?= htmlspecialchars($device['device_number']) ?>')">
                                                <i class="bi bi-person-x"></i> Unassign
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-outline-success" onclick="assignDevice(<?= $device['id'] ?>, '<?= htmlspecialchars($device['device_number']) ?>')">
                                                <i class="bi bi-person-plus"></i> Assign
                                            </button>
                                        <?php endif; ?>
                                        
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteDevice(<?= $device['id'] ?>, '<?= htmlspecialchars($device['device_number']) ?>')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    <?php elseif ($device['assigned_to'] == $userId): ?>
                                        <button class="btn btn-sm btn-outline-warning" onclick="checkinDevice(<?= $device['id'] ?>, '<?= htmlspecialchars($device['device_number']) ?>')">
                                            <i class="bi bi-box-arrow-in-right"></i> Check In
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Add Device Modal -->
    <div class="modal fade" id="addDeviceModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="add_device">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add New Device</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Device Number *</label>
                                <input type="text" class="form-control" name="device_number" required placeholder="e.g., DEV-001">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Device Name *</label>
                                <input type="text" class="form-control" name="device_name" required placeholder="e.g., Dell XPS 15">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Brand</label>
                                <input type="text" class="form-control" name="brand" placeholder="e.g., Dell, HP, Apple">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Model</label>
                                <input type="text" class="form-control" name="model" placeholder="e.g., XPS 15-9520">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" class="form-control" name="serial_number" placeholder="Enter serial number">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="available">Available</option>
                                    <option value="in_use">In Use</option>
                                    <option value="maintenance">Maintenance</option>
                                    <option value="retired">Retired</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" class="form-control" name="purchase_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Warranty Expiry</label>
                                <input type="date" class="form-control" name="warranty_expiry">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="Additional notes about this device..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Device</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Device Modal -->
    <div class="modal fade" id="editDeviceModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="edit_device">
                    <input type="hidden" name="device_id" id="edit_device_id">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Device</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Device Number *</label>
                                <input type="text" class="form-control" name="device_number" id="edit_device_number" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Device Name *</label>
                                <input type="text" class="form-control" name="device_name" id="edit_device_name" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Brand</label>
                                <input type="text" class="form-control" name="brand" id="edit_brand">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Model</label>
                                <input type="text" class="form-control" name="model" id="edit_model">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" class="form-control" name="serial_number" id="edit_serial_number">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status" id="edit_status">
                                    <option value="available">Available</option>
                                    <option value="in_use">In Use</option>
                                    <option value="maintenance">Maintenance</option>
                                    <option value="retired">Retired</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" class="form-control" name="purchase_date" id="edit_purchase_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Warranty Expiry</label>
                                <input type="date" class="form-control" name="warranty_expiry" id="edit_warranty_expiry">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" id="edit_notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Device Modal -->
    <div class="modal fade" id="viewDeviceModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-laptop me-2"></i>Device Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewDeviceContent">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Assign Device Modal -->
    <div class="modal fade" id="assignDeviceModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="action" value="assign_device">
                    <input type="hidden" name="device_id" id="assign_device_id">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Assign Device</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Assign device: <strong id="assign_device_name"></strong></p>
                        <div class="mb-3">
                            <label class="form-label">Select User</label>
                            <select class="form-select" name="assigned_to" required>
                                <option value="">Choose a user...</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['email']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Assign Device</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Device Form -->
    <form id="deleteDeviceForm" method="POST" style="display: none;">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <input type="hidden" name="action" value="delete_device">
        <input type="hidden" name="device_id" id="delete_device_id">
    </form>

    <!-- Unassign Device Form -->
    <form id="unassignDeviceForm" method="POST" style="display: none;">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <input type="hidden" name="action" value="unassign_device">
        <input type="hidden" name="device_id" id="unassign_device_id">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Notification System
        let notificationPollingInterval = null;
        let lastNotificationCheck = Date.now();
        
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon">
                                <i class="bi bi-bell"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title">${escapeHtml(notif.title)}</div>
                                <div class="notification-message">${escapeHtml(notif.message)}</div>
                                <div class="notification-time">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function startNotificationPolling() {
            if (notificationPollingInterval) clearInterval(notificationPollingInterval);
            notificationPollingInterval = setInterval(() => {
                fetch('api/notifications.php?action=get_count')
                    .then(r => r.json())
                    .then(data => {
                        if (data.success && data.unread_count > 0) {
                            const bellBadge = document.querySelector('.notification-badge');
                            if (bellBadge) {
                                bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                                bellBadge.style.display = 'flex';
                            }
                        }
                    })
                    .catch(err => console.error('Error checking notifications:', err));
            }, 30000);
        }
        
        function viewDevice(device) {
            let html = `
                <div class="device-info-item">
                    <div class="device-info-label">Device Number</div>
                    <div class="device-info-value"><code>${escapeHtml(device.device_number)}</code></div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Device Name</div>
                    <div class="device-info-value">${escapeHtml(device.device_name)}</div>
                </div>`;
            
            if (device.brand || device.model) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Model</div>
                    <div class="device-info-value">${escapeHtml(device.brand)} ${escapeHtml(device.model)}</div>
                </div>`;
            }
            
            if (device.serial_number) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Serial Number</div>
                    <div class="device-info-value"><code>${escapeHtml(device.serial_number)}</code></div>
                </div>`;
            }
            
            html += `
                <div class="device-info-item">
                    <div class="device-info-label">Status</div>
                    <div class="device-info-value">
                        <span class="status-badge status-${device.status}">${device.status.replace('_', ' ').toUpperCase()}</span>
                    </div>
                </div>`;
            
            if (device.assigned_username) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Assigned To</div>
                    <div class="device-info-value">
                        <i class="bi bi-person-circle me-1"></i>
                        ${escapeHtml(device.assigned_username)}
                        <br><small class="text-muted">${escapeHtml(device.assigned_email)}</small>
                    </div>
                </div>`;
            } else {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Assignment</div>
                    <div class="device-info-value text-muted">Not Assigned</div>
                </div>`;
            }
            
            if (device.purchase_date) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Purchase Date</div>
                    <div class="device-info-value">${formatDate(device.purchase_date)}</div>
                </div>`;
            }
            
            if (device.warranty_expiry) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Warranty Expiry</div>
                    <div class="device-info-value">${formatDate(device.warranty_expiry)}</div>
                </div>`;
            }
            
            if (device.notes) {
                html += `
                <div class="device-info-item">
                    <div class="device-info-label">Notes</div>
                    <div class="device-info-value">${escapeHtml(device.notes)}</div>
                </div>`;
            }
            
            document.getElementById('viewDeviceContent').innerHTML = html;
            new bootstrap.Modal(document.getElementById('viewDeviceModal')).show();
        }
        
        function editDevice(device) {
            document.getElementById('edit_device_id').value = device.id;
            document.getElementById('edit_device_number').value = device.device_number;
            document.getElementById('edit_device_name').value = device.device_name;
            document.getElementById('edit_brand').value = device.brand || '';
            document.getElementById('edit_model').value = device.model || '';
            document.getElementById('edit_serial_number').value = device.serial_number || '';
            document.getElementById('edit_status').value = device.status;
            document.getElementById('edit_purchase_date').value = device.purchase_date || '';
            document.getElementById('edit_warranty_expiry').value = device.warranty_expiry || '';
            document.getElementById('edit_notes').value = device.notes || '';
            new bootstrap.Modal(document.getElementById('editDeviceModal')).show();
        }
        
        function assignDevice(deviceId, deviceName) {
            document.getElementById('assign_device_id').value = deviceId;
            document.getElementById('assign_device_name').textContent = deviceName;
            new bootstrap.Modal(document.getElementById('assignDeviceModal')).show();
        }
        
        function unassignDevice(deviceId, deviceName) {
            if (confirm(`Are you sure you want to unassign device "${deviceName}"?`)) {
                document.getElementById('unassign_device_id').value = deviceId;
                document.getElementById('unassignDeviceForm').submit();
            }
        }
        
        function deleteDevice(deviceId, deviceName) {
            if (confirm(`Are you sure you want to delete device "${deviceName}"? This action cannot be undone.`)) {
                document.getElementById('delete_device_id').value = deviceId;
                document.getElementById('deleteDeviceForm').submit();
            }
        }
        
        function checkinDevice(deviceId, deviceName) {
            if (confirm(`Are you sure you want to check in "${deviceName}"?`)) {
                window.location.href = `devices.php?action=checkin&id=${deviceId}&csrf_token=<?= $_SESSION['csrf_token'] ?>`;
            }
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function formatDate(dateString) {
            if (!dateString) return '';
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            startNotificationPolling();
        });
    </script>
</body>
</html>