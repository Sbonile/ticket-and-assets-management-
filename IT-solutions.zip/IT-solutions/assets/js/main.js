// Main JavaScript for IT Solutions

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize password toggle
    initializePasswordToggle();
    
    // Initialize form validation
    initializeFormValidation();
    
    // Initialize notifications
    initializeNotifications();
    
    // Initialize search functionality
    initializeSearch();
    
    // Initialize data tables
    initializeDataTables();
});

// Initialize Bootstrap tooltips
function initializeTooltips() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Password visibility toggle
function initializePasswordToggle() {
    const toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        });
    });
}

// Form validation
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
}

// Notifications System
let notificationPollingInterval = null;
let lastNotificationCheck = Date.now();

function initializeNotifications() {
    loadNotifications();
    startNotificationPolling();
    requestNotificationPermission();
}

function loadNotifications() {
    fetch('api/notifications.php?action=get_all')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateNotificationsUI(data.notifications, data.unread_count);
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
}

function updateNotificationsUI(notifications, unreadCount) {
    const notificationsList = document.getElementById('notificationsList');
    const bellBadge = document.querySelector('.notification-badge');
    
    // Update badge count
    if (unreadCount > 0 && bellBadge) {
        bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
        bellBadge.style.display = 'flex';
    } else if (bellBadge) {
        bellBadge.style.display = 'none';
    }
    
    if (!notifications || notifications.length === 0) {
        if (notificationsList) {
            notificationsList.innerHTML = `
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-bell-slash fs-4"></i>
                    <p class="mb-0 small">No notifications</p>
                </div>
            `;
        }
        return;
    }
    
    let html = '';
    notifications.slice(0, 10).forEach(notification => {
        const isUnread = !notification.is_read;
        html += `
            <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notification.id}">
                <div class="d-flex gap-3">
                    <div class="notification-icon">
                        <i class="bi bi-${getNotificationIcon(notification.type)}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="notification-title">${escapeHtml(notification.title)}</div>
                        <div class="notification-message">${escapeHtml(notification.message)}</div>
                        <div class="notification-time">${timeAgo(notification.created_at)}</div>
                    </div>
                    ${isUnread ? `
                        <button class="btn btn-sm btn-link mark-read" onclick="markAsRead(${notification.id}, event)">
                            <i class="bi bi-check-circle"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    });
    
    if (notificationsList) {
        notificationsList.innerHTML = html;
    }
}

function getNotificationIcon(type) {
    const icons = {
        'ticket': 'ticket-detailed',
        'asset': 'box-seam',
        'chat': 'chat-dots',
        'system': 'info-circle'
    };
    return icons[type] || 'bell';
}

function markAsRead(notificationId, event) {
    if (event) event.stopPropagation();
    
    fetch('api/notifications.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=mark_read&notification_id=${notificationId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const item = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
            if (item) {
                item.classList.remove('unread');
                const markBtn = item.querySelector('.mark-read');
                if (markBtn) markBtn.remove();
            }
            updateNotificationCount();
        }
    })
    .catch(error => console.error('Error marking as read:', error));
}

function markAllAsRead() {
    fetch('api/notifications.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=mark_all_read'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotifications();
        }
    })
    .catch(error => console.error('Error marking all as read:', error));
}

function updateNotificationCount() {
    fetch('api/notifications.php?action=get_count')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const bellBadge = document.querySelector('.notification-badge');
                if (data.unread_count > 0 && bellBadge) {
                    bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                    bellBadge.style.display = 'flex';
                } else if (bellBadge) {
                    bellBadge.style.display = 'none';
                }
            }
        })
        .catch(error => console.error('Error updating count:', error));
}

function startNotificationPolling() {
    if (notificationPollingInterval) clearInterval(notificationPollingInterval);
    notificationPollingInterval = setInterval(checkNewNotifications, 30000);
}

function checkNewNotifications() {
    fetch(`api/notifications.php?action=get_new&last_check=${lastNotificationCheck}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.has_new) {
                loadNotifications();
                if (data.notifications && data.notifications.length > 0 && Notification.permission === 'granted') {
                    data.notifications.forEach(notification => {
                        new Notification(notification.title, {
                            body: notification.message,
                            icon: '/favicon.ico'
                        });
                    });
                }
            }
            lastNotificationCheck = Date.now();
        })
        .catch(error => console.error('Error checking notifications:', error));
}

function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const table = document.querySelector('.data-table');
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                });
            }
        });
    }
}

// Data tables initialization
function initializeDataTables() {
    const tables = document.querySelectorAll('.data-table');
    tables.forEach(table => {
        const headers = table.querySelectorAll('thead th');
        headers.forEach((header, index) => {
            if (header.classList.contains('sortable')) {
                header.style.cursor = 'pointer';
                header.addEventListener('click', () => sortTable(table, index));
            }
        });
    });
}

function sortTable(table, column) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const isAscending = table.dataset.sortColumn === column.toString() && table.dataset.sortDirection === 'asc';
    
    rows.sort((a, b) => {
        const aValue = a.cells[column].textContent.trim();
        const bValue = b.cells[column].textContent.trim();
        return isAscending ? bValue.localeCompare(aValue) : aValue.localeCompare(bValue);
    });
    
    rows.forEach(row => tbody.appendChild(row));
    table.dataset.sortColumn = column;
    table.dataset.sortDirection = isAscending ? 'desc' : 'asc';
}

// Helper Functions
function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showAlert(message, type = 'success') {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) return;
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => alert.remove(), 300);
    }, 5000);
}

function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// AJAX Helper
function ajaxRequest(url, method, data, callback) {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                callback(response);
            } catch (e) {
                callback({ success: false, error: 'Invalid response' });
            }
        } else {
            callback({ success: false, error: 'Request failed' });
        }
    };
    
    xhr.onerror = function() {
        callback({ success: false, error: 'Network error' });
    };
    
    xhr.send(data);
}