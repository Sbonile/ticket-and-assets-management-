<?php
// assets/css/theme.css.php - Dynamic Theme CSS
header('Content-Type: text/css');

// Define path to config
$configPath = dirname(__DIR__, 2) . '/config/session.php';
if (file_exists($configPath)) {
    require_once $configPath;
} else {
    // Fallback colors if config not found
    $primary = '#f39c12';
    $primaryDark = '#e67e22';
    $primaryLight = '#fef3c7';
    $secondary = '#1e293b';
    $success = '#10b981';
    $danger = '#ef4444';
    $warning = '#f59e0b';
    $info = '#3b82f6';
}

// Get colors from company config or use defaults
$primary = company('colors.primary', '#f39c12');
$primaryDark = company('colors.primary_dark', '#e67e22');
$primaryLight = company('colors.primary_light', '#fef3c7');
$secondary = company('colors.secondary', '#1e293b');
$success = company('colors.success', '#10b981');
$danger = company('colors.danger', '#ef4444');
$warning = company('colors.warning', '#f59e0b');
$info = company('colors.info', '#3b82f6');
?>

:root {
    --primary: <?= $primary ?>;
    --primary-dark: <?= $primaryDark ?>;
    --primary-light: <?= $primaryLight ?>;
    --primary-gradient: linear-gradient(135deg, <?= $primary ?> 0%, <?= $primaryDark ?> 100%);
    --secondary: <?= $secondary ?>;
    --success: <?= $success ?>;
    --danger: <?= $danger ?>;
    --warning: <?= $warning ?>;
    --info: <?= $info ?>;
}

/* Custom styles that use company colors */
.btn-primary {
    background: var(--primary-gradient) !important;
    border: none !important;
}

.btn-primary:hover {
    background: var(--primary-gradient) !important;
    filter: brightness(1.05);
    transform: translateY(-1px);
}

.btn-outline-primary {
    border: 2px solid var(--primary) !important;
    color: var(--primary) !important;
}

.btn-outline-primary:hover {
    background: var(--primary-gradient) !important;
    border-color: transparent !important;
    color: white !important;
}

.navbar, .header {
    background: var(--primary-gradient) !important;
}

.navbar .nav-link:hover,
.navbar .nav-link.active {
    background: rgba(255,255,255,0.15) !important;
}

.status-badge, .badge-primary {
    background: var(--primary-light);
    color: var(--primary-dark);
}

a, .text-primary {
    color: var(--primary) !important;
}

a:hover {
    color: var(--primary-dark) !important;
}

.bg-primary {
    background: var(--primary-gradient) !important;
}

.border-primary {
    border-color: var(--primary) !important;
}

/* Progress bars */
.progress-bar {
    background: var(--primary-gradient) !important;
}

/* Focus rings */
.form-control:focus, .form-select:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(<?= hexdec(substr($primary, 1, 2)) ?>, <?= hexdec(substr($primary, 3, 2)) ?>, <?= hexdec(substr($primary, 5, 2)) ?>, 0.1);
}

/* Pagination */
.page-item.active .page-link {
    background: var(--primary-gradient);
    border-color: var(--primary);
}

/* Alert */
.alert-primary {
    background: var(--primary-light);
    border-color: var(--primary);
    color: var(--primary-dark);
}