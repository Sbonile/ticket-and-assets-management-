<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

$error = '';
$success = '';

// Function to get system setting
function getSetting($pdo, $key, $default = null) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

// Check if registration is enabled
$registration_enabled = getSetting($pdo, 'registration_enabled', 'true') !== 'false';
$require_strong_password = getSetting($pdo, 'require_strong_password', 'true') === 'true';
$site_name = getSetting($pdo, 'site_name', 'IT Solutions');

// If registration is disabled, redirect to login
if (!$registration_enabled) {
    header("Location: index.php?msg=registration_disabled");
    exit();
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin' || $_SESSION['user_type'] === 'admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: staff_dashboard.php");
    }
    exit();
}

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $phone = trim($_POST['phone'] ?? '');
        $department_code = trim($_POST['department_code'] ?? '');
        $department_name = trim($_POST['department_name'] ?? '');
        
        // Validation
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters long.';
        } elseif ($require_strong_password && !preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/', $password)) {
            $error = 'Password must contain at least one uppercase letter, one lowercase letter, and one number.';
        } elseif ($require_strong_password && !preg_match('/[$@#&!]/', $password)) {
            $error = 'Password must contain at least one special character ($@#&!).';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } else {
            try {
                // Check if email already exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = 'Email address is already registered.';
                } else {
                    // Check if username already exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        $error = 'Username is already taken.';
                    } else {
                        // Hash password and create user
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        
                        $stmt = $pdo->prepare("
                            INSERT INTO users (username, email, password, phone, department_code, department_name, role, user_type, status, password_changed_at) 
                            VALUES (?, ?, ?, ?, ?, ?, 'staff', 'staff', 'active', NOW())
                        ");
                        
                        if ($stmt->execute([$username, $email, $hashed_password, $phone, $department_code, $department_name])) {
                            $user_id = $pdo->lastInsertId();
                            
                            // Send welcome email (if email configured)
                            // mail($email, "Welcome to $site_name", "Your account has been created successfully.");
                            
                            $success = 'Registration successful! You can now login.';
                            
                            // Clear form
                            $_POST = array();
                            
                            // Redirect after 2 seconds
                            echo '<meta http-equiv="refresh" content="2;url=index.php">';
                        } else {
                            $error = 'Registration failed. Please try again.';
                        }
                    }
                }
            } catch (PDOException $e) {
                $error = 'Database error. Please try again later.';
                error_log($e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration | <?= htmlspecialchars($site_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--primary-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .register-container {
            width: 100%;
            max-width: 550px;
            animation: fadeInUp 0.5s ease-out;
        }

        .register-card {
            background: white;
            border-radius: 24px;
            padding: 2rem;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            position: relative;
            overflow: hidden;
        }

        .register-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--primary-gradient);
        }

        .register-header {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .logo {
            font-size: 2rem;
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 0.5rem;
        }

        .logo i {
            font-size: 2rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .tagline {
            color: #64748b;
            font-size: 0.85rem;
        }

        .info-banner {
            background: linear-gradient(135deg, #d4f8e8, #e8faf5);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            margin-bottom: 1.5rem;
            font-size: 0.8rem;
            color: #065f46;
            text-align: center;
            border-left: 4px solid #10b981;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.8rem;
            color: #1e293b;
            margin-bottom: 0.4rem;
        }

        .required-field::after {
            content: '*';
            color: #ef4444;
            margin-left: 4px;
        }

        .input-group {
            border-radius: 12px;
            overflow: hidden;
        }

        .input-group-text {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            color: #64748b;
        }

        .form-control {
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(243,156,18,0.1);
        }

        .form-control.is-invalid {
            border-color: #ef4444;
        }

        .form-control.is-valid {
            border-color: #10b981;
        }

        .toggle-password {
            border: 1px solid #e2e8f0;
            border-left: none;
        }

        .btn-register {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-register:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(243,156,18,0.3);
        }

        .btn-register:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .btn-login {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-login:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }

        .register-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1rem;
            border-top: 1px solid #e2e8f0;
        }

        .alert-custom {
            border-radius: 12px;
            border: none;
            padding: 0.75rem 1rem;
            font-size: 0.85rem;
            margin-bottom: 1.5rem;
        }

        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.7rem;
        }

        .strength-meter {
            height: 4px;
            background: #e2e8f0;
            border-radius: 2px;
            margin-top: 0.5rem;
            overflow: hidden;
        }

        .strength-meter-fill {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }

        .strength-weak { background: #ef4444; width: 25%; }
        .strength-fair { background: #f59e0b; width: 50%; }
        .strength-good { background: #3b82f6; width: 75%; }
        .strength-strong { background: #10b981; width: 100%; }

        .password-requirements {
            font-size: 0.7rem;
            margin-top: 0.5rem;
            padding-left: 0;
            list-style: none;
        }

        .password-requirements li {
            margin-bottom: 0.25rem;
            color: #64748b;
        }

        .password-requirements li.valid {
            color: #10b981;
        }

        .password-requirements li.invalid {
            color: #ef4444;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 576px) {
            .register-card {
                padding: 1.5rem;
            }
            .logo {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-card">
            <div class="register-header">
                <div class="logo">
                    <i class="bi bi-person-plus"></i>
                    <span>Staff Registration</span>
                </div>
                <p class="tagline">Join <?= htmlspecialchars($site_name) ?> Management System</p>
            </div>
            
            <div class="info-banner">
                <i class="bi bi-shield-check me-1"></i>
                <strong>Secure Registration</strong> Your information is protected and encrypted.
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-custom alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success alert-custom alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i>
                    <?= htmlspecialchars($success) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="registerForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="mb-3">
                    <label class="form-label required-field">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" name="username" id="username" 
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" 
                               placeholder="Choose a username" required>
                    </div>
                    <small class="text-muted" id="usernameHelp">This will be your display name throughout the system.</small>
                    <div id="usernameFeedback"></div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label required-field">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" name="email" id="email" 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                               placeholder="your.email@company.com" required>
                    </div>
                    <small class="text-muted">We'll send notifications to this email.</small>
                    <div id="emailFeedback"></div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label required-field">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password" id="password" 
                               placeholder="Create a password" required>
                        <button class="btn btn-outline-secondary toggle-password" type="button" data-target="password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                    <div id="passwordStrength" class="password-strength">
                        <div class="strength-meter">
                            <div class="strength-meter-fill" id="strengthFill"></div>
                        </div>
                        <small id="strengthText" class="text-muted"></small>
                    </div>
                    <?php if ($require_strong_password): ?>
                    <ul class="password-requirements" id="passwordRequirements">
                        <li id="req-length"><i class="bi bi-circle me-1"></i> At least 8 characters</li>
                        <li id="req-upper"><i class="bi bi-circle me-1"></i> At least one uppercase letter</li>
                        <li id="req-lower"><i class="bi bi-circle me-1"></i> At least one lowercase letter</li>
                        <li id="req-number"><i class="bi bi-circle me-1"></i> At least one number</li>
                        <li id="req-special"><i class="bi bi-circle me-1"></i> At least one special character ($@#&!)</li>
                    </ul>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label required-field">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" name="confirm_password" id="confirm_password" 
                               placeholder="Confirm your password" required>
                        <button class="btn btn-outline-secondary toggle-password" type="button" data-target="confirm_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                    <small id="passwordMatch" class="text-muted"></small>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Phone Number (Optional)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                        <input type="tel" class="form-control" name="phone" id="phone" 
                               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" 
                               placeholder="+27 XX XXX XXXX">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Department Code (Optional)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-building"></i></span>
                        <input type="text" class="form-control" name="department_code" id="department_code" 
                               value="<?= htmlspecialchars($_POST['department_code'] ?? '') ?>" 
                               placeholder="e.g., IT, HR, FIN, MKT">
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label">Department Name (Optional)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-briefcase"></i></span>
                        <input type="text" class="form-control" name="department_name" id="department_name" 
                               value="<?= htmlspecialchars($_POST['department_name'] ?? '') ?>" 
                               placeholder="e.g., Information Technology">
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="terms" required>
                        <label class="form-check-label" for="terms">
                            I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">Terms and Conditions</a>
                        </label>
                    </div>
                </div>
                
                <button type="submit" name="register" class="btn btn-register" id="registerBtn" disabled>
                    <i class="bi bi-person-plus me-2"></i> Create Account
                </button>
                
                <div class="mt-3">
                    <a href="index.php" class="btn btn-login">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Back to Login
                    </a>
                </div>
            </form>
            
            <div class="register-footer">
                <p class="mb-0">
                    <i class="bi bi-shield-check"></i> Your information is secure with us
                </p>
            </div>
        </div>
    </div>

    <!-- Terms Modal -->
    <div class="modal fade" id="termsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Terms and Conditions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6>1. Acceptance of Terms</h6>
                    <p>By registering for an account, you agree to comply with these terms and conditions.</p>
                    
                    <h6>2. Account Responsibilities</h6>
                    <p>You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>
                    
                    <h6>3. Acceptable Use</h6>
                    <p>You agree to use the <?= htmlspecialchars($site_name) ?> Management System only for legitimate business purposes and in compliance with all applicable laws and regulations.</p>
                    
                    <h6>4. Data Privacy</h6>
                    <p>Your personal information will be handled in accordance with our Privacy Policy and applicable data protection laws.</p>
                    
                    <h6>5. System Access</h6>
                    <p><?= htmlspecialchars($site_name) ?> reserves the right to suspend or terminate accounts that violate these terms or pose a security risk to the system.</p>
                    
                    <h6>6. Modifications</h6>
                    <p>We may modify these terms at any time. Continued use of the system constitutes acceptance of modified terms.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">I Understand</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password visibility toggle
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                const icon = this.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });
        
        // Password strength checker
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        const passwordMatch = document.getElementById('passwordMatch');
        const registerBtn = document.getElementById('registerBtn');
        const termsCheckbox = document.getElementById('terms');
        
        const requireStrongPassword = <?= json_encode($require_strong_password) ?>;
        
        function checkPasswordStrength(password) {
            let strength = 0;
            let message = '';
            
            // Check requirements
            const hasLength = password.length >= 8;
            const hasUpper = /[A-Z]/.test(password);
            const hasLower = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[$@#&!]/.test(password);
            
            if (hasLength) strength++;
            if (hasUpper) strength++;
            if (hasLower) strength++;
            if (hasNumber) strength++;
            if (hasSpecial && requireStrongPassword) strength++;
            
            // Update requirements list
            if (requireStrongPassword) {
                document.getElementById('req-length').innerHTML = `<i class="bi ${hasLength ? 'bi-check-circle-fill' : 'bi-circle'} me-1"></i> At least 8 characters`;
                document.getElementById('req-length').className = hasLength ? 'valid' : 'invalid';
                
                document.getElementById('req-upper').innerHTML = `<i class="bi ${hasUpper ? 'bi-check-circle-fill' : 'bi-circle'} me-1"></i> At least one uppercase letter`;
                document.getElementById('req-upper').className = hasUpper ? 'valid' : 'invalid';
                
                document.getElementById('req-lower').innerHTML = `<i class="bi ${hasLower ? 'bi-check-circle-fill' : 'bi-circle'} me-1"></i> At least one lowercase letter`;
                document.getElementById('req-lower').className = hasLower ? 'valid' : 'invalid';
                
                document.getElementById('req-number').innerHTML = `<i class="bi ${hasNumber ? 'bi-check-circle-fill' : 'bi-circle'} me-1"></i> At least one number`;
                document.getElementById('req-number').className = hasNumber ? 'valid' : 'invalid';
                
                document.getElementById('req-special').innerHTML = `<i class="bi ${hasSpecial ? 'bi-check-circle-fill' : 'bi-circle'} me-1"></i> At least one special character ($@#&!)`;
                document.getElementById('req-special').className = hasSpecial ? 'valid' : 'invalid';
            }
            
            strengthFill.className = 'strength-meter-fill';
            
            if (password.length === 0) {
                strengthFill.style.width = '0%';
                strengthText.textContent = '';
                return 0;
            }
            
            const maxStrength = requireStrongPassword ? 5 : 4;
            const percentage = (strength / maxStrength) * 100;
            
            if (strength <= 2) {
                strengthFill.classList.add('strength-weak');
                message = 'Weak password';
            } else if (strength === 3) {
                strengthFill.classList.add('strength-fair');
                message = 'Fair password';
            } else if (strength === 4) {
                strengthFill.classList.add('strength-good');
                message = 'Good password';
            } else {
                strengthFill.classList.add('strength-strong');
                message = 'Strong password';
            }
            
            strengthFill.style.width = percentage + '%';
            strengthText.textContent = message;
            return strength;
        }
        
        function checkPasswordMatch() {
            const password = passwordInput.value;
            const confirm = confirmInput.value;
            
            if (confirm.length === 0) {
                passwordMatch.textContent = '';
                return false;
            }
            
            if (password === confirm) {
                passwordMatch.innerHTML = '<i class="bi bi-check-circle-fill text-success me-1"></i> Passwords match';
                passwordMatch.style.color = '#10b981';
                return true;
            } else {
                passwordMatch.innerHTML = '<i class="bi bi-exclamation-circle-fill text-danger me-1"></i> Passwords do not match';
                passwordMatch.style.color = '#ef4444';
                return false;
            }
        }
        
        function checkUsername() {
            const username = document.getElementById('username').value.trim();
            const usernameHelp = document.getElementById('usernameFeedback');
            
            if (username.length < 3) {
                usernameHelp.innerHTML = '<small class="text-danger"><i class="bi bi-exclamation-circle"></i> Username must be at least 3 characters</small>';
                return false;
            } else if (username.length > 50) {
                usernameHelp.innerHTML = '<small class="text-danger"><i class="bi bi-exclamation-circle"></i> Username must be less than 50 characters</small>';
                return false;
            } else if (!/^[a-zA-Z0-9_]+$/.test(username)) {
                usernameHelp.innerHTML = '<small class="text-danger"><i class="bi bi-exclamation-circle"></i> Username can only contain letters, numbers, and underscores</small>';
                return false;
            } else {
                usernameHelp.innerHTML = '<small class="text-success"><i class="bi bi-check-circle"></i> Username available</small>';
                return true;
            }
        }
        
        function checkEmail() {
            const email = document.getElementById('email').value.trim();
            const emailHelp = document.getElementById('emailFeedback');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailRegex.test(email)) {
                emailHelp.innerHTML = '<small class="text-danger"><i class="bi bi-exclamation-circle"></i> Please enter a valid email address</small>';
                return false;
            } else {
                emailHelp.innerHTML = '<small class="text-success"><i class="bi bi-check-circle"></i> Valid email format</small>';
                return true;
            }
        }
        
        function validateForm() {
            const usernameValid = checkUsername();
            const emailValid = checkEmail();
            const password = passwordInput.value;
            const confirmValid = checkPasswordMatch();
            const termsChecked = termsCheckbox.checked;
            
            let passwordValid = true;
            
            if (requireStrongPassword) {
                const hasLength = password.length >= 8;
                const hasUpper = /[A-Z]/.test(password);
                const hasLower = /[a-z]/.test(password);
                const hasNumber = /[0-9]/.test(password);
                const hasSpecial = /[$@#&!]/.test(password);
                passwordValid = hasLength && hasUpper && hasLower && hasNumber && hasSpecial;
            } else {
                passwordValid = password.length >= 8;
            }
            
            const isValid = usernameValid && emailValid && passwordValid && confirmValid && termsChecked && password.length > 0;
            registerBtn.disabled = !isValid;
        }
        
        // Event listeners
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            checkPasswordMatch();
            validateForm();
        });
        
        confirmInput.addEventListener('input', function() {
            checkPasswordMatch();
            validateForm();
        });
        
        document.getElementById('username').addEventListener('input', function() {
            checkUsername();
            validateForm();
        });
        
        document.getElementById('email').addEventListener('input', function() {
            checkEmail();
            validateForm();
        });
        
        termsCheckbox.addEventListener('change', validateForm);
        
        // Initial validation
        validateForm();
        
        // Real-time validation styling
        document.getElementById('username').addEventListener('blur', checkUsername);
        document.getElementById('email').addEventListener('blur', checkEmail);
    </script>
</body>
</html>