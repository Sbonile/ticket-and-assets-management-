<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['name'] ?? 'Staff Member';

// Get staff statistics
try {
    // Get staff's assigned assets
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM assets 
        WHERE assigned_to = ? AND status = 'assigned'
    ");
    $stmt->execute([$userId]);
    $myAssets = $stmt->fetchColumn();
    
    // Get staff's tickets
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM assistance_requests 
        WHERE user_email = ? OR user_name = ?
    ");
    $stmt->execute([$_SESSION['email'] ?? '', $userName]);
    $myTickets = $stmt->fetchColumn();
    
    // Get open tickets for staff
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM assistance_requests 
        WHERE (user_email = ? OR user_name = ?) 
        AND status IN ('pending', 'in_progress')
    ");
    $stmt->execute([$_SESSION['email'] ?? '', $userName]);
    $openTickets = $stmt->fetchColumn();
    
    // Get resolved tickets
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM assistance_requests 
        WHERE (user_email = ? OR user_name = ?) 
        AND status = 'resolved'
    ");
    $stmt->execute([$_SESSION['email'] ?? '', $userName]);
    $resolvedTickets = $stmt->fetchColumn();
    
    // Get staff's assigned devices
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM devices 
        WHERE assigned_to = ?
    ");
    $stmt->execute([$userId]);
    $myDevices = $stmt->fetchColumn();
    
} catch (PDOException $e) {
    $myAssets = 0;
    $myTickets = 0;
    $openTickets = 0;
    $resolvedTickets = 0;
    $myDevices = 0;
}

// Get staff's recent tickets
try {
    $stmt = $pdo->prepare("
        SELECT * FROM assistance_requests 
        WHERE user_email = ? OR user_name = ?
        ORDER BY submitted_at DESC 
        LIMIT 10
    ");
    $stmt->execute([$_SESSION['email'] ?? '', $userName]);
    $recentTickets = $stmt->fetchAll();
} catch (PDOException $e) {
    $recentTickets = [];
}

// Get staff's assigned assets
try {
    $stmt = $pdo->prepare("
        SELECT * FROM assets 
        WHERE assigned_to = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$userId]);
    $assignedAssets = $stmt->fetchAll();
} catch (PDOException $e) {
    $assignedAssets = [];
}

// Get announcements
try {
    $stmt = $pdo->query("
        SELECT * FROM announcements 
        WHERE is_active = 1 
        AND (expires_at IS NULL OR expires_at > NOW()) 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    $announcements = [];
}

// Get unread notifications count
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    $unreadCount = $stmt->fetchColumn();
} catch (PDOException $e) {
    $unreadCount = 0;
}

// Get notifications
try {
    $stmt = $pdo->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    $notifications = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }
        
        /* Navbar */
        .navbar { 
            background: var(--primary-gradient);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand { 
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }
        
        .navbar-brand i {
            font-size: 1.6rem;
        }
        
        .navbar-brand:hover {
            color: white;
        }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            margin: 0 2px;
        }
        
        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
            font-weight: 600;
        }
        
        /* Notification Bell */
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover {
            background: rgba(255,255,255,0.15);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }
        
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: var(--radius-md);
            border: none;
            box-shadow: var(--shadow-lg);
            padding: 0;
        }
        
        .notifications-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            background: white;
            z-index: 1;
        }
        
        .notifications-header h6 {
            margin: 0;
            font-weight: 600;
        }
        
        .notification-item {
            padding: 0.875rem 1.25rem;
            border-bottom: 1px solid var(--border);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .notification-item:hover {
            background: #fefce8;
        }
        
        .notification-item.unread {
            background: #fffbeb;
            border-left: 3px solid var(--primary);
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            background: #fed7aa;
            color: var(--warning);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        .notification-title {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 4px;
        }
        
        .notification-message {
            font-size: 0.75rem;
            color: var(--gray);
            margin-bottom: 4px;
        }
        
        .notification-time {
            font-size: 0.65rem;
            color: #94a3b8;
        }
        
        /* Main Content */
        .main-content { 
            margin-top: 80px; 
            padding: 24px 28px;
            animation: fadeIn 0.4s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Welcome Section */
        .welcome-section {
            margin-bottom: 1.5rem;
        }
        
        .welcome-section h2 {
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 0.25rem;
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            line-height: 1.2;
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--gray);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Quick Actions */
        .quick-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .quick-action-btn {
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius-md);
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: white;
            border: 1px solid var(--border);
            color: var(--dark);
        }
        
        .quick-action-btn:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-2px);
        }
        
        .quick-action-btn i {
            color: var(--primary);
        }
        
        .quick-action-btn:hover i {
            color: white;
        }
        
        /* Cards */
        .card {
            border: none;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            font-size: 1rem;
            color: var(--dark);
        }
        
        .card-header i {
            color: var(--primary);
            font-size: 1.2rem;
        }
        
        /* Table Styles */
        .table {
            margin-bottom: 0;
        }
        
        .table thead th {
            background: #f8fafc;
            color: var(--gray);
            font-weight: 600;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.875rem 1rem;
            border-bottom: 2px solid var(--border);
        }
        
        .table tbody td {
            padding: 0.875rem 1rem;
            vertical-align: middle;
            color: var(--dark);
            font-size: 0.85rem;
        }
        
        .table tbody tr {
            transition: all 0.2s ease;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #fefce8;
        }
        
        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fed7aa; color: #9b2c1d; }
        .status-in_progress { background: #dbeafe; color: #1e40af; }
        .status-resolved { background: #d4f8e8; color: #065f46; }
        .status-available { background: #d4f8e8; color: #065f46; }
        .status-assigned { background: #dbeafe; color: #1e40af; }
        .status-maintenance { background: #fed7aa; color: #9b2c1d; }
        
        .priority-urgent { background: #e74c3c; color: white; }
        .priority-high { background: #f59e0b; color: white; }
        .priority-medium { background: #3b82f6; color: white; }
        .priority-low { background: #10b981; color: white; }
        
        /* Announcement Item */
        .announcement-item {
            padding: 0.875rem 1rem;
            border-bottom: 1px solid var(--border);
            transition: all 0.2s ease;
        }
        
        .announcement-item:last-child {
            border-bottom: none;
        }
        
        .announcement-item:hover {
            background: #fefce8;
        }
        
        .announcement-title {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 4px;
        }
        
        .announcement-content {
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        .announcement-date {
            font-size: 0.65rem;
            color: #94a3b8;
            margin-top: 4px;
        }
        
        /* Asset Item */
        .asset-item {
            background: #f8fafc;
            border-radius: 12px;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            transition: all 0.2s ease;
        }
        
        .asset-item:hover {
            background: #fefce8;
            transform: translateX(5px);
        }
        
        .asset-tag {
            font-family: monospace;
            background: #e2e8f0;
            padding: 2px 6px;
            border-radius: 6px;
            font-size: 0.7rem;
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary);
            background: transparent;
            color: var(--primary);
            font-weight: 600;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-gradient);
            border-color: transparent;
            color: white;
            transform: translateY(-1px);
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            opacity: 0.5;
        }
        
        /* Responsive */
        @media (max-width: 768px) { 
            .main-content { 
                padding: 16px; 
                margin-top: 70px;
            }
            .stat-value {
                font-size: 1.5rem;
            }
            .quick-actions {
                flex-direction: column;
            }
            .quick-action-btn {
                justify-content: center;
            }
            .notifications-dropdown {
                width: 320px;
                right: -60px !important;
            }
        }
        
        @media (max-width: 576px) {
            .stat-card {
                text-align: center;
            }
            .stat-icon {
                margin: 0 auto 10px;
            }
            .notifications-dropdown {
                width: 300px;
                right: -80px !important;
            }
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="staff_dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="staff_dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ticket-assistance.php">
                            <i class="bi bi-headset me-1"></i> Support
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_assets.php">
                            <i class="bi bi-box-seam me-1"></i> My Assets
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <!-- Notification Bell -->
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" id="notificationsDropdown">
                            <div class="notifications-header">
                                <h6><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="#" class="text-decoration-none small" data-bs-toggle="modal" data-bs-target="#notificationsModal">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($userName) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Notifications Modal -->
    <div class="modal fade" id="notificationsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-bell me-2"></i> Notifications</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="list-group list-group-flush" id="modalNotificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="text-center py-5 text-muted">
                                <i class="bi bi-bell-slash fs-1 d-block mb-2"></i>
                                <p>No notifications yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notification): ?>
                                <div class="list-group-item notification-item-modal <?= $notification['is_read'] ? '' : 'unread' ?>" data-id="<?= $notification['id'] ?>">
                                    <div class="d-flex gap-3">
                                        <div class="notification-icon" style="background: #fed7aa; color: #f59e0b;">
                                            <i class="bi bi-info-circle"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="fw-semibold"><?= htmlspecialchars($notification['title']) ?></div>
                                            <div class="small text-muted"><?= htmlspecialchars($notification['message']) ?></div>
                                            <div class="small text-muted mt-1">
                                                <?= date('M d, Y H:i', strtotime($notification['created_at'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if ($unreadCount > 0): ?>
                        <button type="button" class="btn btn-outline-primary" onclick="markAllAsRead()">
                            <i class="bi bi-check2-all"></i> Mark all as read
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h2>Welcome back, <?= htmlspecialchars($userName) ?>!</h2>
            <p class="text-muted">Here's an overview of your IT resources and support tickets.</p>
        </div>
        
        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='my_assets.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $myAssets ?></div>
                            <div class="stat-label">My Assets</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='my_devices.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $myDevices ?></div>
                            <div class="stat-label">My Devices</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-laptop"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='my_tickets.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $myTickets ?></div>
                            <div class="stat-label">Total Tickets</div>
                        </div>
                        <div class="stat-icon" style="background: #dbeafe; color: #3b82f6;">
                            <i class="bi bi-ticket-detailed"></i>
                        </div>
                    </div>
                    <div class="mt-2 small text-muted">
                        <span class="text-warning"><?= $openTickets ?> open</span> | 
                        <span class="text-success"><?= $resolvedTickets ?> resolved</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="window.location.href='ticket-assistance.php'">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-primary">New Ticket</div>
                            <div class="stat-label">Submit Request</div>
                        </div>
                        <div class="stat-icon" style="background: #d4f8e8; color: #10b981;">
                            <i class="bi bi-plus-circle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-lightning-charge me-2"></i> Quick Actions
                    </div>
                    <div class="card-body">
                        <div class="quick-actions">
                            <a href="ticket-assistance.php" class="quick-action-btn">
                                <i class="bi bi-headset"></i> Submit Support Ticket
                            </a>
                            <a href="my_assets.php" class="quick-action-btn">
                                <i class="bi bi-box-seam"></i> View My Assets
                            </a>
                            <a href="profile.php" class="quick-action-btn">
                                <i class="bi bi-person"></i> Update Profile
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Recent Tickets -->
            <div class="col-lg-7">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-clock-history me-2"></i> My Recent Support Tickets</span>
                        <a href="my_tickets.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-eye"></i> View All
                        </a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recentTickets)): ?>
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p class="mb-0">No tickets found</p>
                                <a href="ticket-assistance.php" class="btn btn-sm btn-outline-primary mt-3">Submit a Ticket</a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Issue Type</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Submitted</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentTickets as $ticket): ?>
                                            <tr>
                                                <td class="fw-semibold">#<?= $ticket['id'] ?></td>
                                                <td><?= htmlspecialchars($ticket['issue_type'] ?? 'Request') ?></td>
                                                <td>
                                                    <span class="status-badge status-<?= $ticket['status'] ?>">
                                                        <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge priority-<?= $ticket['priority'] ?? 'medium' ?>">
                                                        <?= ucfirst($ticket['priority'] ?? 'Medium') ?>
                                                    </span>
                                                </td>
                                                <td><?= date('M d, H:i', strtotime($ticket['submitted_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Announcements -->
            <div class="col-lg-5">
                <div class="card h-100">
                    <div class="card-header">
                        <i class="bi bi-megaphone me-2"></i> Announcements
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($announcements)): ?>
                            <div class="empty-state">
                                <i class="bi bi-chat-square-text"></i>
                                <p class="mb-0">No announcements</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($announcements as $announcement): ?>
                                <div class="announcement-item">
                                    <div class="announcement-title">
                                        <i class="bi bi-megaphone me-1" style="color: var(--primary);"></i>
                                        <?= htmlspecialchars($announcement['title']) ?>
                                    </div>
                                    <div class="announcement-content">
                                        <?= htmlspecialchars(substr($announcement['content'], 0, 100)) ?>
                                        <?= strlen($announcement['content']) > 100 ? '...' : '' ?>
                                    </div>
                                    <div class="announcement-date">
                                        <i class="bi bi-calendar3 me-1"></i>
                                        <?= date('M d, Y', strtotime($announcement['created_at'])) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- My Assets -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-box-seam me-2"></i> My Assigned Assets</span>
                        <a href="my_assets.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-eye"></i> View All
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($assignedAssets)): ?>
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p class="mb-0">No assets assigned to you</p>
                            </div>
                        <?php else: ?>
                            <div class="row g-3">
                                <?php foreach ($assignedAssets as $asset): ?>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="asset-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <strong><?= htmlspecialchars($asset['name']) ?></strong>
                                                    <div class="asset-tag mt-1"><?= htmlspecialchars($asset['asset_tag']) ?></div>
                                                </div>
                                                <span class="status-badge status-<?= $asset['status'] ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $asset['status'])) ?>
                                                </span>
                                            </div>
                                            <?php if ($asset['serial_number']): ?>
                                                <div class="small text-muted mt-2">
                                                    <i class="bi bi-upc-scan"></i> SN: <?= htmlspecialchars($asset['serial_number']) ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($asset['model']): ?>
                                                <div class="small text-muted">
                                                    <i class="bi bi-device-ssd"></i> <?= htmlspecialchars($asset['model']) ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Notification System
        let notificationPollingInterval = null;
        
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon">
                                <i class="bi bi-info-circle"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title">${escapeHtml(notif.title)}</div>
                                <div class="notification-message">${escapeHtml(notif.message)}</div>
                                <div class="notification-time">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                    location.reload();
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function startNotificationPolling() {
            if (notificationPollingInterval) clearInterval(notificationPollingInterval);
            notificationPollingInterval = setInterval(() => {
                fetch('api/notifications.php?action=get_count')
                    .then(r => r.json())
                    .then(data => {
                        if (data.success && data.unread_count > 0) {
                            const bellBadge = document.querySelector('.notification-badge');
                            if (bellBadge) {
                                bellBadge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                                bellBadge.style.display = 'flex';
                            }
                        }
                    })
                    .catch(err => console.error('Error checking notifications:', err));
            }, 30000);
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            startNotificationPolling();
        });
    </script>
</body>
</html>