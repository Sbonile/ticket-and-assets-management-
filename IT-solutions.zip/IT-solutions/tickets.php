<?php
// At the top of each page, after session start
require_once 'config/session.php';
require_once 'config/database.php';
require_once 'includes/header.php';

// Then your page content...

// At the bottom of each page
require_once 'includes/footer.php';

// Check if user is logged in and has admin access
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Check if user has admin role
$allowed_roles = ['admin', 'boss', 'it_tech'];
if (!in_array($_SESSION['role'] ?? '', $allowed_roles) && ($_SESSION['user_type'] ?? '') !== 'admin') {
    header("Location: dashboard.php");
    exit();
}

// Check if assistance_requests table exists, if not create it
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `assistance_requests` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_name` VARCHAR(100) NOT NULL,
            `user_email` VARCHAR(100) NOT NULL,
            `laptop_number` VARCHAR(50) DEFAULT NULL,
            `issue_type` VARCHAR(100) DEFAULT NULL,
            `description` TEXT NOT NULL,
            `status` VARCHAR(20) DEFAULT 'pending',
            `priority` VARCHAR(20) DEFAULT 'medium',
            `assigned_technician_id` INT(11) DEFAULT NULL,
            `public_notes` TEXT,
            `resolved_at` TIMESTAMP NULL DEFAULT NULL,
            `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_status` (`status`),
            KEY `idx_email` (`user_email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    
    // Create ticket_chat_messages table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `ticket_chat_messages` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `ticket_id` INT(11) NOT NULL,
            `sender_type` ENUM('user', 'technician', 'admin') NOT NULL,
            `sender_name` VARCHAR(100) NOT NULL,
            `message` TEXT NOT NULL,
            `is_read` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_ticket_id` (`ticket_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    
    // Create ticket_assignments table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `ticket_assignments` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `request_id` INT(11) NOT NULL,
            `technician_id` INT(11) NOT NULL,
            `assigned_by` VARCHAR(100) NOT NULL,
            `assigned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
} catch (PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
}

// Get all technicians for dropdown
try {
    $technicians = $pdo->query("
        SELECT id, name, status, current_tickets, max_tickets, email 
        FROM technicians 
        ORDER BY FIELD(status, 'available', 'busy', 'offline', 'on_leave'), name
    ")->fetchAll();
} catch (PDOException $e) {
    $technicians = [];
}

// Initialize stats with default values
$stats = [
    'total' => 0,
    'pending' => 0,
    'in_progress' => 0,
    'resolved' => 0,
    'urgent' => 0,
    'high' => 0,
    'medium' => 0,
    'low' => 0,
];

// Get ticket statistics
try {
    $stats['total'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests")->fetchColumn() ?: 0;
    $stats['pending'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE status = 'pending'")->fetchColumn() ?: 0;
    $stats['in_progress'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE status = 'in_progress'")->fetchColumn() ?: 0;
    $stats['resolved'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE status = 'resolved'")->fetchColumn() ?: 0;
    $stats['urgent'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE priority = 'urgent' AND status != 'resolved'")->fetchColumn() ?: 0;
    $stats['high'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE priority = 'high' AND status != 'resolved'")->fetchColumn() ?: 0;
    $stats['medium'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE priority = 'medium' AND status != 'resolved'")->fetchColumn() ?: 0;
    $stats['low'] = $pdo->query("SELECT COUNT(*) FROM assistance_requests WHERE priority = 'low' AND status != 'resolved'")->fetchColumn() ?: 0;
} catch (PDOException $e) {
    // Table might be empty or not exist yet
}

// Get all tickets with technician info
try {
    $tickets = $pdo->query("
        SELECT 
            ar.*,
            t.name as technician_name,
            t.email as technician_email,
            (SELECT message FROM ticket_chat_messages WHERE ticket_id = ar.id ORDER BY created_at DESC LIMIT 1) as last_message,
            (SELECT created_at FROM ticket_chat_messages WHERE ticket_id = ar.id ORDER BY created_at DESC LIMIT 1) as last_message_time,
            (SELECT COUNT(*) FROM ticket_chat_messages WHERE ticket_id = ar.id AND sender_type = 'user' AND is_read = 0) as unread_count
        FROM assistance_requests ar
        LEFT JOIN technicians t ON ar.assigned_technician_id = t.id
        ORDER BY FIELD(ar.priority, 'urgent', 'high', 'medium', 'low'), 
                 FIELD(ar.status, 'pending', 'in_progress', 'resolved'),
                 ar.submitted_at DESC
    ")->fetchAll();
} catch (PDOException $e) {
    $tickets = [];
}

// Get unread notifications count
$unreadCount = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$_SESSION['user_id']]);
    $unreadCount = $stmt->fetchColumn();
} catch (PDOException $e) {
    $unreadCount = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Management | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }
        
        .navbar { 
            background: var(--primary-gradient);
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            padding: 0.75rem 1.5rem;
        }
        
        .navbar-brand { 
            font-weight: 700;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }
        
        .navbar-brand i { font-size: 1.6rem; }
        
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }
        
        .notification-bell:hover { background: rgba(255,255,255,0.15); }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }
        
        .notifications-dropdown {
            width: 380px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: 16px;
            border: none;
            box-shadow: 0 20px 40px -12px rgba(0,0,0,0.2);
            padding: 0;
        }
        
        .main-content { 
            margin-top: 80px; 
            padding: 24px 28px;
        }
        
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.15);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }
        
        .stat-value { font-size: 2rem; font-weight: 700; color: #1e293b; }
        .stat-label { font-size: 0.75rem; color: #64748b; font-weight: 600; text-transform: uppercase; }
        
        .priority-summary {
            background: white;
            border-radius: 20px;
            padding: 1rem 1.5rem;
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        .priority-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .priority-urgent { background: #e74c3c; }
        .priority-high { background: #f39c12; }
        .priority-medium { background: #3498db; }
        .priority-low { background: #27ae60; }
        
        .card {
            border: none;
            border-radius: 24px;
            box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12);
            overflow: hidden;
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            color: #1e293b;
        }
        
        .card-header i { color: var(--primary); }
        
        .ticket-list-container {
            max-height: calc(100vh - 300px);
            overflow-y: auto;
        }
        
        .ticket-item {
            cursor: pointer;
            transition: all 0.2s ease;
            border-left: 4px solid transparent;
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .ticket-item:hover {
            background: #fefce8;
            transform: translateX(2px);
        }
        
        .ticket-item.active {
            background: var(--primary-light);
            border-left-color: var(--primary);
        }
        
        .ticket-priority-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .status-pending { background: #fed7aa; color: #9b2c1d; }
        .status-in_progress { background: #dbeafe; color: #1e40af; }
        .status-resolved { background: #d4f8e8; color: #065f46; }
        
        .chat-container {
            height: 500px;
            display: flex;
            flex-direction: column;
            background: #f8fafc;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }
        
        .message {
            max-width: 80%;
            padding: 0.75rem 1rem;
            border-radius: 18px;
            word-wrap: break-word;
        }
        
        .message-user {
            background: var(--primary-gradient);
            color: white;
            align-self: flex-start;
            border-bottom-left-radius: 4px;
        }
        
        .message-technician, .message-admin {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: white;
            align-self: flex-end;
            border-bottom-right-radius: 4px;
        }
        
        .message-meta { font-size: 0.65rem; opacity: 0.8; margin-top: 6px; }
        
        .chat-input-area {
            padding: 1rem 1.25rem;
            background: white;
            border-top: 1px solid #e9ecef;
        }
        
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
        }
        
        .search-box {
            position: relative;
            width: 200px;
        }
        
        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }
        
        .search-box input {
            padding-left: 32px;
            border-radius: 30px;
            border: 1px solid #e2e8f0;
            font-size: 0.8rem;
        }
        
        .unread-badge {
            background: #e74c3c;
            color: white;
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 0.65rem;
            font-weight: 600;
            margin-left: 8px;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #94a3b8;
        }
        
        .empty-state i { font-size: 3rem; margin-bottom: 1rem; opacity: 0.5; }
        
        .issue-details {
            background: #f8fafc;
            padding: 1rem;
            border-radius: 12px;
        }
        
        .form-control, .form-select {
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding: 0.5rem 0.75rem;
            font-size: 0.8rem;
        }
        
        textarea.form-control { resize: none; }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .main-content { animation: fadeIn 0.4s ease-out; }
        
        @media (max-width: 768px) { 
            .main-content { padding: 16px; margin-top: 70px; }
            .stat-value { font-size: 1.5rem; }
            .message { max-width: 90%; }
            .search-box { width: 140px; }
        }
        
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #e9ecef; border-radius: 3px; }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 3px; }
        
        .modal-content { border-radius: 24px; border: none; }
        .modal-header {
            background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%);
            border-bottom: 1px solid #fde68a;
        }
        .modal-header h5 { font-weight: 700; color: #92400e; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php"><i class="bi bi-laptop me-1"></i> Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="assets.php"><i class="bi bi-box-seam me-1"></i> Assets</a></li>
                    <li class="nav-item"><a class="nav-link active" href="tickets.php"><i class="bi bi-ticket-detailed me-1"></i> Tickets</a></li>
                    <li class="nav-item"><a class="nav-link" href="technicians.php"><i class="bi bi-people me-1"></i> Technicians</a></li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown p-0">
                            <div class="notifications-header p-3 border-bottom d-flex justify-content-between align-items-center sticky-top bg-white">
                                <h6 class="m-0"><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link text-decoration-none p-0" onclick="markAllAsRead()" style="color: var(--primary);">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-5 text-muted">
                                    <i class="bi bi-bell-slash fs-1 d-block mb-2"></i>
                                    <small>Loading...</small>
                                </div>
                            </div>
                            <div class="notifications-header border-top">
                                <a href="profile.php" class="text-decoration-none small" style="color: var(--primary);">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <!-- Statistics Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="filterTickets('all')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value"><?= $stats['total'] ?></div>
                            <div class="stat-label">Total Tickets</div>
                        </div>
                        <div class="stat-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="bi bi-ticket-detailed"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="filterTickets('pending')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-warning"><?= $stats['pending'] ?></div>
                            <div class="stat-label">Pending</div>
                        </div>
                        <div class="stat-icon" style="background: #fed7aa; color: #f59e0b;">
                            <i class="bi bi-clock-history"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="filterTickets('in_progress')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-info"><?= $stats['in_progress'] ?></div>
                            <div class="stat-label">In Progress</div>
                        </div>
                        <div class="stat-icon" style="background: #dbeafe; color: #3b82f6;">
                            <i class="bi bi-arrow-repeat"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card" onclick="filterTickets('resolved')">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="stat-value text-success"><?= $stats['resolved'] ?></div>
                            <div class="stat-label">Resolved</div>
                        </div>
                        <div class="stat-icon" style="background: #d4f8e8; color: #10b981;">
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Priority Summary -->
        <div class="row g-4 mb-4">
            <div class="col-12">
                <div class="priority-summary">
                    <div class="d-flex justify-content-around align-items-center flex-wrap gap-3">
                        <div class="d-flex align-items-center">
                            <span class="priority-dot priority-urgent"></span>
                            <span>Urgent: <strong><?= $stats['urgent'] ?></strong></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="priority-dot priority-high"></span>
                            <span>High: <strong><?= $stats['high'] ?></strong></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="priority-dot priority-medium"></span>
                            <span>Medium: <strong><?= $stats['medium'] ?></strong></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="priority-dot priority-low"></span>
                            <span>Low: <strong><?= $stats['low'] ?></strong></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Ticket Management -->
        <div class="row g-4">
            <!-- Ticket List -->
            <div class="col-md-5 col-lg-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span><i class="bi bi-list-ul me-2"></i>Support Tickets</span>
                        <div class="d-flex gap-2">
                            <div class="search-box">
                                <i class="bi bi-search"></i>
                                <input type="text" id="searchTickets" class="form-control form-control-sm" placeholder="Search tickets...">
                            </div>
                            <button class="btn btn-sm btn-outline-secondary" onclick="location.reload()" title="Refresh">
                                <i class="bi bi-arrow-repeat"></i>
                            </button>
                        </div>
                    </div>
                    <div class="ticket-list-container" id="ticketList">
                        <?php if (empty($tickets)): ?>
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p class="mt-2 mb-0">No tickets found</p>
                                <p class="small text-muted mt-1">Tickets will appear here when users submit support requests</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($tickets as $ticket): ?>
                                <div class="ticket-item" 
                                     data-ticket-id="<?= $ticket['id'] ?>"
                                     data-ticket-priority="<?= $ticket['priority'] ?>"
                                     data-ticket-status="<?= $ticket['status'] ?>"
                                     data-user-name="<?= htmlspecialchars($ticket['user_name']) ?>"
                                     data-user-email="<?= htmlspecialchars($ticket['user_email']) ?>"
                                     data-description="<?= htmlspecialchars($ticket['description']) ?>"
                                     data-laptop-number="<?= htmlspecialchars($ticket['laptop_number'] ?? 'N/A') ?>"
                                     data-submitted-at="<?= $ticket['submitted_at'] ?>"
                                     data-issue-type="<?= htmlspecialchars($ticket['issue_type'] ?? 'Request') ?>"
                                     data-assigned-tech="<?= $ticket['assigned_technician_id'] ?? '' ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div class="d-flex align-items-center">
                                            <span class="ticket-priority-dot priority-<?= $ticket['priority'] ?>"></span>
                                            <strong class="ms-1">#<?= $ticket['id'] ?></strong>
                                            <span class="ms-2 text-truncate" style="max-width: 120px;"><?= htmlspecialchars(substr($ticket['issue_type'] ?? 'Request', 0, 20)) ?></span>
                                        </div>
                                        <span class="status-badge status-<?= $ticket['status'] ?>">
                                            <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                        </span>
                                    </div>
                                    <div class="small text-muted mt-1">
                                        <i class="bi bi-person"></i> <?= htmlspecialchars(substr($ticket['user_name'], 0, 20)) ?>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <div class="small text-muted">
                                            <i class="bi bi-calendar"></i> <?= date('M d, H:i', strtotime($ticket['submitted_at'])) ?>
                                        </div>
                                        <?php if (($ticket['unread_count'] ?? 0) > 0): ?>
                                            <span class="unread-badge"><?= $ticket['unread_count'] ?> new</span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($ticket['last_message'])): ?>
                                        <div class="small text-muted mt-1 text-truncate">
                                            <i class="bi bi-chat"></i> <?= htmlspecialchars(substr($ticket['last_message'], 0, 40)) ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($ticket['technician_name'])): ?>
                                        <div class="small text-muted mt-1">
                                            <i class="bi bi-person-badge"></i> Assigned to: <?= htmlspecialchars($ticket['technician_name']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Ticket Details & Chat -->
            <div class="col-md-7 col-lg-8">
                <div id="noTicketSelected" class="card h-100">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-chat-dots fs-1 text-muted"></i>
                        <h5 class="mt-3">Select a ticket to view details</h5>
                        <p class="text-muted">Click on any ticket from the list to start managing it</p>
                    </div>
                </div>

                <div id="ticketDetails" class="card h-100" style="display: none;">
                    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <h5 class="mb-0">Ticket #<span id="ticketIdDisplay"></span></h5>
                            <div class="mt-1 small">
                                <span id="ticketUser" class="me-3"><i class="bi bi-person"></i> <span></span></span>
                                <span id="ticketEmail"><i class="bi bi-envelope"></i> <span></span></span>
                            </div>
                        </div>
                        <div class="d-flex gap-2 flex-wrap">
                            <select id="ticketPriority" class="form-select form-select-sm" style="width: 110px;" onchange="updateTicketPriority()">
                                <option value="low">🟢 Low</option>
                                <option value="medium">🔵 Medium</option>
                                <option value="high">🟠 High</option>
                                <option value="urgent">🔴 Urgent</option>
                            </select>
                            <select id="ticketStatus" class="form-select form-select-sm" style="width: 130px;" onchange="updateTicketStatus()">
                                <option value="pending">⏳ Pending</option>
                                <option value="in_progress">🔄 In Progress</option>
                                <option value="resolved">✅ Resolved</option>
                            </select>
                            <select id="assignTechnician" class="form-select form-select-sm" style="width: 180px;" onchange="assignTechnician()">
                                <option value="">👨‍🔧 Assign to...</option>
                                <?php foreach ($technicians as $tech): ?>
                                    <option value="<?= $tech['id'] ?>">
                                        <?= htmlspecialchars($tech['name']) ?> 
                                        (<?= $tech['current_tickets'] ?? 0 ?>/<?= $tech['max_tickets'] ?? 5 ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="card-body p-0 d-flex flex-column">
                        <!-- Issue Details -->
                        <div class="p-3 border-bottom">
                            <h6 class="mb-2"><i class="bi bi-info-circle me-1"></i> Issue Details</h6>
                            <div class="issue-details">
                                <p id="ticketDescription" class="mb-0"></p>
                            </div>
                            <div class="mt-2 small text-muted">
                                <span id="ticketLaptop"><i class="bi bi-laptop"></i> Laptop: <span></span></span>
                                <span id="ticketSubmitted" class="ms-3"><i class="bi bi-calendar"></i> Submitted: <span></span></span>
                            </div>
                        </div>
                        
                        <!-- Chat Section -->
                        <div class="chat-container">
                            <div class="chat-messages" id="chatMessages">
                                <div class="empty-state">
                                    <i class="bi bi-chat-dots fs-3"></i>
                                    <p>Select a ticket to start conversation</p>
                                </div>
                            </div>
                            <div class="chat-input-area">
                                <div class="input-group">
                                    <textarea class="form-control" id="messageInput" rows="2" placeholder="Type your message here..." disabled></textarea>
                                    <button class="btn btn-primary" id="sendMessageBtn" disabled onclick="sendMessage()">
                                        <i class="bi bi-send"></i> Send
                                    </button>
                                </div>
                                <div class="small text-muted mt-2">
                                    <i class="bi bi-info-circle"></i> Messages will be visible to the user
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentTicketId = null;
        let lastMessageId = 0;
        let pollingInterval = null;
        let currentFilter = 'all';
        let currentSearch = '';

        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }
        
        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                html += `
                    <div class="notification-item p-3 border-bottom ${!notif.is_read ? 'unread' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon" style="background: #fed7aa; color: #f59e0b;">
                                <i class="bi bi-info-circle"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title fw-semibold">${escapeHtml(notif.title)}</div>
                                <div class="notification-message small text-muted">${escapeHtml(notif.message)}</div>
                                <div class="notification-time small">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }
        
        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }
        
        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Ticket selection
        document.querySelectorAll('.ticket-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.ticket-item').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                currentTicketId = this.dataset.ticketId;
                
                document.getElementById('ticketIdDisplay').textContent = currentTicketId;
                document.getElementById('ticketUser').querySelector('span').textContent = this.dataset.userName;
                document.getElementById('ticketEmail').querySelector('span').textContent = this.dataset.userEmail;
                document.getElementById('ticketDescription').textContent = this.dataset.description;
                document.getElementById('ticketLaptop').querySelector('span').textContent = this.dataset.laptopNumber;
                document.getElementById('ticketSubmitted').querySelector('span').textContent = new Date(this.dataset.submittedAt).toLocaleString();
                
                document.getElementById('ticketPriority').value = this.dataset.ticketPriority;
                document.getElementById('ticketStatus').value = this.dataset.ticketStatus;
                
                const assignSelect = document.getElementById('assignTechnician');
                if (assignSelect) {
                    assignSelect.value = this.dataset.assignedTech || '';
                }
                
                document.getElementById('noTicketSelected').style.display = 'none';
                document.getElementById('ticketDetails').style.display = 'flex';
                document.getElementById('messageInput').disabled = false;
                document.getElementById('sendMessageBtn').disabled = false;
                
                loadMessages();
                markMessagesAsRead();
                
                if (pollingInterval) clearInterval(pollingInterval);
                pollingInterval = setInterval(() => {
                    loadMessages();
                }, 5000);
            });
        });
        
        function filterTickets(status) {
            currentFilter = status;
            const items = document.querySelectorAll('.ticket-item');
            items.forEach(item => {
                if (status === 'all' || item.dataset.ticketStatus === status) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }
        
        document.getElementById('searchTickets')?.addEventListener('keyup', function() {
            currentSearch = this.value.toLowerCase();
            const items = document.querySelectorAll('.ticket-item');
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(currentSearch)) {
                    if (currentFilter === 'all' || item.dataset.ticketStatus === currentFilter) {
                        item.style.display = '';
                    }
                } else {
                    item.style.display = 'none';
                }
            });
        });
        
        function loadMessages() {
            if (!currentTicketId) return;
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_messages&ticket_id=${currentTicketId}&last_id=${lastMessageId}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.messages && data.messages.length > 0) {
                    data.messages.forEach(msg => {
                        addMessageToChat(msg);
                        if (msg.id > lastMessageId) lastMessageId = msg.id;
                    });
                    scrollChatToBottom();
                }
            })
            .catch(err => console.error('Error loading messages:', err));
        }
        
        function addMessageToChat(message) {
            const chatMessages = document.getElementById('chatMessages');
            const emptyState = chatMessages.querySelector('.empty-state');
            if (emptyState) emptyState.remove();
            
            const messageDiv = document.createElement('div');
            const isUser = message.sender_type === 'user';
            const senderClass = isUser ? 'message-user' : 'message-admin';
            const senderName = message.sender_type === 'user' ? message.sender_name : 'Admin: ' + message.sender_name;
            
            messageDiv.className = `message ${senderClass}`;
            messageDiv.innerHTML = `
                <div class="fw-semibold small">${escapeHtml(senderName)}</div>
                <div>${escapeHtml(message.message)}</div>
                <div class="message-meta">${new Date(message.created_at).toLocaleString()}</div>
            `;
            chatMessages.appendChild(messageDiv);
        }
        
        function scrollChatToBottom() {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        function markMessagesAsRead() {
            if (!currentTicketId) return;
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=mark_messages_read&ticket_id=${currentTicketId}`
            })
            .catch(err => console.error('Error marking messages as read:', err));
        }
        
        function sendMessage() {
            const messageInput = document.getElementById('messageInput');
            const message = messageInput.value.trim();
            
            if (!message || !currentTicketId) return;
            
            const adminName = '<?= htmlspecialchars($_SESSION['name'] ?? 'Admin') ?>';
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=send_message&ticket_id=${currentTicketId}&message=${encodeURIComponent(message)}&sender_type=admin&sender_name=${encodeURIComponent(adminName)}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    messageInput.value = '';
                    loadMessages();
                } else {
                    alert('Failed to send message: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => {
                console.error('Error sending message:', err);
                alert('Failed to send message');
            });
        }
        
        function updateTicketPriority() {
            const priority = document.getElementById('ticketPriority').value;
            if (!currentTicketId) return;
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=set_priority&ticket_id=${currentTicketId}&priority=${priority}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const ticketItem = document.querySelector(`.ticket-item[data-ticket-id="${currentTicketId}"]`);
                    if (ticketItem) {
                        ticketItem.dataset.ticketPriority = priority;
                        const priorityDot = ticketItem.querySelector('.ticket-priority-dot');
                        if (priorityDot) {
                            priorityDot.className = `ticket-priority-dot priority-${priority}`;
                        }
                    }
                }
            })
            .catch(err => console.error('Error updating priority:', err));
        }
        
        function updateTicketStatus() {
            const status = document.getElementById('ticketStatus').value;
            if (!currentTicketId) return;
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=update_ticket_status&ticket_id=${currentTicketId}&status=${status}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(err => console.error('Error updating status:', err));
        }
        
        function assignTechnician() {
            const technicianId = document.getElementById('assignTechnician').value;
            if (!currentTicketId || !technicianId) return;
            
            fetch('api/ticket_messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=assign_technician&ticket_id=${currentTicketId}&technician_id=${technicianId}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Failed to assign technician: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => console.error('Error assigning technician:', err));
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
        });
    </script>
</body>
</html>