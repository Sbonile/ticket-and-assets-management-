<?php
// config/company.php - White Label Configuration
return [
    // Company Information
    'company' => [
        'name' => 'Your Company Name',
        'short_name' => 'YCN',
        'logo_text' => 'Your Company',
        'logo_icon' => 'bi-building', // Bootstrap icon class
        'email' => 'support@yourcompany.com',
        'phone' => '+27 10 123 4567',
        'website' => 'https://yourcompany.com',
        'address' => '123 Business St, Johannesburg, 2000',
        'registration_number' => 'REG123456',
        'vat_number' => 'ZA1234567890',
    ],
    
    // Branding Colors
    'colors' => [
        'primary' => '#f39c12',      // Main brand color
        'primary_dark' => '#e67e22', // Darker shade
        'primary_light' => '#fef3c7', // Lighter shade
        'secondary' => '#1e293b',    // Secondary color
        'success' => '#10b981',
        'danger' => '#ef4444',
        'warning' => '#f59e0b',
        'info' => '#3b82f6',
    ],
    
    // Theme Settings
    'theme' => [
        'logo_path' => 'assets/images/logo.png', // Path to custom logo
        'favicon_path' => 'assets/images/favicon.ico',
        'login_background' => 'assets/images/login-bg.jpg',
        'dashboard_icon' => 'bi-building', // Icon for dashboard
    ],
    
    // System Settings
    'system' => [
        'name' => 'Your System Name',
        'version' => '1.0.0',
        'support_email' => 'support@yourcompany.com',
        'support_phone' => '+27 10 123 4567',
        'timezone' => 'Africa/Johannesburg',
    ],
    
    // Footer Text
    'footer' => [
        'copyright' => '© ' . date('Y') . ' Your Company Name. All rights reserved.',
        'powered_by' => 'Powered by Your Company',
        'show_version' => true,
    ],
];