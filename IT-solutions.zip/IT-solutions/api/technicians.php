<?php
// api/technicians.php - Technician API (Integrated with Users Table)
require_once '../config/session.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// Check if user is admin
$isAdmin = ($_SESSION['role'] === 'admin' || $_SESSION['user_type'] === 'admin');
if (!$isAdmin) {
    echo json_encode(['success' => false, 'error' => 'Admin access required']);
    exit();
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'update_status':
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        $status = $_POST['status'] ?? '';
        $validStatuses = ['available', 'busy', 'offline', 'on_leave'];
        
        if (!$id || !in_array($status, $validStatuses)) {
            echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
            exit();
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE technicians SET status = ? WHERE id = ?");
            $success = $stmt->execute([$status, $id]);
            
            if ($success) {
                // Get technician details for notification
                $stmt = $pdo->prepare("SELECT user_id, name FROM technicians WHERE id = ?");
                $stmt->execute([$id]);
                $tech = $stmt->fetch();
                
                // Create notification for the technician
                if ($tech && $tech['user_id']) {
                    $stmt = $pdo->prepare("
                        INSERT INTO notifications (user_id, title, message, type, created_at) 
                        VALUES (?, ?, ?, 'system', NOW())
                    ");
                    $statusMsg = ucfirst(str_replace('_', ' ', $status));
                    $stmt->execute([$tech['user_id'], 'Status Updated', "Your status has been updated to: {$statusMsg}"]);
                }
            }
            
            echo json_encode(['success' => $success]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'toggle_leave':
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$id) {
            echo json_encode(['success' => false, 'error' => 'Invalid ID']);
            exit();
        }
        
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("SELECT on_leave, user_id, name FROM technicians WHERE id = ?");
            $stmt->execute([$id]);
            $tech = $stmt->fetch();
            
            if ($tech) {
                $newLeaveStatus = $tech['on_leave'] ? 0 : 1;
                $stmt = $pdo->prepare("UPDATE technicians SET on_leave = ?, status = ? WHERE id = ?");
                $newStatus = $newLeaveStatus ? 'on_leave' : 'available';
                $stmt->execute([$newLeaveStatus, $newStatus, $id]);
                
                // Create notification
                $message = $newLeaveStatus ? "You have been marked on leave." : "You have returned from leave.";
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, ?, ?, 'system', NOW())
                ");
                $stmt->execute([$tech['user_id'], 'Leave Status Updated', $message]);
            }
            
            $pdo->commit();
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'delete':
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$id) {
            echo json_encode(['success' => false, 'error' => 'Invalid ID']);
            exit();
        }
        
        try {
            $pdo->beginTransaction();
            
            // Get user_id first
            $stmt = $pdo->prepare("SELECT user_id FROM technicians WHERE id = ?");
            $stmt->execute([$id]);
            $tech = $stmt->fetch();
            
            if ($tech) {
                // Delete from technicians table
                $stmt = $pdo->prepare("DELETE FROM technicians WHERE id = ?");
                $stmt->execute([$id]);
                
                // Update users table - set status to inactive instead of deleting
                $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
                $stmt->execute([$tech['user_id']]);
            }
            
            $pdo->commit();
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'add':
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $maxTickets = filter_var($_POST['max_tickets'] ?? 5, FILTER_VALIDATE_INT);
        $department_code = trim($_POST['department_code'] ?? 'IT');
        $department_name = $_POST['department_name'] ?? '';
        
        // Map department codes to names
        $deptNames = [
            'IT' => 'Information Technology',
            'HR' => 'Human Resources',
            'FIN' => 'Finance',
            'OPS' => 'Operations',
            'MKT' => 'Marketing',
            'SALES' => 'Sales'
        ];
        
        if (empty($department_name)) {
            $department_name = $deptNames[$department_code] ?? 'Information Technology';
        }
        
        if (empty($name) || empty($email)) {
            echo json_encode(['success' => false, 'error' => 'Name and email are required']);
            exit();
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'error' => 'Invalid email format']);
            exit();
        }
        
        try {
            $pdo->beginTransaction();
            
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Email already exists']);
                exit();
            }
            
            // Default password (should be changed on first login)
            $defaultPassword = password_hash('password123', PASSWORD_DEFAULT);
            
            // Insert into users table
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password, phone, role, user_type, department_code, department_name, status, created_at) 
                VALUES (?, ?, ?, ?, 'staff', 'technician', ?, ?, 'active', NOW())
            ");
            $stmt->execute([$name, $email, $defaultPassword, $phone, $department_code, $department_name]);
            $user_id = $pdo->lastInsertId();
            
            // Insert into technicians table
            $stmt = $pdo->prepare("
                INSERT INTO technicians (user_id, name, email, phone, status, max_tickets, current_tickets, total_tickets_resolved, on_leave, created_at) 
                VALUES (?, ?, ?, ?, 'available', ?, 0, 0, 0, NOW())
            ");
            $stmt->execute([$user_id, $name, $email, $phone, $maxTickets]);
            
            // Create welcome notification
            $stmt = $pdo->prepare("
                INSERT INTO notifications (user_id, title, message, type, created_at) 
                VALUES (?, ?, ?, 'system', NOW())
            ");
            $stmt->execute([$user_id, 'Welcome to IT Solutions', 'You have been added as a technician. Your default password is "password123". Please change it after logging in.']);
            
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Technician added successfully']);
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'edit':
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $maxTickets = filter_var($_POST['max_tickets'] ?? 5, FILTER_VALIDATE_INT);
        $status = $_POST['status'] ?? 'available';
        $on_leave = isset($_POST['on_leave']) ? 1 : 0;
        
        if (!$id || empty($name) || empty($email)) {
            echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
            exit();
        }
        
        try {
            $pdo->beginTransaction();
            
            // Update technicians table
            $stmt = $pdo->prepare("
                UPDATE technicians SET 
                    name = ?, email = ?, phone = ?, max_tickets = ?, status = ?, on_leave = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $phone, $maxTickets, $status, $on_leave, $id]);
            
            // Update users table
            $stmt = $pdo->prepare("
                UPDATE users SET username = ?, email = ?, phone = ?
                WHERE id = (SELECT user_id FROM technicians WHERE id = ?)
            ");
            $stmt->execute([$name, $email, $phone, $id]);
            
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Technician updated successfully']);
        } catch (PDOException $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'get':
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$id) {
            echo json_encode(['success' => false, 'error' => 'Invalid ID']);
            exit();
        }
        
        try {
            $stmt = $pdo->prepare("
                SELECT t.*, u.department_code, u.department_name 
                FROM technicians t
                LEFT JOIN users u ON t.user_id = u.id
                WHERE t.id = ?
            ");
            $stmt->execute([$id]);
            $technician = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'technician' => $technician]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'get_all':
        try {
            $stmt = $pdo->query("
                SELECT t.*, 
                       u.department_code, u.department_name, u.status as user_status,
                       (SELECT COUNT(*) FROM tickets WHERE assigned_technician_id = t.id AND status IN ('pending', 'in_progress')) as current_jobs,
                       (SELECT COUNT(*) FROM tickets WHERE assigned_technician_id = t.id AND status = 'resolved') as total_tickets_resolved
                FROM technicians t
                LEFT JOIN users u ON t.user_id = u.id
                ORDER BY FIELD(t.status, 'available', 'busy', 'offline', 'on_leave'), t.name
            ");
            $technicians = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'technicians' => $technicians]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>