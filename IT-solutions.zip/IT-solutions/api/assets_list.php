<?php
// api/assets_list.php - Get all assets for modal
require_once '../config/session.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$assets = $pdo->query("
    SELECT a.*, u.username as assigned_username 
    FROM assets a 
    LEFT JOIN users u ON a.assigned_to = u.id 
    ORDER BY a.created_at DESC
")->fetchAll();

echo json_encode(['success' => true, 'assets' => $assets]);
?>