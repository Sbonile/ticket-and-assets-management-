<?php
// api/ticket_messages.php - Ticket Messages API (Fully Integrated)
require_once '../config/session.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$action = $_POST['action'] ?? '';
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'] ?? '';
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['name'] ?? 'User';
$isAdmin = ($userRole === 'admin' || $userType === 'admin');

switch ($action) {
    case 'send_message':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $message = trim($_POST['message'] ?? '');
        $senderType = $_POST['sender_type'] ?? 'admin';
        $senderName = trim($_POST['sender_name'] ?? $userName);
        
        if (!$ticketId || empty($message)) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID or message']);
            exit();
        }
        
        // Verify user has access to this ticket
        $stmt = $pdo->prepare("
            SELECT ar.*, t.name as technician_name 
            FROM assistance_requests ar
            LEFT JOIN technicians t ON ar.assigned_technician_id = t.id
            WHERE ar.id = ?
        ");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            exit();
        }
        
        // Check permissions
        $hasAccess = false;
        if ($isAdmin) {
            $hasAccess = true;
        } elseif ($userType === 'technician') {
            // Check if technician is assigned to this ticket
            $stmt = $pdo->prepare("SELECT id FROM technicians WHERE user_id = ?");
            $stmt->execute([$userId]);
            $tech = $stmt->fetch();
            if ($tech && $ticket['assigned_technician_id'] == $tech['id']) {
                $hasAccess = true;
                $senderType = 'technician';
            }
        }
        
        if (!$hasAccess) {
            echo json_encode(['success' => false, 'error' => 'You do not have permission to message on this ticket']);
            exit();
        }
        
        // Insert message
        $stmt = $pdo->prepare("
            INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, is_read, created_at) 
            VALUES (?, ?, ?, ?, 0, NOW())
        ");
        $success = $stmt->execute([$ticketId, $senderType, $senderName, $message]);
        
        if ($success) {
            $messageId = $pdo->lastInsertId();
            
            // Update ticket updated_at
            $stmt = $pdo->prepare("UPDATE assistance_requests SET updated_at = NOW() WHERE id = ?");
            $stmt->execute([$ticketId]);
            
            // Create notification for the other party
            $notificationUserId = null;
            $notificationTitle = "New Message on Ticket #" . str_pad($ticketId, 6, '0', STR_PAD_LEFT);
            $notificationMessage = "{$senderName} sent a message on your support ticket.";
            
            if ($senderType === 'user') {
                // Notify assigned technician
                if ($ticket['assigned_technician_id']) {
                    $stmt = $pdo->prepare("SELECT user_id FROM technicians WHERE id = ?");
                    $stmt->execute([$ticket['assigned_technician_id']]);
                    $techUser = $stmt->fetch();
                    if ($techUser) {
                        $notificationUserId = $techUser['user_id'];
                    }
                }
                // Also notify admins
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    SELECT id, ?, ?, 'ticket', NOW() 
                    FROM users WHERE role = 'admin' AND status = 'active'
                ");
                $stmt->execute([$notificationTitle, $notificationMessage]);
            } else {
                // Notify the user who created the ticket
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$ticket['user_email']]);
                $user = $stmt->fetch();
                if ($user) {
                    $notificationUserId = $user['id'];
                }
            }
            
            if ($notificationUserId) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, ?, ?, 'ticket', NOW())
                ");
                $stmt->execute([$notificationUserId, $notificationTitle, $notificationMessage]);
            }
            
            echo json_encode(['success' => true, 'message_id' => $messageId]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to send message']);
        }
        break;
        
    case 'get_messages':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $lastId = filter_var($_POST['last_id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$ticketId) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID']);
            exit();
        }
        
        // Verify user has access
        $stmt = $pdo->prepare("
            SELECT ar.*, t.name as technician_name, t.user_id as technician_user_id 
            FROM assistance_requests ar
            LEFT JOIN technicians t ON ar.assigned_technician_id = t.id
            WHERE ar.id = ?
        ");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            exit();
        }
        
        $hasAccess = false;
        if ($isAdmin) {
            $hasAccess = true;
        } elseif ($userType === 'technician') {
            $stmt = $pdo->prepare("SELECT id FROM technicians WHERE user_id = ?");
            $stmt->execute([$userId]);
            $tech = $stmt->fetch();
            if ($tech && $ticket['assigned_technician_id'] == $tech['id']) {
                $hasAccess = true;
            }
        } else {
            // Regular staff - check if email matches
            $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            if ($user && $user['email'] === $ticket['user_email']) {
                $hasAccess = true;
            }
        }
        
        if (!$hasAccess) {
            echo json_encode(['success' => false, 'error' => 'You do not have permission to view these messages']);
            exit();
        }
        
        // Get messages
        $stmt = $pdo->prepare("
            SELECT * FROM ticket_chat_messages 
            WHERE ticket_id = ? AND id > ?
            ORDER BY created_at ASC
        ");
        $stmt->execute([$ticketId, $lastId]);
        $messages = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'messages' => $messages]);
        break;
        
    case 'mark_messages_read':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$ticketId) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID']);
            exit();
        }
        
        // Mark messages as read based on sender type
        if ($isAdmin || $userType === 'technician') {
            // Admin/technician marks user messages as read
            $stmt = $pdo->prepare("
                UPDATE ticket_chat_messages 
                SET is_read = 1 
                WHERE ticket_id = ? AND sender_type = 'user' AND is_read = 0
            ");
        } else {
            // User marks admin/technician messages as read
            $stmt = $pdo->prepare("
                UPDATE ticket_chat_messages 
                SET is_read = 1 
                WHERE ticket_id = ? AND sender_type IN ('admin', 'technician') AND is_read = 0
            ");
        }
        $stmt->execute([$ticketId]);
        
        echo json_encode(['success' => true]);
        break;
        
    case 'update_ticket_status':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $status = $_POST['status'] ?? '';
        $validStatuses = ['pending', 'in_progress', 'resolved'];
        
        if (!$ticketId || !in_array($status, $validStatuses)) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID or status']);
            exit();
        }
        
        // Check permissions
        if (!$isAdmin && $userType !== 'technician') {
            echo json_encode(['success' => false, 'error' => 'Only admins and technicians can update ticket status']);
            exit();
        }
        
        // Get old status for notification
        $stmt = $pdo->prepare("SELECT user_email, assigned_technician_id FROM assistance_requests WHERE id = ?");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            exit();
        }
        
        $oldStatus = $ticket['status'];
        
        // Update status
        $stmt = $pdo->prepare("
            UPDATE assistance_requests 
            SET status = ?, updated_at = NOW(),
                resolved_at = CASE WHEN ? = 'resolved' AND resolved_at IS NULL THEN NOW() ELSE resolved_at END
            WHERE id = ?
        ");
        $success = $stmt->execute([$status, $status, $ticketId]);
        
        if ($success && $oldStatus !== $status) {
            // Add system message about status change
            $statusMessages = [
                'pending' => 'Ticket status changed to: Pending',
                'in_progress' => 'Ticket status changed to: In Progress',
                'resolved' => '🎉 Ticket has been marked as Resolved!'
            ];
            
            $stmt = $pdo->prepare("
                INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, created_at) 
                VALUES (?, 'admin', 'System', ?, NOW())
            ");
            $stmt->execute([$ticketId, $statusMessages[$status] ?? "Status updated to: " . ucfirst($status)]);
            
            // Notify user
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$ticket['user_email']]);
            $user = $stmt->fetch();
            if ($user) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, ?, ?, 'ticket', NOW())
                ");
                $stmt->execute([
                    $user['id'],
                    "Ticket #" . str_pad($ticketId, 6, '0', STR_PAD_LEFT),
                    "Your ticket status has been updated to: " . ucfirst(str_replace('_', ' ', $status))
                ]);
            }
        }
        
        echo json_encode(['success' => $success]);
        break;
        
    case 'set_priority':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $priority = $_POST['priority'] ?? '';
        $validPriorities = ['low', 'medium', 'high', 'urgent'];
        
        if (!$ticketId || !in_array($priority, $validPriorities)) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID or priority']);
            exit();
        }
        
        // Only admins can set priority
        if (!$isAdmin) {
            echo json_encode(['success' => false, 'error' => 'Only admins can set ticket priority']);
            exit();
        }
        
        $stmt = $pdo->prepare("UPDATE assistance_requests SET priority = ?, updated_at = NOW() WHERE id = ?");
        $success = $stmt->execute([$priority, $ticketId]);
        
        if ($success) {
            // Add system message
            $stmt = $pdo->prepare("
                INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, created_at) 
                VALUES (?, 'admin', 'System', ?, NOW())
            ");
            $priorityIcons = ['low' => '🟢', 'medium' => '🟡', 'high' => '🟠', 'urgent' => '🔴'];
            $stmt->execute([$ticketId, "Priority set to: {$priorityIcons[$priority]} " . ucfirst($priority)]);
        }
        
        echo json_encode(['success' => $success]);
        break;
        
    case 'assign_technician':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $technicianId = filter_var($_POST['technician_id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$ticketId || !$technicianId) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket or technician ID']);
            exit();
        }
        
        // Only admins can assign technicians
        if (!$isAdmin) {
            echo json_encode(['success' => false, 'error' => 'Only admins can assign technicians']);
            exit();
        }
        
        // Get technician name and user_id
        $stmt = $pdo->prepare("SELECT name, user_id FROM technicians WHERE id = ?");
        $stmt->execute([$technicianId]);
        $tech = $stmt->fetch();
        
        if (!$tech) {
            echo json_encode(['success' => false, 'error' => 'Technician not found']);
            exit();
        }
        
        $technicianName = $tech['name'];
        $technicianUserId = $tech['user_id'];
        
        // Get ticket info
        $stmt = $pdo->prepare("SELECT user_email, assigned_technician_id FROM assistance_requests WHERE id = ?");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            exit();
        }
        
        $pdo->beginTransaction();
        
        try {
            // Remove old technician's current tickets count if exists
            if ($ticket['assigned_technician_id']) {
                $stmt = $pdo->prepare("
                    UPDATE technicians SET current_tickets = GREATEST(current_tickets - 1, 0) 
                    WHERE id = ?
                ");
                $stmt->execute([$ticket['assigned_technician_id']]);
            }
            
            // Update ticket
            $stmt = $pdo->prepare("
                UPDATE assistance_requests 
                SET assigned_technician_id = ?, status = 'in_progress', updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$technicianId, $ticketId]);
            
            // Record assignment in ticket_assignments table
            $stmt = $pdo->prepare("
                INSERT INTO ticket_assignments (request_id, technician_id, assigned_by, assigned_at)
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([$ticketId, $technicianId, $userName]);
            
            // Update technician current tickets count
            $stmt = $pdo->prepare("
                UPDATE technicians SET current_tickets = current_tickets + 1 WHERE id = ?
            ");
            $stmt->execute([$technicianId]);
            
            $pdo->commit();
            
            // Send assignment notification to technician
            if ($technicianUserId) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, ?, ?, 'ticket', NOW())
                ");
                $stmt->execute([
                    $technicianUserId,
                    "New Ticket Assigned",
                    "Ticket #" . str_pad($ticketId, 6, '0', STR_PAD_LEFT) . " has been assigned to you."
                ]);
            }
            
            // Send notification to user
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$ticket['user_email']]);
            $user = $stmt->fetch();
            if ($user) {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, ?, ?, 'ticket', NOW())
                ");
                $stmt->execute([
                    $user['id'],
                    "Technician Assigned",
                    "{$technicianName} has been assigned to your ticket."
                ]);
            }
            
            // Add assignment message to chat
            $assignmentMsg = "👨‍🔧 **{$technicianName}** has been assigned to your ticket and will assist you shortly.";
            $stmt = $pdo->prepare("
                INSERT INTO ticket_chat_messages (ticket_id, sender_type, sender_name, message, created_at) 
                VALUES (?, 'admin', 'System', ?, NOW())
            ");
            $stmt->execute([$ticketId, $assignmentMsg]);
            
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    case 'get_ticket_info':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        
        if (!$ticketId) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID']);
            exit();
        }
        
        // Get ticket info with technician details
        $stmt = $pdo->prepare("
            SELECT 
                ar.*,
                t.name as technician_name,
                t.email as technician_email,
                (SELECT COUNT(*) FROM ticket_chat_messages WHERE ticket_id = ar.id AND is_read = 0 AND sender_type != 'admin') as unread_count
            FROM assistance_requests ar
            LEFT JOIN technicians t ON ar.assigned_technician_id = t.id
            WHERE ar.id = ?
        ");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            echo json_encode(['success' => false, 'error' => 'Ticket not found']);
            exit();
        }
        
        echo json_encode(['success' => true, 'ticket' => $ticket]);
        break;
        
    case 'get_technicians':
        // Only admins can get technician list
        if (!$isAdmin) {
            echo json_encode(['success' => false, 'error' => 'Unauthorized']);
            exit();
        }
        
        $stmt = $pdo->query("
            SELECT id, name, email, status, current_tickets, max_tickets, on_leave 
            FROM technicians 
            WHERE status != 'offline' OR on_leave = 0
            ORDER BY current_tickets ASC, name ASC
        ");
        $technicians = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'technicians' => $technicians]);
        break;
        
    case 'add_public_note':
        $ticketId = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $note = trim($_POST['note'] ?? '');
        
        if (!$ticketId || empty($note)) {
            echo json_encode(['success' => false, 'error' => 'Invalid ticket ID or note']);
            exit();
        }
        
        if (!$isAdmin && $userType !== 'technician') {
            echo json_encode(['success' => false, 'error' => 'Unauthorized']);
            exit();
        }
        
        $stmt = $pdo->prepare("
            UPDATE assistance_requests 
            SET public_notes = CONCAT(IFNULL(public_notes, ''), ?, '\n---\n')
            WHERE id = ?
        ");
        $success = $stmt->execute(["[" . date('Y-m-d H:i:s') . "] " . $userName . ": " . $note, $ticketId]);
        
        echo json_encode(['success' => $success]);
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>