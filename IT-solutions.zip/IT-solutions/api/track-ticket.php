<?php
// api/track-ticket.php - Track Ticket Status API
require_once '../config/database.php';

header('Content-Type: application/json');

$ticketId = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);

if (!$ticketId) {
    echo json_encode(['success' => false, 'error' => 'Invalid ticket ID']);
    exit();
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            ar.*,
            t.name as assigned_technician,
            t.email as technician_email
        FROM assistance_requests ar
        LEFT JOIN technicians t ON ar.assigned_technician_id = t.id
        WHERE ar.id = ?
    ");
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    
    if (!$ticket) {
        echo json_encode(['success' => false, 'error' => 'Ticket not found']);
        exit();
    }
    
    echo json_encode(['success' => true, 'ticket' => $ticket]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>