<?php
// my_assets.php - Staff view of their assigned assets
require_once 'config/session.php';
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['name'] ?? 'Staff Member';

// Get user's assigned assets
$stmt = $pdo->prepare("
    SELECT a.*, 
           CASE 
               WHEN a.warranty_expiry IS NULL THEN 'No Warranty'
               WHEN a.warranty_expiry < CURDATE() THEN 'Expired'
               WHEN a.warranty_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 'Expiring Soon'
               ELSE 'Valid'
           END as warranty_status,
           DATEDIFF(COALESCE(a.warranty_expiry, CURDATE()), CURDATE()) as days_until_expiry
    FROM assets a
    WHERE a.assigned_to = ?
    ORDER BY a.status, a.name
");
$stmt->execute([$userId]);
$assets = $stmt->fetchAll();

// Get user's assigned devices
$stmt = $pdo->prepare("
    SELECT d.*,
           CASE 
               WHEN d.warranty_expiry IS NULL THEN 'No Warranty'
               WHEN d.warranty_expiry < CURDATE() THEN 'Expired'
               WHEN d.warranty_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 'Expiring Soon'
               ELSE 'Valid'
           END as warranty_status
    FROM devices d
    WHERE d.assigned_to = ?
    ORDER BY d.status, d.device_name
");
$stmt->execute([$userId]);
$devices = $stmt->fetchAll();

// Statistics
$totalAssets = count($assets);
$totalDevices = count($devices);
$expiringWarranties = 0;

foreach ($assets as $asset) {
    if ($asset['warranty_status'] === 'Expiring Soon') $expiringWarranties++;
}
foreach ($devices as $device) {
    if ($device['warranty_status'] === 'Expiring Soon') $expiringWarranties++;
}

// Get unread notifications count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$userId]);
$unreadCount = $stmt->fetchColumn();

// Get recent notifications
$stmt = $pdo->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 20
");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Assets | IT Solutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            --primary: #f39c12;
            --primary-dark: #e67e22;
            --primary-light: #fef3c7;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }

        .navbar {
            background: var(--primary-gradient);
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            padding: 0.75rem 1.5rem;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
            color: white;
        }

        .navbar-brand i { font-size: 1.6rem; }

        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }

        .navbar-nav .nav-link.active {
            background: rgba(255,255,255,0.25);
        }

        .notification-bell {
            position: relative;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: white;
        }

        .notification-bell:hover { background: rgba(255,255,255,0.15); }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            font-size: 0.6rem;
            font-weight: 600;
            min-width: 18px;
            height: 18px;
            display: none;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary);
        }

        .main-content {
            margin-top: 80px;
            padding: 24px 28px;
            animation: fadeIn 0.4s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.25rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.15);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
        }

        .stat-label {
            font-size: 0.75rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .card {
            border: none;
            border-radius: 24px;
            box-shadow: 0 10px 40px -12px rgba(0,0,0,0.12);
            overflow: hidden;
            background: white;
        }

        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 1.25rem 1.5rem;
            font-weight: 700;
            font-size: 1rem;
            color: #1e293b;
        }

        .card-header i {
            color: var(--primary);
            font-size: 1.2rem;
        }

        .asset-card, .device-card {
            background: white;
            border-radius: 16px;
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
            overflow: hidden;
            height: 100%;
        }

        .asset-card:hover, .device-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.15);
            border-color: transparent;
        }

        .asset-header, .device-header {
            padding: 1rem;
            border-bottom: 1px solid #f1f5f9;
            background: #f8fafc;
        }

        .asset-body, .device-body {
            padding: 1rem;
        }

        .asset-tag {
            font-family: monospace;
            background: #e2e8f0;
            padding: 4px 8px;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .status-available { background: #d4f8e8; color: #065f46; }
        .status-assigned { background: #dbeafe; color: #1e40af; }
        .status-in_use { background: #dbeafe; color: #1e40af; }
        .status-maintenance { background: #fed7aa; color: #9b2c1d; }

        .warranty-valid { color: #10b981; }
        .warranty-expiring { color: #f59e0b; }
        .warranty-expired { color: #ef4444; }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #94a3b8;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(243,156,18,0.3);
            color: white;
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                margin-top: 70px;
            }
            .stat-value {
                font-size: 1.5rem;
            }
        }

        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="staff_dashboard.php">
                <i class="bi bi-cpu"></i>
                <span>IT Solutions</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="staff_dashboard.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="my_assets.php"><i class="bi bi-box-seam me-1"></i> My Assets</a></li>
                    <li class="nav-item"><a class="nav-link" href="my_devices.php"><i class="bi bi-laptop me-1"></i> My Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="ticket-assistance.php"><i class="bi bi-headset me-1"></i> Support</a></li>
                </ul>
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item">
                        <div class="notification-bell" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="bi bi-bell fs-5"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="notification-badge" style="display: flex;"><?= min($unreadCount, 99) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end notifications-dropdown" style="width: 380px; max-height: 500px; overflow-y: auto; border-radius: 16px; border: none; box-shadow: 0 20px 40px -12px rgba(0,0,0,0.2); padding: 0;">
                            <div class="notifications-header p-3 border-bottom d-flex justify-content-between align-items-center sticky-top bg-white">
                                <h6 class="mb-0"><i class="bi bi-bell me-2"></i>Notifications</h6>
                                <button class="btn btn-sm btn-link" onclick="markAllAsRead()">Mark all read</button>
                            </div>
                            <div id="notificationsList" class="notifications-list">
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-bell-slash fs-4"></i>
                                    <p class="mb-0 small">Loading...</p>
                                </div>
                            </div>
                            <div class="notifications-header border-top p-2 text-center">
                                <a href="profile.php" class="text-decoration-none small">View all notifications</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown ms-2">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($userName) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">My Assets & Devices</h2>
                <p class="text-muted mb-0">View all IT equipment assigned to you</p>
            </div>
            <a href="ticket-assistance.php" class="btn btn-primary">
                <i class="bi bi-headset me-2"></i> Report Issue
            </a>
        </div>

        <!-- Stats Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $totalAssets ?></div>
                            <div class="stat-label">Assigned Assets</div>
                        </div>
                        <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value"><?= $totalDevices ?></div>
                            <div class="stat-label">Assigned Devices</div>
                        </div>
                        <div class="stat-icon bg-success bg-opacity-10 text-success">
                            <i class="bi bi-laptop"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="stat-value text-warning"><?= $expiringWarranties ?></div>
                            <div class="stat-label">Expiring Warranties</div>
                        </div>
                        <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- My Assets Section -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-box-seam me-2"></i> My Assigned Assets
            </div>
            <div class="card-body">
                <?php if (empty($assets)): ?>
                    <div class="empty-state">
                        <i class="bi bi-inbox"></i>
                        <p class="mb-0">No assets assigned to you yet</p>
                        <p class="small text-muted mt-1">Contact IT admin for asset assignment</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($assets as $asset): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="asset-card">
                                    <div class="asset-header d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="asset-tag"><?= htmlspecialchars($asset['asset_tag']) ?></span>
                                        </div>
                                        <span class="status-badge status-<?= $asset['status'] ?>">
                                            <?= ucfirst(str_replace('_', ' ', $asset['status'])) ?>
                                        </span>
                                    </div>
                                    <div class="asset-body">
                                        <h6 class="mb-2"><?= htmlspecialchars($asset['name']) ?></h6>
                                        <?php if ($asset['category']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-folder me-1"></i> <?= ucfirst($asset['category']) ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($asset['model']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-device-ssd me-1"></i> <?= htmlspecialchars($asset['model']) ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($asset['serial_number']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-upc-scan me-1"></i> SN: <?= htmlspecialchars($asset['serial_number']) ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($asset['manufacturer']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-building me-1"></i> <?= htmlspecialchars($asset['manufacturer']) ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($asset['warranty_expiry']): ?>
                                            <p class="small mb-0 mt-2">
                                                <i class="bi bi-shield-check me-1"></i> Warranty: 
                                                <span class="warranty-<?= strtolower(str_replace(' ', '-', $asset['warranty_status'])) ?>">
                                                    <?= date('M d, Y', strtotime($asset['warranty_expiry'])) ?>
                                                    <?php if ($asset['days_until_expiry'] > 0 && $asset['days_until_expiry'] <= 90): ?>
                                                        (<?= $asset['days_until_expiry'] ?> days left)
                                                    <?php elseif ($asset['days_until_expiry'] < 0): ?>
                                                        (Expired)
                                                    <?php endif; ?>
                                                </span>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Devices Section -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-laptop me-2"></i> My Assigned Devices
            </div>
            <div class="card-body">
                <?php if (empty($devices)): ?>
                    <div class="empty-state">
                        <i class="bi bi-inbox"></i>
                        <p class="mb-0">No devices assigned to you yet</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($devices as $device): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="device-card">
                                    <div class="device-header d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="asset-tag"><?= htmlspecialchars($device['device_number']) ?></span>
                                        </div>
                                        <span class="status-badge status-<?= $device['status'] ?>">
                                            <?= ucfirst(str_replace('_', ' ', $device['status'])) ?>
                                        </span>
                                    </div>
                                    <div class="device-body">
                                        <h6 class="mb-2"><?= htmlspecialchars($device['device_name']) ?></h6>
                                        <?php if ($device['brand']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-building me-1"></i> <?= htmlspecialchars($device['brand']) ?>
                                                <?php if ($device['model']): ?> <?= htmlspecialchars($device['model']) ?><?php endif; ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($device['serial_number']): ?>
                                            <p class="small text-muted mb-1">
                                                <i class="bi bi-upc-scan me-1"></i> SN: <?= htmlspecialchars($device['serial_number']) ?>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($device['warranty_expiry']): ?>
                                            <p class="small mb-0 mt-2">
                                                <i class="bi bi-shield-check me-1"></i> Warranty: 
                                                <span class="warranty-<?= strtolower(str_replace(' ', '-', $device['warranty_status'])) ?>">
                                                    <?= date('M d, Y', strtotime($device['warranty_expiry'])) ?>
                                                </span>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function loadNotifications() {
            fetch('api/notifications.php?action=get_all')
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationsUI(data.notifications, data.unread_count);
                    }
                })
                .catch(err => console.error('Error loading notifications:', err));
        }

        function updateNotificationsUI(notifications, unreadCount) {
            const notificationsList = document.getElementById('notificationsList');
            const bellBadge = document.querySelector('.notification-badge');
            
            if (unreadCount > 0 && bellBadge) {
                bellBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                bellBadge.style.display = 'flex';
            } else if (bellBadge) {
                bellBadge.style.display = 'none';
            }
            
            if (!notifications || notifications.length === 0) {
                if (notificationsList) {
                    notificationsList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-bell-slash fs-4"></i>
                            <p class="mb-0 small">No notifications</p>
                        </div>
                    `;
                }
                return;
            }
            
            let html = '';
            notifications.slice(0, 10).forEach(notif => {
                const isUnread = !notif.is_read;
                html += `
                    <div class="notification-item p-3 border-bottom ${isUnread ? 'bg-warning bg-opacity-10' : ''}" data-id="${notif.id}">
                        <div class="d-flex gap-3">
                            <div class="notification-icon" style="background: #fed7aa; color: #f59e0b;">
                                <i class="bi bi-info-circle"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="notification-title fw-semibold">${escapeHtml(notif.title)}</div>
                                <div class="notification-message small text-muted">${escapeHtml(notif.message)}</div>
                                <div class="notification-time small">${timeAgo(notif.created_at)}</div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            if (notificationsList) {
                notificationsList.innerHTML = html;
            }
        }

        function markAllAsRead() {
            fetch('api/notifications.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mark_all_read'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    const bellBadge = document.querySelector('.notification-badge');
                    if (bellBadge) bellBadge.style.display = 'none';
                }
            })
            .catch(err => console.error('Error marking all as read:', err));
        }

        function timeAgo(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);
            
            if (seconds < 60) return 'Just now';
            const minutes = Math.floor(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.floor(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.floor(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            return date.toLocaleDateString();
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        document.addEventListener('DOMContentLoaded', function() {
            loadNotifications();
            setInterval(loadNotifications, 60000);
        });
    </script>
</body>
</html>